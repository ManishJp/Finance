﻿// ***********************************************************************
// <copyright file="PublicHolidayService.Reader.cs"  company = "MSC">
//   Mediterranean Shipping Company SA
//   OneVision Project
// </copyright>
// <summary>Public holiday service client.</summary>
// ***********************************************************************

namespace Msc.MasterData.Presentation.Web.UIServices
{
    using System;
    using System.Collections.Generic;
    using Models;
    using Msc.Framework.UI.Core;
    using Msc.MasterData.Service.Proxies.Readers.PublicHolidayReaderService;

    /// <summary>
    /// Class to hold all service calls to Public Holiday service.
    /// </summary>
    /// <seealso cref="Msc.MasterData.Presentation.Web.UIServices.PublicHolidayService" />
    public partial class PublicHolidayService : UIServiceBase
    {
        /// <summary>
        /// The current
        /// </summary>
        private static readonly Lazy<PublicHolidayService> current = new Lazy<PublicHolidayService>(GetInstance, System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);

        /// <summary>
        /// Gets the public holiday service instance.
        /// </summary>
        /// <returns></returns>
        private static PublicHolidayService GetInstance()
        {
            return new PublicHolidayService();
        }

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>
        /// The current.
        /// </value>
        internal static PublicHolidayService Current
        {
            get
            {
                return current.Value;
            }
        }

        /// <summary>
        /// Gets the public holidays by subdivision identifier.
        /// </summary>
        /// <param name="countryId">The country identifier.</param>
        /// <param name="subdivisionId">The subdivision identifier.</param>
        /// <returns>Returns a list of public holidays based on the country and sub divisions</returns>
        public List<PublicHolidayViewModel> GetPublicHolidaysBySubdivisionId(long countryId, long subdivisionId)
        {
            PublicHolidayReaderServiceClient client = Proxy.Create<PublicHolidayReaderServiceClient, IPublicHolidayReaderService>();
            List<PublicHolidayViewModel> publicHolidays = null;
            try
            {
                PublicHoliday[] publicHolidaysServiceResult = client.GetPublicHolidays(depotId: 0, terminalId: 0, entityId: 0, countryId: countryId, subdivisionId: subdivisionId, locationId: 0);
                publicHolidays = this.Map<List<PublicHolidayViewModel>>(publicHolidaysServiceResult);
            }
            catch (Exception e)
            {
                this.TraceDebug(e);
            }
            finally
            {
                client.CloseSafe();
            }

            return publicHolidays;
        }
    }
}