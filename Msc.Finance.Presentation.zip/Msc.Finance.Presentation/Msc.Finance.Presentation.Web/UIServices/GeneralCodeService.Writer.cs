﻿// ***********************************************************************
// <copyright file="GeneralCodeService.Writer.cs" company = "MSC">
//   Mediterranean Shipping Company SA
//   OneVision Project
// </copyright>
// <summary>General Code Service for writier.</summary>
// ***********************************************************************
namespace Msc.Finance.Presentation.Web.UIServices
{
    using System;
    using Framework.UI.Core;
    using MasterData.Service.Proxies.Writers.GeneralCodeWriterService;
    using ViewModels;
    /// <summary>
    /// Class GeneralCodeService.
    /// </summary>
    /// <seealso cref="Msc.Framework.UI.Core.UIServiceBase" />
    public partial class GeneralCodeService : UIServiceBase
    {
        /// <summary>
        /// Saves the general code.
        /// </summary>
        /// <param name="generalCodeView">The general code view.</param>
        public void SaveGeneralCode(GeneralCodeViewModel generalCodeView)
        {
            GeneralCodeWriterServiceClient generalCodeClient = Proxy.Create<GeneralCodeWriterServiceClient, IGeneralCodeWriterService>();
            try
            {
                GeneralCode generalCode = this.Map<GeneralCode>(generalCodeView);
                if (generalCode != null)
                {
                    if (generalCode.UserDetail == null)
                    {
                        generalCode.UserDetail = this.Map<UserBase>(generalCodeView.User);
                    }

                    generalCodeClient.SaveGeneralCode(generalCode);
                }
            }
            catch (Exception e)
            {
                this.TraceDebug(e);
                throw;
            }
            finally
            {
                generalCodeClient.CloseSafe();
            }
        }
    }
}