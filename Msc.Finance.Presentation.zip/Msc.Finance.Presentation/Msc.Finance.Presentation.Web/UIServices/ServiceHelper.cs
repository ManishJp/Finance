﻿// ***********************************************************************
// <copyright file="ServiceHelper.cs"  company = "MSC - iBox">
//   Mediterranean Shipping Company SA - iBox
//   OneVision Project
// </copyright>
// <summary>Service helper holds all the common method used by the UIServices.</summary>
// ***********************************************************************

namespace Msc.Finance.Presentation.Web.UIServices
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using Framework.UI.Helper;


    /// <summary>
    /// Service helper holds all the common method used by the UIServices.
    /// </summary>
    /// <seealso cref="Msc.MasterData.Presentation.Web.UIServices.ServiceHelper" />
    public class ServiceHelper
    {
        /// <summary>
        /// Method to get sort option details.
        /// </summary>
        /// <param name="request">Call back request.</param>
        /// <returns>Returns a array of strings.</returns>
        public static Dictionary<string, object> GetFilterDetail(CallbackRequestData request)
        {
            Dictionary<string, object> dict = null;
            if (request != null && request.FilterOptions != null && request.FilterOptions.Any())
            {
                dict = new Dictionary<string, object>();
                foreach (var fl in request.FilterOptions)
                {
                    if (dict.ContainsKey(fl.Member))
                    {
                        dict[fl.Member] = fl.Value;
                    }
                    else
                    {
                        dict.Add(fl.Member, fl.Value);
                    }
                }
            }

            return dict;
        }
    }
}