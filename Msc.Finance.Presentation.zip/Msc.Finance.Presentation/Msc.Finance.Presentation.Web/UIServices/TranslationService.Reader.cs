﻿// ***********************************************************************
// <copyright file="GeneralCodeService.Reader.cs"  company = "MSC">
//   Mediterranean Shipping Company SA
//   OneVision Project
// </copyright>
// <summary>General Code Service for reader.</summary>
// ***********************************************************************
namespace Msc.MasterData.Presentation.Web.UIServices
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Framework.UI.Core;
    using Framework.UI.Helper;
    using Models;
    using Service.Proxies.Readers.TranslationReaderService;
    using Pagination = Framework.Common.Model.Pagination;

    /// <summary>
    /// Class GeneralCodeService.
    /// </summary>
    /// <seealso cref="Msc.Framework.UI.Core.UIServiceBase" />
    public partial class TranslationService : UIServiceBase
    {
        /// <summary>
        /// The current
        /// </summary>
        private static readonly Lazy<TranslationService> TranslationServiceInstance = new Lazy<TranslationService>(GetTranslationServiceInstance, System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>The current.</value>
        internal static TranslationService Current
        {
            get
            {
                return TranslationServiceInstance.Value;
            }
        }

        /// <summary>
        /// Gets the general codes.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns>list of General Code Views.</returns>
        public async Task<Pagination.PageResponse<TranslationViewModel>> GetTranslations(CallbackRequestData request)
        {
            TranslationReaderServiceClient translationClient = Proxy.Create<TranslationReaderServiceClient, ITranslationReaderService>();
            Pagination.PageResponse<TranslationViewModel> translations = null;
            try
            {
                if (request != null)
                {
                    var sorts = new List<Sort>();
                    var filters = new List<Filter>();
                    Dictionary<string, object> filterDictionary = null;
                    filterDictionary = ServiceHelper.GetFilterDetail(request);
                    if (request != null && request.SortOptions != null && request.SortOptions.Any())
                    {
                        sorts.Add(new Sort() { IsDescending = request.SortOptions[0].Operator == SortOperator.Descending, Member = request.SortOptions[0].Member });
                    }

                    foreach (var filter in filterDictionary)
                    {
                        filters.Add(this.AddServiceFilter(filter.Key, filter.Value));
                    }

                    var pageRequest = new PageRequest()
                    {
                        PageIndex = request.Page,
                        PageSize = request.PageSize,
                        Filters = filters.ToArray(),
                        Sorts = sorts.ToArray()
                    };

                    PageResponseOfTranslationSearchResult translationServiceResult = await translationClient.GetTranslationsAsync(pageRequest);
                    if (translationServiceResult != null && translationServiceResult.Items != null && translationServiceResult.Items.Any())
                    {
                        translations = new Pagination.PageResponse<TranslationViewModel>() { Items = this.Map<List<TranslationViewModel>>(translationServiceResult.Items), TotalCount = translationServiceResult.TotalCount };
                    }
                }
            }
            catch (Exception e)
            {
                this.TraceDebug(e);
            }
            finally
            {
                translationClient.CloseSafe();
            }

            return translations;
        }

        /// <summary>
        /// Gets the Translation service instance.
        /// </summary>
        /// <returns>Translation Service.</returns>
        private static TranslationService GetTranslationServiceInstance()
        {
            return new TranslationService();
        }

        /// <summary>
        /// Adds the service filter.
        /// </summary>
        /// <typeparam name="T">Generic Class</typeparam>
        /// <param name="key">The key.</param>
        /// <param name="value">The value.</param>
        /// <returns>Filter value.</returns>
        private Filter AddServiceFilter<T>(string key, T value)
        {
            return new Filter()
            {
                Criteria = value?.ToString(),
                Member = key,
                CriteriaTypeName = value?.GetType().FullName
            };
        }
    }
}