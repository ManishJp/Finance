﻿// ***********************************************************************
// <copyright file="CountryService.cs"  company = "MSC">
//   Mediterranean Shipping Company SA
//   OneVision Project
// </copyright>
// <summary>Country service client.</summary>
// ***********************************************************************

namespace Msc.MasterData.Presentation.Web.UIServices
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using Framework.Common.Utility;
    using Framework.UI.Core;
    using Service.Proxies.Writers.CountryWriterService;

    /// <summary>
    /// Class to hold all service calls to Country service.
    /// </summary>
    /// <seealso cref="Msc.MasterData.Presentation.Web.UIServices.CountryService" />
    public partial class CountryService : UIServiceBase
    {
        /// <summary>
        /// Method for GetLanguage.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="languageList">Passing a value LanguageList.</param>
        /// <returns>Return a Languages List.</returns>
        public List<Models.CountryLanguageViewModel> GetLanguage(long id, string languageList)
        {
            List<Models.CountryLanguageViewModel> countryLanguages = this.GetCountryLanguages(id);
            if (countryLanguages != null && countryLanguages.Any())
            {
                IEnumerable<Models.CountryLanguageViewModel> countrylanguagesWithRecordStatus = countryLanguages.Select(s => { s.RecordStatus = Models.RecordStatus.Deleted; return s; });
                if (countrylanguagesWithRecordStatus != null)
                {
                    countryLanguages = countrylanguagesWithRecordStatus.ToList();
                }

                string[] languages = languageList.Split(separator: new char[] { ',' });
                foreach (string language in languages)
                {
                    int index = countryLanguages.FindIndex(s => s.Id == SimpleConvert.ConvertInt64(language));
                    if (index < 0)
                    {
                        countryLanguages.Add(new Models.CountryLanguageViewModel { Id = SimpleConvert.ConvertInt64(language), RecordStatus = Models.RecordStatus.Added });
                    }
                    else
                    {
                        countryLanguages[index].RecordStatus = Models.RecordStatus.Unchanged;
                    }
                }
            }

            return countryLanguages;
        }

        /// <summary>
        /// Saves the country.
        /// </summary>
        /// <param name="countryViewModel">The country view model.</param>
        /// <param name="stringConcatLanguages">The string concatenated languages.</param>
        public void SaveCountry(Models.CountryViewModel countryViewModel, string stringConcatLanguages)
        {
            CountryWriterServiceClient client = Proxy.Create<CountryWriterServiceClient, ICountryWriterService>();
            try
            {
                Country country = Map<Country>(countryViewModel);
                if (country.Status == null)
                {
                    var config = new MapperConfiguration(c =>
                    {
                        c.CreateMap<Models.CountryViewModel, Country>();
                        c.CreateMap<Models.SubdivisionViewModel, Subdivision>();
                        c.CreateMap<Models.GeneralCodeBaseViewModel, GeneralCodeBase>();
                        c.CreateMap<Models.CurrencyBaseViewModel, CurrencyBase>();
                        c.CreateMap<Models.CountryLanguageViewModel, CountryLanguage>();
                        c.CreateMap<Models.PublicHolidayViewModel, PublicHoliday>();
                        c.CreateMap<Models.UserViewModel, UserBase>();
                        c.CreateMap<Models.RecordStatus, RecordStatus>();
                    });
                    country = config.Map<Country>(countryViewModel);
                }

                if (!string.IsNullOrEmpty(stringConcatLanguages))
                {
                    var languages = new List<CountryLanguage>();
                    foreach (var data in this.GetLanguage(countryViewModel.Id, stringConcatLanguages))
                    {
                        languages.Add(new CountryLanguage
                        {
                            CountryLanguageId = data.CountryLanguageId,
                            Name = data.Name,
                            Id = data.Id,
                            RecordStatus = (RecordStatus)data.RecordStatus
                        });
                    }
                    country.Languages = languages.ToArray();
                }

                client.SaveCountry(country);
            }
            catch (Exception e)
            {
                TraceDebug(e);
                throw;
            }
            finally
            {
                client.CloseSafe();
            }
        }
    }
}