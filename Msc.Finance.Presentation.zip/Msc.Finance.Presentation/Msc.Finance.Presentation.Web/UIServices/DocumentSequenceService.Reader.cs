﻿// ***********************************************************************
// <copyright file="CountryService.cs"  company = "MSC">
//   Mediterranean Shipping Company SA
//   OneVision Project
// </copyright>
// <summary>Country service client.</summary>
// ***********************************************************************
namespace Msc.Finance.Presentation.Web.UIServices
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Finance.Presentation.Web.UIServices;
    using Finance.Service.Proxies.Readers.DocumentSequenceReaderService;
    using Framework.Common.Composition.Mappings;
    using Framework.UI.Core;
    using Framework.UI.Helper;
    using Msc.Finance.Presentation.Web.ViewModels;
    using Pagination = Framework.Common.Model.Pagination;

    /// <summary>
    /// Class CommonController.
    /// </summary>
    /// <seealso cref="Msc.Finance.Presentation.Web.UIServices.DocumentSequenceService" />
    public partial class DocumentSequenceService : UIServiceBase
    {
        /// <summary>
        /// The current
        /// </summary>
        private static readonly Lazy<DocumentSequenceService> current = new Lazy<DocumentSequenceService>(GetDocumentSequenceServiceInstance, System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);

        /// <summary>
        /// Gets the country service instance.
        /// </summary>
        /// <returns></returns>
        private static DocumentSequenceService GetDocumentSequenceServiceInstance()
        {
            return new DocumentSequenceService();
        }

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>
        /// The current.
        /// </value>
        internal static DocumentSequenceService Current
        {
            get
            {
                return current.Value;
            }
        }

        /// <summary>
        /// Adds the service filter.
        /// </summary>
        /// <typeparam name="T">Generic Class</typeparam>
        /// <param name="key">The key.</param>
        /// <param name="value">The value.</param>
        /// <returns>Filter value.</returns>
        private Filter AddServiceFilter<T>(string key, T value)
        {
            return new Filter()
            {
                Criteria = value?.ToString(),
                Member = key,
                CriteriaTypeName = value?.GetType().FullName
            };
        }

        /// <summary>
        /// Gets the countries.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="country">The country.</param>
        /// <returns>The page response of the Country search result.</returns>
        public async Task<Pagination.PageResponse<DocumentSequenceGridViewModel>> GetDocumentSequences(CallbackRequestData request, DocumentSequenceGridViewModel documentSequence)
        {
            DocumentSequenceReaderServiceClient client = Proxy.Create<DocumentSequenceReaderServiceClient, IDocumentSequenceReaderService>();
            Pagination.PageResponse<DocumentSequenceGridViewModel> documentSequences = null;
            try
            {
                var sorts = new List<Sort>();
                Dictionary<string, object> filterDictionary = null;
                filterDictionary = ServiceHelper.GetFilterDetail(request);
                if (request != null && request.SortOptions != null && request.SortOptions.Any())
                {
                    sorts.Add(new Sort() { IsDescending = request.SortOptions[0].Operator == SortOperator.Descending, Member = request.SortOptions[0].Member });
                }

                var filters = new List<Filter>();
                filters.Add(this.AddServiceFilter(key: "subModuleName", value: documentSequence.SubModuleName));
                filters.Add(this.AddServiceFilter(key: "name", value: documentSequence.Description));
                filters.Add(this.AddServiceFilter(key: "code", value: documentSequence.Code));
                filters.Add(this.AddServiceFilter(key: "issuingCompany", value: documentSequence.IssuingCompany));
                filters.Add(this.AddServiceFilter(key: "country", value: documentSequence.Country));
                if (filterDictionary != null)
                {
                    foreach (var filter in filterDictionary)
                    {
                        filters.Add(this.AddServiceFilter(filter.Key, filter.Value));
                    }
                }

                var pageRequest = new PageRequest()
                {
                    PageIndex = request.Page,
                    PageSize = request.PageSize,  
                    Filters = filters.ToArray(),          
                    Sorts = sorts.ToArray()
                };
                PageResponseOfDocumentSequenceSearchResult serviceResult = await client.GetDocumentSequencesAsync(pageRequest);
                documentSequences = this.Map<Pagination.PageResponse<DocumentSequenceGridViewModel>>(serviceResult);
            }
            catch (Exception e)
            {
                TraceDebug(e);
            }
            finally
            {
                client.CloseSafe();
            }

            return documentSequences;
        }
    }
}