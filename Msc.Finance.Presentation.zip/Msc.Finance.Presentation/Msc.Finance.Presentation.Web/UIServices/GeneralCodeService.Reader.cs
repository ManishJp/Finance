﻿// ***********************************************************************
// <copyright file="GeneralCodeService.Reader.cs"  company = "MSC">
//   Mediterranean Shipping Company SA
//   OneVision Project
// </copyright>
// <summary>General Code Service for reader.</summary>
// ***********************************************************************
namespace Msc.Finance.Presentation.Web.UIServices
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.ServiceModel;
    using System.Threading.Tasks;
    using Framework.Common.Composition.Communication;
    using Framework.UI.Core;
    using Framework.UI.Helper;
    using MasterData.Service.Proxies.Readers.GeneralCodeReaderService;
    using ViewModels;
    using Pagination = Framework.Common.Model.Pagination;

    /// <summary>
    /// Class GeneralCodeService.
    /// </summary>
    /// <seealso cref="Msc.Framework.UI.Core.UIServiceBase" />
    public partial class GeneralCodeService : UIServiceBase
    {
        /// <summary>
        /// The current
        /// </summary>
        private static readonly Lazy<GeneralCodeService> GeneralCodeServiceInstance = new Lazy<GeneralCodeService>(GetGeneralCodeServiceInstance, System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>The current.</value>
        internal static GeneralCodeService Current
        {
            get
            {
                return GeneralCodeServiceInstance.Value;
            }
        }

        /// <summary>
        /// Gets the general codes.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="generalCode">The general code.</param>
        /// <returns>list of General Code Views.</returns>
        public async Task<Pagination.PageResponse<GeneralCodeViewModel>> GetGeneralCodes(CallbackRequestData request, GeneralCodeViewModel generalCode)
        {
            GeneralCodeReaderServiceClient generalCodeClient = Proxy.Create<GeneralCodeReaderServiceClient, IGeneralCodeReaderService>();
            Pagination.PageResponse<GeneralCodeViewModel> generalCodes = null;
            try
            {
                if (request != null)
                {
                    var sorts = new List<Sort>();
                    var filters = new List<Filter>();
                    Dictionary<string, object> filterDictionary = null;
                    filterDictionary = ServiceHelper.GetFilterDetail(request);

                    if (request != null && request.SortOptions != null && request.SortOptions.Any())
                    {
                        sorts.Add(new Sort() { IsDescending = request.SortOptions[0].Operator == SortOperator.Descending, Member = request.SortOptions[0].Member });
                    }

                    if (generalCode != null)
                    {
                        filters.Add(this.AddServiceFilter(key: "code", value: generalCode.Code));
                        filters.Add(this.AddServiceFilter(key: "name", value: generalCode.Name));
                        filters.Add(this.AddServiceFilter(key: "description", value: generalCode.Description));
                        filters.Add(this.AddServiceFilter(key: "active", value: generalCode.Active.Name));
                    }

                    if (filterDictionary != null)
                    {
                        foreach (var filter in filterDictionary)
                        {
                            filters.Add(this.AddServiceFilter(filter.Key, filter.Value));
                        }
                    }

                    var pageRequest = new PageRequest()
                    {
                        PageIndex = request.Page,
                        PageSize = request.PageSize,
                        Filters = filters.ToArray(),
                        Sorts = sorts.ToArray()
                    };

                    PageResponseOfGeneralCode generalCodeServiceResult = await generalCodeClient.GetGeneralCodesAsync(pageRequest);
                    if (generalCodeServiceResult != null && generalCodeServiceResult.Items != null && generalCodeServiceResult.Items.Any())
                    {
                        generalCodes = new Pagination.PageResponse<GeneralCodeViewModel>() { Items = this.Map<List<GeneralCodeViewModel>>(generalCodeServiceResult.Items), TotalCount = generalCodeServiceResult.TotalCount };
                    }
                }
            }
            catch (Exception e)
            {
                this.TraceDebug(e);
            }
            finally
            {
                generalCodeClient.CloseSafe();
            }

            return generalCodes;
        }

        /// <summary>
        /// Gets the general codes.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="generalCode">The general code.</param>
        /// <returns>list of General Code Views.</returns>
        public async Task<Pagination.SearchResponse<GeneralCodeBaseViewModel>> SearchGeneralCodes(CallbackRequestData request, string referenceName)
        {
            GeneralCodeReaderServiceClient generalCodeClient = Proxy.Create<GeneralCodeReaderServiceClient, IGeneralCodeReaderService>(
              new EndpointAddress(new Uri(new Uri("net.tcp://127.0.0.1:19202"), ServiceNameHelper.GetPath(typeof(IGeneralCodeReaderService)))),
              new NetTcpBinding(SecurityMode.None)
              {
                  ReaderQuotas = new System.Xml.XmlDictionaryReaderQuotas
                  {
                      MaxArrayLength = 2048 * 10,
                      MaxStringContentLength = 2 * 1024 * 1024 / 8,
                  },
                  MaxBufferSize = 2 * 1024 * 1024, // 2MB
                   MaxReceivedMessageSize = 2 * 1024 * 1024, // 2 MB
               });
            generalCodeClient.InnerChannel.OperationTimeout = TimeSpan.FromSeconds(value: 30);
            Pagination.SearchResponse<GeneralCodeBaseViewModel> generalCodes = null;
            try
            {
                if (request != null)
                {
                    string filterText = Extensions.GetFilterText(request.FilterOptions);
                    SearchResultOfGeneralCodeSearchResult generalCodeSearchResults = await generalCodeClient.SearchGeneralCodesAsync(request.PageSize, request.Page, referenceName, string.Empty, filterText);
                    generalCodes = new Pagination.SearchResponse<GeneralCodeBaseViewModel>();
                    generalCodes.Items = this.Map<List<GeneralCodeBaseViewModel>>(generalCodeSearchResults.Data);
                    generalCodes.TotalCount = generalCodeSearchResults.Total;
                }
            }
            catch (Exception e)
            {
                this.TraceDebug(e);
            }
            finally
            {
                generalCodeClient.CloseSafe();
            }

            return generalCodes;
        }

        /// <summary>
        /// Gets the general code by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>General Code ViewModel.</returns>
        public GeneralCodeViewModel GetGeneralCodeById(long id)
        {
            GeneralCodeReaderServiceClient generalCodeClient = Proxy.Create<GeneralCodeReaderServiceClient, IGeneralCodeReaderService>();
            GeneralCodeViewModel generalCode = null;
            try
            {
                GeneralCode generalCodeServiceResult = generalCodeClient.GetGeneralCodeById(id);
                if (generalCodeServiceResult != null)
                {
                    generalCode = this.Map<GeneralCodeViewModel>(generalCodeServiceResult);
                }
            }
            catch (Exception e)
            {
                this.TraceDebug(e);
            }
            finally
            {
                generalCodeClient.CloseSafe();
            }

            return generalCode;
        }

        /// <summary>
        /// Gets the country service instance.
        /// </summary>
        /// <returns>GeneralCode Service.</returns>
        private static GeneralCodeService GetGeneralCodeServiceInstance()
        {
            return new GeneralCodeService();
        }

        /// <summary>
        /// Adds the service filter.
        /// </summary>
        /// <typeparam name="T">Generic Class</typeparam>
        /// <param name="key">The key.</param>
        /// <param name="value">The value.</param>
        /// <returns>Filter value.</returns>
        private Filter AddServiceFilter<T>(string key, T value)
        {
            return new Filter()
            {
                Criteria = value?.ToString(),
                Member = key,
                CriteriaTypeName = value?.GetType().FullName
            };
        }
    }
}