﻿// ***********************************************************************
// <copyright file="CountryService.cs"  company = "MSC">
//   Mediterranean Shipping Company SA
//   OneVision Project
// </copyright>
// <summary>Country service client.</summary>
// ***********************************************************************
namespace Msc.MasterData.Presentation.Web.UIServices
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Pagination = Framework.Common.Model.Pagination;
    using Framework.UI.Core;
    using Framework.UI.Helper;
    using Service.Proxies.Readers.CountryReaderService;
    using Framework.Common.Composition.Mappings;
    using Finance.Presentation.Web.ViewModels;
    using Finance.Presentation.Web.UIServices;/// <summary>
                                              /// Class CommonController.
                                              /// </summary>
                                              /// <seealso cref="Msc.MasterData.Presentation.Web.UIServices.CountryService" />
    public partial class CountryService : UIServiceBase
    {
        /// <summary>
        /// The current
        /// </summary>
        private static readonly Lazy<CountryService> current = new Lazy<CountryService>(GetCountryServiceInstance, System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);

        /// <summary>
        /// Gets the country service instance.
        /// </summary>
        /// <returns></returns>
        private static CountryService GetCountryServiceInstance()
        {
            return new CountryService();
        }
        
        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>
        /// The current.
        /// </value>
        internal static CountryService Current
        {
            get
            {
                return current.Value;
            }
        }

        /// <summary>
        /// Adds the service filter.
        /// </summary>
        /// <typeparam name="T">Generic Class</typeparam>
        /// <param name="key">The key.</param>
        /// <param name="value">The value.</param>
        /// <returns>Filter value.</returns>
        private Filter AddServiceFilter<T>(string key, T value)
        {
            return new Filter()
            {
                Criteria = value?.ToString(),
                Member = key,
                CriteriaTypeName = value?.GetType().FullName
            };
        }

        /// <summary>
        /// Gets the countries.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="country">The country.</param>
        /// <returns>The page response of the Country search result.</returns>
        public async Task<Pagination.PageResponse<CountryViewModel>> GetCountries(CallbackRequestData request, CountryFilterViewModel country)
        {
            CountryReaderServiceClient client = Proxy.Create<CountryReaderServiceClient, ICountryReaderService>();
            Pagination.PageResponse<CountryViewModel> countries = null;
            try
            {
                var sorts = new List<Sort>();
                Dictionary<string, object> filterDictionary = null;
                filterDictionary = ServiceHelper.GetFilterDetail(request);
                if (request != null && request.SortOptions != null && request.SortOptions.Any())
                {
                    sorts.Add(new Sort() { IsDescending = request.SortOptions[0].Operator == SortOperator.Descending, Member = request.SortOptions[0].Member });
                }

                var filters = new List<Filter>();
                filters.Add(this.AddServiceFilter(key: "code", value: country.Code));
                filters.Add(this.AddServiceFilter(key: "name", value: country.Name));
                filters.Add(this.AddServiceFilter(key: "divisionCode", value: country.SubdivisionCode));
                filters.Add(this.AddServiceFilter(key: "divisionName", value: country.SubdivisionName));
                filters.Add(this.AddServiceFilter(key: "status", value: country.Status.Code));
                filters.Add(this.AddServiceFilter(key: "isEuropean", value: country.EuropeanCountryDetail.Code));
                filters.Add(this.AddServiceFilter(key: "validTo", value: country.AsOfDate));
                if (filterDictionary != null)
                {
                    foreach (var filter in filterDictionary)
                    {
                        filters.Add(this.AddServiceFilter(filter.Key, filter.Value));
                    }
                }

                var pageRequest = new PageRequest()
                {
                    PageIndex = request.Page,
                    PageSize = request.PageSize,
                    Filters = filters.ToArray(),
                    Sorts = sorts.ToArray()
                };
                PageResponseOfCountrySearchResult serviceResult = await client.GetCountriesAsync(pageRequest);
                countries = this.Map<Pagination.PageResponse<CountryViewModel>>(serviceResult);
            }
            catch (Exception e)
            {
                TraceDebug(e);
            }
            finally
            {
                client.CloseSafe();
            }

            return countries;
        }

        /// <summary>
        /// Gets the country by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>The country view model.</returns>
        public CountryViewModel GetCountryById(long id)
        {
            CountryReaderServiceClient client = Proxy.Create<CountryReaderServiceClient, ICountryReaderService>();
            CountryViewModel country = null;
            try
            {
                CountrySearchResult serviceResult = client.GetCountryById(id);
                if (serviceResult != null)
                {
                    country = this.Map<CountryViewModel>(serviceResult);
                    if (serviceResult.CurrencyDetail == null)
                    {
                        country.CurrencyDetail = Map<CurrencyBaseViewModel>(serviceResult.CurrencyDetail);
                        country.UserDetail = Map<UserViewModel>(serviceResult.UserDetail);
                        country.Status = Map<GeneralCodeBaseViewModel>(serviceResult.Status);
                    }

                    country.CountryLanguages = GetCountryLanguages(id);
                }
            }
            catch (Exception e)
            {
                TraceDebug(e);
            }
            finally
            {
                client.CloseSafe();
            }

            return country;
        }

        /// <summary>
        /// Gets the sub divisions.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>List of Subdivision ViewModel.</returns>
        public List<Models.SubdivisionViewModel> GetSubDivisions(long id)
        {
            CountryReaderServiceClient client = Proxy.Create<CountryReaderServiceClient, ICountryReaderService>();
            List<Models.SubdivisionViewModel> subDivisions = default(List<Models.SubdivisionViewModel>);
            try
            {
                SubdivisionSearchResult[] serviceResult = client.GetSubdivisions(id);
                if (serviceResult != null && serviceResult.Length > 0)
                {
                    subDivisions = Map<List<SubdivisionViewModel>>(serviceResult);
                }
            }
            catch (Exception e)
            {
                TraceDebug(e);
            }
            finally
            {
                client.CloseSafe();
            }

            return subDivisions;
        }

        /// <summary>
        /// Gets the country language.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>List of Country Language ViewModel.</returns>
        private List<Models.CountryLanguageViewModel> GetCountryLanguages(long id)
        {
            CountryReaderServiceClient client = Proxy.Create<CountryReaderServiceClient, ICountryReaderService>();
            List<Models.CountryLanguageViewModel> languages = default(List<Models.CountryLanguageViewModel>);
            try
            {
                CountryLanguage[] serviceResult = client.GetCountryLanguage(id);
                if (serviceResult != null)
                {
                    languages = Map<List<Models.CountryLanguageViewModel>>(serviceResult);
                }
            }
            catch (Exception e)
            {
                TraceDebug(e);
            }
            finally
            {
                client.CloseSafe();
            }

            return languages;
        }
    }
}