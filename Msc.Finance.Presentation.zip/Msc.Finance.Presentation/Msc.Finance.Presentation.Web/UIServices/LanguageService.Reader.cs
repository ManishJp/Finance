﻿// ***********************************************************************
// <copyright file="LanguageService.Reader.cs"  company = "MSC">
//   Mediterranean Shipping Company SA
//   OneVision Project
// </copyright>
// <summary>Language service client.</summary>
// ***********************************************************************

namespace Msc.MasterData.Presentation.Web.UIServices
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Framework.UI.Helper;
    using Models;
    using Msc.Framework.UI.Core;
    using Msc.MasterData.Service.Proxies.Readers.LanguageReaderService;
    using Pagination = Framework.Common.Model.Pagination;

    /// <summary>
    /// Class to hold all service calls to Language service.
    /// </summary>
    /// <seealso cref="Msc.MasterData.Presentation.Web.UIServices.LanguageService" />
    public partial class LanguageService : UIServiceBase
    {
        /// <summary>
        /// The current
        /// </summary>
        private static readonly Lazy<LanguageService> current = new Lazy<LanguageService>(GetInstance, System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);

        /// <summary>
        /// Gets the language service instance.
        /// </summary>
        /// <returns></returns>
        private static LanguageService GetInstance()
        {
            return new LanguageService();
        }

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>
        /// The current.
        /// </value>
        internal static LanguageService Current
        {
            get
            {
                return current.Value;
            }
        }

        /// <summary>
        /// Gets the languages of all countries based on the criteria.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Search response of the Languages based on the filter criteria.</returns>
        public Pagination.SearchResponse<CountryLanguageViewModel> GetLanguages(CallbackRequestData request)
        {
            LanguageReaderServiceClient client = Proxy.Create<LanguageReaderServiceClient, ILanguageReaderService>();
            Pagination.SearchResponse<CountryLanguageViewModel> languages = null;
            try
            {
                string criteria = string.Empty;
                if (request != null)
                {
                    criteria = Extensions.GetFilterText(request?.FilterOptions);
                    var sorts = new List<Sort>();
                    Dictionary<string, object> filterDictionary = null;
                    filterDictionary = ServiceHelper.GetFilterDetail(request);
                    if (request != null && request.SortOptions != null && request.SortOptions.Any())
                    {
                        sorts.Add(new Sort() { IsDescending = request.SortOptions[0].Operator == SortOperator.Descending, Member = request.SortOptions[0].Member });
                    }

                    var filters = new List<Filter>();
                    filters.Add(new Filter()
                    {
                        Criteria = criteria,
                        Member = "code"
                    });
                    var pageRequest = new PageRequest()
                    {
                        PageIndex = request.Page,
                        PageSize = request.PageSize,
                        Filters = filters.ToArray(),
                        Sorts = sorts.ToArray()
                    };
                    PageResponseOfLanguage languagePageResponse = client.GetLanguages(pageRequest);
                    languages = new Pagination.SearchResponse<CountryLanguageViewModel>();
                    languages.Items = Map<List<CountryLanguageViewModel>>(languagePageResponse.Items);
                    languages.TotalCount = languagePageResponse.TotalCount;
                }
            }
            catch (Exception e)
            { TraceDebug(e); }
            finally
            {
                client.CloseSafe();
            }
            return languages;
        }
    }
}