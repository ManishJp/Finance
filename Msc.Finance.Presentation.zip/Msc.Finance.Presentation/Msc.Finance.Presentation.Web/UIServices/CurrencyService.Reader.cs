﻿// ***********************************************************************
// <copyright file="CurrencyService.Reader.cs"  company = "MSC">
//   Mediterranean Shipping Company SA
//   OneVision Project
// </copyright>
// <summary>Country service client.</summary>
// ***********************************************************************

namespace Msc.MasterData.Presentation.Web.UIServices
{
    using System;
    using System.Collections.Generic;
    using Framework.Common.Model.Pagination;
    using Framework.UI.Helper;
    using Models;
    using Msc.Framework.UI.Core;
    using Msc.MasterData.Service.Proxies.Readers.CurrencyReaderService;

    /// <summary>
    /// Class to hold all service calls to Currency service.
    /// </summary>
    /// <seealso cref="Msc.MasterData.Presentation.Web.UIServices.CurrencyService" />
    public partial class CurrencyService : UIServiceBase
    {
        /// <summary>
        /// The current
        /// </summary>
        private static readonly Lazy<CurrencyService> current = new Lazy<CurrencyService>(GetCountryServiceInstance, System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);

        /// <summary>
        /// Gets the currency service instance.
        /// </summary>
        /// <returns></returns>
        private static CurrencyService GetCountryServiceInstance()
        {
            return new CurrencyService();
        }

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>
        /// The current.
        /// </value>
        internal static CurrencyService Current
        {
            get
            {
                return current.Value;
            }
        }

        /// <summary>
        /// Gets the country language.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Search response of the currency based on the filter criteria.</returns>
        public SearchResponse<CurrencyBaseViewModel> GetCurrencies(CallbackRequestData request)
        {
            CurrencyReaderServiceClient client = Proxy.Create<CurrencyReaderServiceClient, ICurrencyReaderService>();
            SearchResponse<CurrencyBaseViewModel> currency = null;
            try
            {
                string criteria = string.Empty;
                if (request != null)
                {
                    criteria = Extensions.GetFilterText(request?.FilterOptions);
                    SearchResultOfCurrencyBase currencyServiceResult = client.SearchCurrencies(request.PageSize, request.Page, criteria, string.Empty);
                    currency = new SearchResponse<CurrencyBaseViewModel>();
                    currency.Items = Map<List<CurrencyBaseViewModel>>(currencyServiceResult.Data);
                    currency.TotalCount = currencyServiceResult.Total;
                }
            }
            catch (Exception e)
            { TraceDebug(e); }
            finally
            {
                client.CloseSafe();
            }
            return currency;
        }
    }
}
