﻿// ***********************************************************************
// <copyright file="ProxyConfiguration.cs" company = "MSC">
//   Mediterranean Shipping Company SA
//   OneVision Project
// </copyright>
// <summary>Proxy Configuration.</summary>
// ***********************************************************************
namespace Msc.Finance.Presentation.Web
{
    using System;
    using System.Configuration;
    using System.ServiceModel;
    using System.ServiceModel.Channels;
    using Framework.UI.Core;

    /// <summary>
    /// Class ProxyConfiguration.
    /// </summary>
    /// <seealso cref="Msc.Framework.UI.Core.IProxyConfiguration" />
    [ProxyConfigurationExport]
    public class ProxyConfiguration : IProxyConfiguration
    {
        /// <summary>
        /// Gets the base address.
        /// </summary>
        /// <value>The base address.</value>
        public Uri BaseAddress
        {
            get
            {
                return new Uri(ConfigurationManager.AppSettings["ProxyBaseAddress"]);
            }
        }

        /// <summary>
        /// Gets the operation time out.
        /// </summary>
        /// <value>The operation time out.</value>
        public TimeSpan OperationTimeOut
        {
            get
            {
                return TimeSpan.FromSeconds(value: 3000);
            }
        }

        /// <summary>
        /// Gets the binding.
        /// </summary>
        /// <value>The binding.</value>
        public Binding Binding
        {
            get
            {
                return new NetTcpBinding(SecurityMode.None)
                {
                    ReaderQuotas = new System.Xml.XmlDictionaryReaderQuotas
                    {
                        MaxArrayLength = 2048 * 10,
                        MaxStringContentLength = 2 * 1024 * 1024 / 8,
                    },
                    MaxBufferSize = 2 * 1024 * 1024, // 2MB
                    MaxReceivedMessageSize = 2 * 1024 * 1024, // 2 MB
                };
            }
        }
    }
}