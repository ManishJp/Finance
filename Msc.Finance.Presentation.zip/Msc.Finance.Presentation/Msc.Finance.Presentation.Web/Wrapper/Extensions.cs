﻿//-----------------------------------------------------------------------
// <copyright file = "Extensions.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox
//   OneVision Project
// </copyright>
// <summary>This is the Extensions class.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Presentation.Web
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using Msc.Framework.UI.Helper;

    /// <summary>
    /// Class Extensions.
    /// </summary>
    public static class Extensions
    {
        /// <summary>
        /// Method to get filter text.
        /// </summary>
        /// <param name="filterOptions">List of filter option.</param>
        /// <returns>Returns a filter text.</returns>
        public static string GetFilterText(IList<FilterOption> filterOptions)
        {
            string filterText = string.Empty;
            if (filterOptions != null && filterOptions.Any())
            {
                if (filterOptions.FirstOrDefault() != null)
                {
                    filterText = filterOptions.FirstOrDefault().Value.ToString();
                }
            }

            return filterText;
        }

        /// <summary>
        /// Maps the specified source to Generic Class.
        /// </summary>
        /// <typeparam name="T">Generic Class.</typeparam>
        /// <param name="source">The source.</param>
        /// <returns>Generic Class for map.</returns>
        public static T Map<T>(object source) where T : class
        {
            if (typeof(T).GenericTypeArguments.Any() && source.GetType().HasElementType)
            {
                return Map<T>(source, source.GetType().GetElementType(), typeof(T).GenericTypeArguments.First());
            }

            return Map<T>(source, source.GetType(), typeof(T));
        }

        /// <summary>
        /// Maps the specified data.
        /// </summary>
        /// <typeparam name="T">Generic Class.</typeparam>
        /// <param name="data">The data.</param>
        /// <param name="source">The source.</param>
        /// <param name="destination">The destination.</param>
        /// <returns>Generic Class Value.</returns>
        public static T Map<T>(object data, Type source, Type destination) where T : class
        {
            var config = new MapperConfiguration(cfg => cfg.CreateMap(source, destination));
            return config.Map<T>(data);
        }

        /// <summary>
        /// Maps the specified source.
        /// </summary>
        /// <typeparam name="T">Generic Class.</typeparam>
        /// <param name="config">The configuration.</param>
        /// <param name="source">The source.</param>
        /// <returns>Generic Class Value.</returns>
        public static T Map<T>(this MapperConfiguration config, object source) where T : class
        {
            if (source == null)
            {
                return Activator.CreateInstance<T>();
            }

            IMapper mapper = config.CreateMapper();
            return mapper.Map<T>(source);
        }

        /// <summary>
        /// Gets the value for filter.
        /// </summary>
        /// <typeparam name="T">Generic Class.</typeparam>
        /// <param name="value">The value.</param>
        /// <param name="key">The key.</param>
        /// <returns>Generic Class Value.</returns>
        internal static T GetFilterValue<T>(this Dictionary<string, object> value, string key)
        {
            if (value.ContainsKey(key))
            {
                return (T)value[key];
            }

            return default(T);
        }
    }
}