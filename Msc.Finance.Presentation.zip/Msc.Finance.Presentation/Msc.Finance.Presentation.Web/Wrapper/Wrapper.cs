﻿// ***********************************************************************
// <copyright file = "Wrapper.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox. OneVision Project.
// </copyright>
// <summary>This is the CountryView class.</summary>
// ***********************************************************************
namespace Msc.Finance.Presentation.Web
{
    using System;
    using System.Linq.Expressions;
    using System.Web.Mvc;
    using Framework.UI.Helper;

    /// <summary>
    /// Class Wrapper.
    /// </summary>
    public static class Wrapper
    {
        /// <summary>
        /// the ComboBox for.
        /// </summary>
        /// <typeparam name="TModel">The type of the t model.</typeparam>
        /// <typeparam name="TProperty">The type of the t property.</typeparam>
        /// <param name="helper">The helper.</param>
        /// <param name="expression">The expression.</param>
        /// <param name="routeValue">The route value.</param>
        /// <returns>Html String.</returns>
        public static MvcHtmlString OVGeneralCodeFor<TModel, TProperty>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TProperty>> expression, object routeValue)
        {
            return helper.OVComboBoxFor(
                expression,
                new ComboBoxSettings
                {
                    ValueField = "Code",
                    TextField = "Description",
                    ControllerName = "Common",
                    Custom = true,
                    MethodName = "GetGeneralCodeList",
                    RouteValues = routeValue
                });
        }

        /// <summary>
        /// the general code for.
        /// </summary>
        /// <typeparam name="TModel">The type of the t model.</typeparam>
        /// <typeparam name="TProperty">The type of the t property.</typeparam>
        /// <param name="helper">The helper.</param>
        /// <param name="expression">The expression.</param>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <returns>Html String.</returns>
        public static MvcHtmlString OVGeneralCodeFor<TModel, TProperty>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TProperty>> expression, string methodName, object routeValue)
        {
            return helper.OVComboBoxFor(
                expression,
                new ComboBoxSettings
                {
                    ValueField = "Code",
                    TextField = "Description",
                    ControllerName = "Common",
                    Custom = true,
                    MethodName = methodName,
                    RouteValues = routeValue
                });
        }

        /// <summary>
        /// the valid from.
        /// </summary>
        /// <typeparam name="TModel">The type of the t model.</typeparam>
        /// <param name="helper">The helper.</param>
        /// <param name="expression">The expression.</param>
        /// <param name="validTo">The valid to.</param>
        /// <returns>Html String.</returns>
        public static MvcHtmlString OVValidFrom<TModel>(this HtmlHelper<TModel> helper, Expression<Func<TModel, DateTime>> expression, DateTime validTo)
        {
            DateTime? maxDate = null;
            if (validTo.Date != default(DateTime))
            {
                maxDate = validTo;
            }

            return helper.OVDatePickerFor(expression, maxDate: maxDate);
        }

        /// <summary>
        /// the valid to.
        /// </summary>
        /// <typeparam name="TModel">The type of the t model.</typeparam>
        /// <param name="helper">The helper.</param>
        /// <param name="expression">The expression.</param>
        /// <param name="validFrom">The valid from.</param>
        /// <returns>Html String.</returns>
        public static MvcHtmlString OVValidTo<TModel>(this HtmlHelper<TModel> helper, Expression<Func<TModel, DateTime>> expression, DateTime validFrom)
        {
            return helper.OVDatePickerFor(expression, minDate: validFrom.Date == default(DateTime) ? DateTime.Now : validFrom);
        }

        /// <summary>
        /// the new element.
        /// </summary>
        /// <param name="helper">The helper.</param>
        /// <param name="mainCssClass">The main CSS class.</param>
        /// <param name="elementCssClass">The element CSS class.</param>
        /// <param name="label">The label.</param>
        /// <param name="element">The element.</param>
        /// <returns>Html String.</returns>
        public static MvcHtmlString OVNewElement(this HtmlHelper helper, string mainCssClass, string elementCssClass, MvcHtmlString label, MvcHtmlString element)
        {
            TagBuilder elementTag = TagHelper.Build(tagName: "div", idField: string.Empty, cssClass: elementCssClass, innerHtml: element.ToString(), clickEvent: string.Empty);
            TagBuilder row = TagHelper.Build(tagName: "div", idField: string.Empty, cssClass: "row", innerHtml: label.ToString() + elementTag.ToString(), clickEvent: string.Empty);
            return MvcHtmlString.Create(TagHelper.Build(tagName: "div", idField: string.Empty, cssClass: mainCssClass, innerHtml: row.ToString(), clickEvent: string.Empty).ToString());
        }
    }
}