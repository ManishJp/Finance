﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System;

    [Serializable]
    public class DocumentTypeDefinitionViewModel
    {
        public long UsedByAgencyCount { get; set; }

        public long UnUsedByAgencyCount { get; set; }

        public List<DocumentTypeGridViewModel> DocumentTypes { get; set; }
    }
}
