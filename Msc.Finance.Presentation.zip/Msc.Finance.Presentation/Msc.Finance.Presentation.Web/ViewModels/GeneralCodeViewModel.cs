﻿//-----------------------------------------------------------------------
// <copyright file = "GeneralCodeViewModel.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox
//   OneVision Project
// </copyright>
// <summary>This is the GeneralCodeView class.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System;

    /// <summary>
    /// Class GeneralCodeView.
    /// </summary>
    [Serializable]
    public class GeneralCodeViewModel : GeneralCodeBaseViewModel
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public long Id { get; set; }        
        
        /// <summary>
        /// Gets or sets the UsedByAgency.
        /// </summary>
        /// <value>Used By Agency.</value>
        public string UsedByAgency { get; set; }

        /// <summary>
        /// Gets or sets the sequence order.
        /// </summary>
        /// <value>The sequence order.</value>
        public long SequenceOrder { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value><c>true</c> if this instance is active; otherwise, <c>false</c>.</value>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets the user detail.
        /// </summary>
        /// <value>The user detail.</value>
        public UserViewModel User { get; set; } = new UserViewModel();

        /// <summary>
        /// Gets or sets the active detail.
        /// </summary>
        /// <value>The active detail.</value>
        public GeneralCodeBaseViewModel Active { get; set; } = new GeneralCodeBaseViewModel();
    }
}