﻿//-----------------------------------------------------------------------
// <copyright file = "DocumentSequenceView.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox. OneVision Project.
// </copyright>
// <summary>Model Class For DocumentSequenceView.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System;

    [Serializable]
    public class DocumentSequenceViewModel 
    {        
        #region Properties

        /// <summary>
        ///  Gets or sets the value for Id.
        /// </summary>
        /// <value>Id value.</value>
        public long Id { get; set; }

        /// <summary>
        ///  Gets or sets the value for Description.
        /// </summary>
        /// <value>Description value.</value>
        public string Description { get; set; }

        /// <summary>
        ///  Gets or sets the value for Code.
        /// </summary>
        /// <value>Code value.</value>
        public string Code { get; set; }

        /// <summary>
        ///  Gets or sets the value for RecordStatus.
        /// </summary>
        /// <value>RecordStatus value.</value>
        public RecordRowStatusModel RecordStatus { get; set; }

        /// <summary>
        ///  Gets or sets the value for Module Detail.
        /// </summary>
        /// <value>Module value.</value>
        public GeneralCodeViewModel ModuleDetail { get; set; }

        /// <summary>
        ///  Gets or sets the value for IssuingCompany.
        /// </summary>
        /// <value>Issuing Company value.</value>
        public GeneralCodeViewModel IssuingCompany { get; set; }

        /// <summary>
        ///  Gets or sets the value for CountryHO.
        /// </summary>
        /// <value>Country HO value.</value>
        public CountryViewModel CountryHO { get; set; }

        /// <summary>
        ///  Gets or sets a value indicating whether IsUseForProForma.
        /// </summary>
        /// <value>Use For IsUseForProForma value.</value>
        public bool IsProforma { get; set; }

        /// <summary>
        ///  Gets or sets a value indicating whether IsLocationPrefix.
        /// </summary>
        /// <value>Location Prefix value.</value>
        public bool IsLocationPrefix { get; set; }

        /// <summary>
        ///  Gets or sets the value for SEQResetFrequency.
        /// </summary>
        /// <value>SEQ Reset Frequency value.</value>
        public GeneralCodeViewModel ResetFrequency { get; set; }

        /// <summary>
        ///  Gets or sets the value for SerialLength.
        /// </summary>
        /// <value>Serial Length value.</value>
        public long SerialLength { get; set; }

        /// <summary>
        ///  Gets or sets the value for DebitReference.
        /// </summary>
        /// <value>Debit Reference value.</value>
        public string DebitPrefix { get; set; }

        /// <summary>
        ///  Gets or sets the value for DebitStart.
        /// </summary>
        /// <value>Debit Start value.</value>
        public long DebitStartingNo { get; set; }

        /// <summary>
        ///  Gets or sets the value for DebitDocPreviewNo.
        /// </summary>
        /// <value>DebitDoc PreviewNo value.</value>
        public string DebitDocPreviewNo { get; set; }

        /// <summary>
        ///  Gets or sets the value for CreditReference.
        /// </summary>
        /// <value>Credit Reference value.</value>
        public string CreditPrefix { get; set; }

        /// <summary>
        ///  Gets or sets the value for CreditStarts.
        /// </summary>
        /// <value>Credit Starts value.</value>
        public long CreditStartingNo { get; set; }

        /// <summary>
        ///  Gets or sets the value for CreditDocPreviewNo.
        /// </summary>
        /// <value>CreditDoc PreviewNo value.</value>
        public string CreditDocPreviewNo { get; set; }

        #endregion Properties
    }
}