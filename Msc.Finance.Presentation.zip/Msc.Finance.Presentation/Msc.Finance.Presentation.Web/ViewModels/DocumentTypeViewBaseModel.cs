﻿//-----------------------------------------------------------------------
// <copyright file = "DocumentTypeHeaderView.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox. OneVision Project.
// </copyright>
// <summary>
//   Declare DocumentTypeHeaderView.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System.Collections.Generic;

    using System;

    [Serializable]
    public class DocumentTypeViewBaseModel
    {

        #region Properties       

        /// <summary>
        ///  Gets or sets the value for Id.
        /// </summary>
        /// <value>Id value.</value>
        public long Id { get; set; }

        /// <summary>
        ///  Gets or sets the value for Code.
        /// </summary>
        /// <value>Code value.</value>
        public string Code { get; set; }

        /// <summary>
        ///  Gets or sets the value for Description.
        /// </summary>
        /// <value>Description value.</value>
        public string Description { get; set; }

        #endregion
    }
}
