﻿//-----------------------------------------------------------------------
// <copyright file = "DocumentTypeHeaderView.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox. OneVision Project.
// </copyright>
// <summary>
//   Declare DocumentTypeHeaderView.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System.Collections.Generic;

    using System;

    [Serializable]
    public class DocumentTypeViewModel : DocumentTypeViewBaseModel
    {      

        #region Properties       

        /// <summary>
        ///  Gets or sets the value for DocumentType.
        /// </summary>
        /// <value>DocumentType value.</value>
        public string DocumentType { get; set; }

        /// <summary>
        ///  Gets or sets the value for RecordStatus.
        /// </summary>
        /// <value>RecordStatus value.</value>
        public RecordRowStatus RecordStatus { get; set; }

        /// <summary>
        /// Gets or sets the value for ModuleDetail.
        /// </summary>
        /// <value>Module Detail.</value>
        public GeneralCodeViewModel SubModule { get; set; } = new GeneralCodeViewModel();

        /// <summary>
        /// Gets or sets the value for GeneralCodeDetail.
        /// </summary>
        /// <value>GeneralCode Detail.</value>
        public GeneralCodeViewModel GeneralCode { get; set; } = new GeneralCodeViewModel();

        /// <summary>
        /// Gets or sets the value for GeneralCodeDetail.
        /// </summary>
        /// <value>GeneralCode Detail.</value>
        public GeneralCodeViewModel Status { get; set; } = new GeneralCodeViewModel();

        /// <summary>
        ///  Gets or sets the value for BusinessCode.
        /// </summary>
        /// <value>Business Code.</value>
        public string BusinessCode { get; set; }

        /// <summary>
        ///  Gets or sets a value indicating whether IsActive.
        /// </summary>
        /// <value>Active Value.</value>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets the UsedByAgency.
        /// </summary>
        /// <value>Used By Agency.</value>
        public string UsedByAgency { get; set; }

        /// <summary>
        ///  Gets or sets the value for AllowedRoles.
        /// </summary>
        /// <value>Allowed Roles.</value>
        public IList<RoleViewModel> AllowedRoles { get; set; }

        /// <summary>
        ///  Gets or sets the value for HeaderDynamicAttributes.
        /// </summary>
        /// <value>Header DynamicAttributes.</value>
        public IList<DynamicAttributeDefinitionViewModel> HeaderDynamicAttributes { get; set; }

        /// <summary>
        /// Gets or sets the LineItemDetails.
        /// </summary>
        /// <value>This property gets or sets the value of the LineItemDetails.</value>
        public IList<DocumentLineItemViewModel> LineItems { get; set; }

        /// <summary>
        /// Gets or sets the SequenceTemplateDetail.
        /// </summary>
        /// <value>This property or sets the value of the SequenceTemplateDetail.</value>
        public IList<DocumentSequenceTemplateViewModel> SequenceTemplates { get; set; }

        #endregion
    }
}
