﻿namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System;

    [Serializable]
    public class RoleViewModel
    {
        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets Code.
        /// </summary>
        public string Code { get; set; }

        /// <summaryDescription
        /// Gets or sets Name.
        /// </summary>
        public string Description { get; set; }
    }
}
