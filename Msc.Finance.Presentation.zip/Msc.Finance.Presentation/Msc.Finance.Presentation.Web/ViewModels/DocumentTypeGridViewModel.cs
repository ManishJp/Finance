﻿//-----------------------------------------------------------------------
// <copyright file = "DocumentTypeGridView.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox. OneVision Project.
// </copyright>
// <summary>
//   Declare DocumentTypeGridView.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System.Collections.Generic;
    using System;

    [Serializable]
    public class DocumentTypeGridViewModel
    {
        #region Properties

        /// <summary>
        ///  Gets or sets the value for Id.
        /// </summary>
        /// <value>Id value.</value>
        public long Id { get; set; }

        /// <summary>
        ///  Gets or sets the value for Code.
        /// </summary>
        /// <value>Code value.</value>
        public string Code { get; set; }

        /// <summary>
        ///  Gets or sets the value for Description.
        /// </summary>
        /// <value>Description value.</value>
        public string Description { get; set; }

        /// <summary>
        ///  Gets or sets the value for Status.
        /// </summary>
        /// <value>Status value.</value>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the value for ModuleDetail.
        /// </summary>
        /// <value>Module Detail.</value>
        public string SubModuleName { get; set; }

        /// <summary>
        ///  Gets or sets the value for BusinessCode.
        /// </summary>
        /// <value>Business Code.</value>
        public string BusinessCode { get; set; }

        /// <summary>
        ///  Gets or sets the value for DocumentType.
        /// </summary>
        /// <value>DocumentType.</value>
        public string DocumentType { get; set; }

        #endregion
    }
}
