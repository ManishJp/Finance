﻿namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System;

    [Serializable]
    public class ChargeCodeViewModel
    {
        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets Code.
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets Description.
        /// </summary>
        public string Description { get; set; }
    }
}