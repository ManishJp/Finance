﻿//-----------------------------------------------------------------------
// <copyright file = "DocumentSequenceTemplateViewModel.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox. OneVision Project.
// </copyright>
// <summary>Model Class For DocumentSequenceTemplateViewModel.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System;

    [Serializable]
    public class DocumentSequenceTemplateViewModel
    {        
        #region Properties


        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        /// <value>Country View Id.</value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets Code.
        /// </summary>
        /// <value>Country View Code.</value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets Description.
        /// </summary>
        /// <value>General Code View Description.</value>
        public string Description { get; set; }

        /// <summary>
        ///  Gets or sets the value for CompanyEntityDetail.
        /// </summary>
        /// <value>Company Entity Detail .</value>
        public CompanyEntityViewModel CompanyEntityDetail { get; set; }

        /// <summary>
        ///  Gets or sets the value for IssuingCompanyDetail.
        /// </summary>
        /// <value>Issuing Company Detail.</value>
        public GeneralCodeViewModel IssuingCompanyDetail { get; set; }

        /// <summary>
        ///  Gets or sets the value for DocumentSequenceDetail.
        /// </summary>
        /// <value>Document Sequence Detail.</value>
        public DocumentSequenceViewModel DocumentSequenceDetail { get; set; }

        /// <summary>
        ///  Gets or sets a value indicating whether IsSingleTemplate.
        /// </summary>
        /// <value>Single Template Value.</value>
        public bool IsSingleTemplate { get; set; }

        /// <summary>
        ///  Gets or sets the value for DebitDocTemplate.
        /// </summary>
        /// <value>Debit Doc Template.</value>
        public string DebitDocTemplate { get; set; }

        /// <summary>
        ///  Gets or sets the value for CreditDocTemplate.
        /// </summary>
        /// <value>Credit Doc Template.</value>
        public string CreditDocTemplate { get; set; }

        #endregion Properties
    }
}