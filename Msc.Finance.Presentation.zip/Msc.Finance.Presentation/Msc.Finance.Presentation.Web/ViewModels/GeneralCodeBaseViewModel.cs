﻿//-----------------------------------------------------------------------
// <copyright file = "GeneralCodeBaseViewModel.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox
//   OneVision Project
// </copyright>
// <summary>This is the GeneralCodeView class.</summary>
//-----------------------------------------------------------------------
using System;

namespace Msc.Finance.Presentation.Web.ViewModels
{
    /// <summary>
    /// Class GeneralCodeBaseView.
    /// </summary>
    [Serializable]
    public class GeneralCodeBaseViewModel
    {
        /// <summary>
        /// Gets or sets the type of the code.
        /// </summary>
        /// <value>The type of the code.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the type of the code.
        /// </summary>
        /// <value>The type of the code.</value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }
    }
}