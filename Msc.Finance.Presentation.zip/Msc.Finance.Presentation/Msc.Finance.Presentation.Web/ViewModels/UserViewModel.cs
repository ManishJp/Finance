﻿//-----------------------------------------------------------------------
// <copyright file = "UserViewModel.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox
//   OneVision Project
// </copyright>
// <summary>This is the UserViewModel class.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System;

    /// <summary>
    /// Class UserViewModel.
    /// </summary>
    [Serializable]
    public class UserViewModel
    {
        /// <summary>
        /// Gets or sets the modified on.
        /// </summary>
        /// <value>The modified on.</value>
        public DateTime ModifiedOn { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>The created on.</value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the created by id.
        /// </summary>
        /// <value>The created by id.</value>
        public long CreatedById { get; set; }

        /// <summary>
        /// Gets or sets the name of the created by.
        /// </summary>
        /// <value>The name of the created by.</value>
        public string CreatedByName { get; set; }

        /// <summary>
        /// Gets or sets the modified by id.
        /// </summary>
        /// <value>The modified by id.</value>
        public long ModifiedById { get; set; }

        /// <summary>
        /// Gets or sets the name of the modified by.
        /// </summary>
        /// <value>The name of the modified by.</value>
        public string ModifiedByName { get; set; }
    }
}