﻿//-----------------------------------------------------------------------
// <copyright file="DocumentLineChargeViewModel.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox
//   OneVision Project 
// </copyright>
//-----------------------------------------------------------------------


namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System;

    [Serializable]
    public class DocumentLineChargeViewModel 
    {        
        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        /// <value>Country View Id.</value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets Code.
        /// </summary>
        /// <value>Country View Code.</value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets Description.
        /// </summary>
        /// <value>General Code View Description.</value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the ChargeDetail.
        /// </summary>
        /// <value>This property gets or sets the value of the ChargeDetail.</value>
        public ChargeCodeViewModel Charge { get; set; }

        /// <summary>
        ///  Gets or sets the value for BusinessCode.
        /// </summary>
        /// <value>Business Code.</value>
        public string BusinessCode { get; set; }

    }
}