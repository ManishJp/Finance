﻿//-----------------------------------------------------------------------
// <copyright file="DynamicAttributeDefinitionView.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox
//   OneVision Project 
// </copyright>
//-----------------------------------------------------------------------

namespace Msc.Finance.Presentation.Web.ViewModels
{

    using System;

    [Serializable]
    public class DynamicAttributeDefinitionViewModel
    {
        
        #region Properties

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets Code.
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the AttributeDetail.
        /// </summary>
        /// <value>This property gets the value of the AttributeDetail.</value>
        public GeneralCodeViewModel Attribute { get; set; }

        /// <summary>
        /// Gets or sets the ValidationDetail.
        /// </summary>
        /// <value>This property gets the value of the ValidationDetail.</value>
        public GeneralCodeViewModel Validation { get; set; }
        #endregion
    }
}