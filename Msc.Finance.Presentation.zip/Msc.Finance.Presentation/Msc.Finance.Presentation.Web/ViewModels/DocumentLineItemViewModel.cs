﻿//-----------------------------------------------------------------------
// <copyright file = "DocumentLineItemView.cs" company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox. OneVision Project.
// </copyright>
// <summary>Model Class For DocumentLineItemView.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Presentation.Web.ViewModels
{
    using System.Collections.Generic;
    using System;

    [Serializable]
    public class DocumentLineItemViewModel
    {
        #region Properties

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets Code.
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the LineItemAttributes.
        /// </summary>
        /// <value>This property gets or sets the value of the LineItemAttributes.</value>
        public IList<DynamicAttributeDefinitionViewModel> LineItemAttributes { get; set; }

        /// <summary>
        /// Gets or sets the DocumentLineCharges.
        /// </summary>
        /// <value>This property gets or sets the value of the DocumentLineCharges.</value>
        public IList<DocumentLineChargeViewModel> DocumentLineCharges { get; set; }

        #endregion
    }
}
