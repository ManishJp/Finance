﻿/*Modification History
Modified By,      Modified On,    Version No,     Reason
==========================================================

*/
var filterpanel = '<div id="FilterWrapper"></div>';
var container = $("#container");
$(function () {
    $('.navheader').click(function () {
        $(this).parent().children('ul.submenu').slideToggle(200);
    });
    TransactionButton(false, true, false, false, false, true, false);
    var fndPrgs, IniArr, i;
    fndPrgs = $("ul .submenu li a");
    IniArr = [];
    for (i = 0; i < fndPrgs.length; i++) {
        var getPrgsTitle = fndPrgs[i].getAttribute("title")
        var getPrgsId = fndPrgs[i].getAttribute("id");
        var program = { value: getPrgsTitle, data: getPrgsId };
        IniArr.push(program);
    }

    $('#menusearch').autocomplete({
        lookup: IniArr,
        onSelect: function (suggestion) {
            if ('#' + suggestion.data) {
                $('#' + suggestion.data).trigger('click');
            }
        }
    });

    var menu = $('ul .submenu li');
    $(menu).click(function (e) {
        if (!$(this).hasClass("has-ul")) {
            $("#redirect").append('<form action="' + $(this).find("a")[0].attributes['url'].value + '" id="URLSUBMIT" method="POST">');
            $("#redirect form").append('<input type="hidden" name="UserID" value=' + $("#UserID").val() + ' />');
            $("#redirect form").append('<input type="hidden" name="ouid" value=' + $("#OUID").val() + ' />');
            $("#redirect form").append('<input type="hidden" name="Menu" value=' + $("#MenuData").val() + ' />');
            $("#redirect form").append('</form>');
            $("#redirect form").submit();
        }

    });

    var createMenu = $('.jq-dropdown-menu li');
    $(createMenu).click(function (e) {
        e.preventDefault();
        var url = $(this)[0].attributes['url'].value;
        $.ajax({
            url: url,
            type: "GET",
            cache: false,
            dataType: 'html',
            success: function (partialData) {
                $("#innerContentHolder").html(partialData);
            },
            error: function (data) {
            }
        });
    });
    TransactionFilter = (function () {
        var id = "#FilterWrapper";
        var btnid = "#filter";
        var filterName = "filterName";
        var gridWrapperId = "#DataGrid";
        var GetGridName = function () {
            return $(gridWrapperId + " [data-role='grid']").attr("id");
        }
        var UpdateGridDataSource = function (data) {
            var grid = MSCJS.GetGrid(GetGridName());

            grid.dataSource.read(data);
        }
        var css = {
            appliedsearch: ".appliedsearch",
            searchcriteria: ".searchcriteria",
            button: ".k-button",
        }

        var lblvalue = {
            show: "SHOW FILTER",
            hide: "HIDE FILTER"
        }

        var FilterButtonValue = function (isShow) {
            var data = $(btnid).data("kendoButton")
            data.wrapper.context.lastChild.textContent = isShow ? lblvalue.show : lblvalue.hide;
        }

        var AppliedFilter = function () {
            if (window[filterName] && Object.keys(window[filterName]).length > 0) {
                var hasfilter = false;
                var exlst = $(id + " " + css.appliedsearch + " li");
                var child = [exlst[0]];
                $.each(window[filterName], function (i, lbl) {
                    // id = MSCJS.GetId(id);
                    if ($(id + " [name = '" + i + "']").val()) {
                        child.push(CreateFilterListTag(lbl, $(id + " [name = '" + i + "']").val()));
                        hasfilter = true;
                    }
                })
                child.push(exlst[exlst.length - 1]);
                $(id + " " + css.appliedsearch).html(child);
                // $(id + " " + css.appliedsearch)[hasfilter ? "show" : "hide"]();
            }
        }
        var Init = function () {
            $(id + " " + css.searchcriteria).show();
            $(id + " " + css.appliedsearch).hide();
            FilterButtonValue(false);
        }
        var Close = function () {
            $(id + " " + css.searchcriteria).hide();
            $(id + " " + css.appliedsearch)[$(id + " " + css.appliedsearch + " li").length > 2 ? "show" : "hide"]();
            FilterButtonValue(true);
        }
        return {
            AddFilter: function (id, lbl) {
                if (!window["filterName"]) {
                    window["filterName"] = {};
                }
                window["filterName"][id] = lbl;
            },
            ApplyFilter: function (e) {
                e.preventDefault();
                var kendoButton = $(e.event.target).closest(css.button).attr("id");
                var kendoButtonFn = window[kendoButton + "_Clicked"];
                if (typeof kendoButtonFn === "function") {
                    kendoButtonFn(e);
                } else {
                    UpdateGridDataSource($(id + " *").serializeFormJSON());
                    AppliedFilter();
                    Close();
                    //Ajax.RequestManager().Enqueue({
                    //    url: UrlHelper.Action('ApplyFilter'),
                    //    type: "GET",
                    //    data: $(id+ " *").serialize(),
                    //    cache: false,
                    //    dataType: 'html',
                    //    success: function (partialData) {
                    //       // FilterButtonValue(true);
                    //        AppliedFilter();
                    //        Close();
                    //        $(gridWrapperId).html(partialData);
                    //    },
                    //    error: function (data) {
                    //    }
                    //});
                }
            },
            ClearFilter: function (e) {
                e.preventDefault();
                Ajax.RequestManager().Enqueue({
                    url: UrlHelper.Action('DataFilters'),
                    type: "GET",
                    cache: false,
                    dataType: 'html',
                    success: function (partialData) {
                        $(id).html(partialData);
                        Init();
                    },
                    error: function (data) {
                    }
                });
            },
            ClearAppliedFilter: function (e) {
                e.preventDefault();
                $(id + " " + css.searchcriteria).html("");
                //$(id).html("");
                // TransactionFilter.ApplyFilter(e);
                UpdateGridDataSource();
                AppliedFilter();
                Close();
            },
            GetFilter: function (e) {
                if ($(id + " " + css.searchcriteria).is(":visible")) {
                    Close();
                }
                else if ($(id + " " + css.searchcriteria) && $(id + " " + css.searchcriteria).html() && $(id + " " + css.searchcriteria).length > 0) {
                    Init();
                }
                else {
                    Ajax.RequestManager().Enqueue({
                        url: UrlHelper.Action('DataFilters'),
                        type: "GET",
                        cache: false,
                        dataType: 'html',
                        success: function (partialData) {
                            $(id).html(partialData);
                            $(id).show();
                            Init();
                        },
                        error: function (data) {
                        }
                    });
                }
            }
        }
    }());
});

function ReloadInitial() {
    Ajax.RequestManager().Enqueue({
        url: UrlHelper.Action('Close'),
        type: "POST",
        cache: false,
        dataType: 'html',
        success: function (partialData) {
            TransactionButton(false, true, false, false, false, true, false);
            AddFilterValue("SHOW FILTER");
            $("#container").html(filterpanel + partialData);
            $("#window_AboutInforamtion_btn").addClass("hidden")
        },
        error: function (data) {
        }
    });
}

function Save(e) {
    e.preventDefault();
    var kendoButton = $(e.event.target).closest(".k-button").attr("id");
    var kendoButtonFn = window[kendoButton + "_Clicked"];
    if (typeof kendoButtonFn === "function") {
        kendoButtonFn(e);
    } else {
        var msg = Validation.IsValidAndFocus({ ContainerId: "form1" });
        if (msg.length == 0) {
            Ajax.RequestManager().Enqueue({
                url: UrlHelper.Action('Save'),
                type: "POST",
                data: $("#container *").serialize(),
                cache: false,
                dataType: 'html',
                success: function (partialData) {
                    if (partialData.type != 'E') {
                        ReloadInitial();
                        MSCJS.Message.ShowInformation(partialData.title, partialData.message);
                    }
                    else {
                        MSCJS.Message.ShowError(partialData.title, partialData.message);
                    }
                },
                error: function (data) {
                }
            });
        }
        else {
            MSCJS.Message.MessageBox("Error", msg[0].ErrorMessage, { text: 'OK', action: function () { msg[0].FocusId ? Validation.ValidationFocus(msg[0].FocusId) : '' }, css: '' });
        }
    }
}

function ClearData() {
    Ajax.RequestManager().Enqueue({
        url: UrlHelper.Action('Clear'),
        type: "POST",
        cache: false,
        dataType: 'html',
        success: function (partialData) {
            TransactionButton(true, false, false, true, true, false, false);
            $("#container").html(partialData);
            $("#msgBox").data("kendoWindow").close();
        },
        error: function (partialData) {
        }
    });
}

function Clear(e) {
    e.preventDefault();
    var kendoButton = $(e.event.target).closest(".k-button").attr("id");
    var kendoButtonFn = window[kendoButton + "_Clicked"];
    if (typeof kendoButtonFn === "function") {
        kendoButtonFn(e);
    } else {
        YesNoMessageBox(e, "Do you want to clear?", "ClearData");
    }
}

function Delete(e) {
    var kendoButton = $(e.event.target).closest(".k-button").attr("id");
    var kendoButtonFn = window[kendoButton + "_Clicked"];
    if (typeof kendoButtonFn === "function") {
        kendoButtonFn(e);
    } else {
        e.preventDefault();
        Ajax.RequestManager().Enqueue({
            url: "Delete",
            type: "POST",
            cache: false,
            dataType: 'html',
            success: function (partialData) {
                $("#container").html(partialData);
            },
            error: function (partialData) {
            }
        });
    }
}
function Edit(e) {
    e.preventDefault();
    var kendoButton = $(e.event.target).closest(".k-button").attr("id");
    var kendoButtonFn = window[kendoButton + "_Clicked"];
    if (typeof kendoButtonFn === "function") {
        kendoButtonFn(e);
    } else {
        Ajax.RequestManager().Enqueue({
            url: UrlHelper.Action('Edit') + "?Id=" + $("#Id").val(),
            type: "GET",
            cache: false,
            dataType: 'html',
            success: function (data) {
                if (data.type) {
                    MSCJS.Message.ShowMessage(data.type, data.title, data.message);
                }
                else {
                    $("#window_AboutInforamtion_btn").addClass("hidden")
                    gridProperties.isQuery = false;
                    TransactionButton(true, false, false, true, false, false, false);
                    $("#container").html(data);
                }
            },
            error: function (data) {
            }
        });
    }
}
function Cancel(e) {
    e.preventDefault();
    var kendoButton = $(e.event.target).closest(".k-button").attr("id");
    var kendoButtonFn = window[kendoButton + "_Clicked"];
    if (typeof kendoButtonFn === "function") {
        kendoButtonFn(e);
    } else {
        YesNoMessageBox(e, "Do you want to Cancel?", "ReloadInitial");
    }
}
function Create(e) {
    e.preventDefault();
    var kendoButton = $(e.event.target).closest(".k-button").attr("id");
    var kendoButtonFn = window[kendoButton + "_Clicked"];
    if (typeof kendoButtonFn === "function") {
        kendoButtonFn(e);
    } else {
        Ajax.RequestManager().Enqueue({
            url: UrlHelper.Action('Create'),
            type: "GET",
            cache: false,
            dataType: 'html',
            success: function (partialData) {
                TransactionButton(true, false, false, true, true, false, false);
                $("#container").html(partialData);
                gridProperties.isQuery = false;
            },
            error: function (data) {
            }
        });
    }
}
function ClearFilter(e) {
    e.preventDefault();
    Ajax.RequestManager().Enqueue({
        url: UrlHelper.Action('DataFilters'),
        type: "GET",
        cache: false,
        dataType: 'html',
        success: function (partialData) {
            $('#FilterWrapper').html(partialData);
        },
        error: function (data) {
        }
    });
}
function AddFilterValue(value) {
    var data = $("#filter").data("kendoButton")
    data.wrapper.context.lastChild.textContent = value;
}
function ApplyFilter(e) {
    e.preventDefault();
    var kendoButton = $(e.event.target).closest(".k-button").attr("id");
    var kendoButtonFn = window[kendoButton + "_Clicked"];
    if (typeof kendoButtonFn === "function") {
        kendoButtonFn(e);
    } else {
        Ajax.RequestManager().Enqueue({
            url: UrlHelper.Action('ApplyFilter'),
            type: "GET",
            data: $("#FilterWrapper *").serialize(),
            cache: false,
            dataType: 'html',
            success: function (partialData) {
                //$('#FilterWrapper').removeClass('visible').animate({ 'display': 'block !important' });
                //AddFilterValue("SHOW FILTER");
                $("#DataGrid").html(partialData);
            },
            error: function (data) {
            }
        });
    }
}

function GetFilter() {
    if ($('#FilterWrapper').hasClass("visible")) {
        $('#FilterWrapper').removeClass('visible').animate({ 'display': 'none !important' });
        $('#FilterWrapper').hide();
        AddFilterValue("SHOW FILTER");
    } else {
        $('#FilterWrapper').addClass('visible').animate({ 'display': 'block !important' });
        //if ($('#FilterWrapper') && $('#FilterWrapper').html() == "") {
        Ajax.RequestManager().Enqueue({
            url: UrlHelper.Action('DataFilters'),
            type: "GET",
            cache: false,
            dataType: 'html',
            success: function (partialData) {
                $('#FilterWrapper').html(partialData);
            },
            error: function (data) {
            }
        });
        //}
        AddFilterValue("HIDE FILTER");
    }
}

function TransactionButton(isSave, isCreate, isEdit, isCancel, isClear, isFilter, isDeactivate) {
    ButtonAction("#save", isSave);
    ButtonAction("#create", isCreate);
    ButtonAction("#edit", isEdit);
    ButtonAction("#cancel", isCancel);
    ButtonAction("#clear", isClear);
    ButtonAction("#filter", isFilter);
    ButtonAction("#deactivate", isDeactivate);
}

function ButtonAction(id, show) {
    $(id)[show ? 'show' : 'hide']();
}
function TreeView(e) {
    e.preventDefault();
    $.ajax({
        url: "TreeView",
        type: "GET",
        cache: false,
        dataType: 'html',
        success: function (partialData) {
            $('#container').html(partialData);
        },
        error: function (data) {
        }
    });

}

function SetTitleText(map, title) {
    $('.crumbs').text(map);
    $('#titlebarheader').html(title);
}
function YesNoMessageBox(e, message, yesAction) {
    if ($("#msgBox").length !== 0) {
        $("#msgBox").remove();
    }
    var div = document.createElement("DIV");
    div.setAttribute('id', 'msgBox');

    $(div).appendTo("body");

    var ConformWindow = $(div).kendoWindow({
        title: "Confirm",
        resizable: false,
        width: 300,
        height: 100,
        modal: true
    });
    ConformWindow.data("kendoWindow").wrapper.addClass('windowwidth2');
    ConformWindow.data("kendoWindow")
        .content('<p class="clear-message">' + message + '</p>' +
                    '<div class="window-footer buttonctr pull-right"><button class="clear-confirm k-button" onclick="' + yesAction + '()">Yes</button>' +
                    '<button class="clear-cancel k-button">No</button></div>')
        .center().open();
    ConformWindow.find(".clear-confirm,.clear-cancel")
        .click(function () {
            ConformWindow.data("kendoWindow").close();
        }).end()
}
function AboutInformation() {
    if ($("#window_AboutInforamtion") && $("#window_AboutInforamtion").length > 0) {
        var window = MSCJS.GetWindow("window_AboutInforamtion");
        window.open();
    }
}
