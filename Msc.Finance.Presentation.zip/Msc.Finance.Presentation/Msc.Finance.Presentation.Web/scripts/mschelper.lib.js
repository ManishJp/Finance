﻿/*global window,alert*/
(function MSCJSLIB(w) {
    w.MSCJS = (function () {
        var clfn = function () {
            return (function (e, fn) { if (fn) { return MSCJS.Common.Helper.ExecuteMethod(fn, [e]); } });
        };
        var clfn = function (fn) {
            return (function (e) { if (fn) { return MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id+fn, [e]); } });
        };
        return {
            GetGrid: function (id) {
                return $(MSCJS.GetId(id)).data('kendoGrid');
            },
            GetComboBox: function (id) {
                return $(MSCJS.GetId(id)).data('kendoComboBox');
            },
            GetDatePicker: function (id) {
                return $(MSCJS.GetId(id)).data('kendoDatePicker');
            },
            GetDateTimePicker: function (id) {
                return $(MSCJS.GetId(id)).data('kendoDateTimePicker');
            },
            GetWindow: function (id) {
                return $(MSCJS.GetId(id)).data('kendoWindow');
            },
            GetPopUp: function (id) {
                return {
                    Component: function () {
                        return $(MSCJS.GetId(id)).data('kendoWindow')
                    },
                    Center: function () {
                        this.Component().center();
                    },
                    Show: function () {
                        this.Component().open();
                    },
                    Hide: function () {
                        this.Component().close();
                    }
                }
            },
            GetAutoComplete: function (id) {
                return {
                    Component: function () {
                        return $(MSCJS.GetId(id)).data('kendoAutoComplete')
                    },
                    SelectedItem: function () {
                        var me = this.Component();
                        if (me) { return me.dataItem(me.select()); }
                        return {};
                    }
                }
            },
            GetNumericTextBox: function (id) {
                return {
                    Component: function () {
                        return $(MSCJS.GetId(id)).data('kendoNumericTextBox')
                    },
                    Value: function () {
                        var me = this.Component();
                        if (me) { return me.val(); }
                        return 0;
                    }
                }
            },
            DatePicker: function (id) {
                return {
                    Component: function () {
                        return $(MSCJS.GetId(id)).data('kendoDatePicker')
                    },
                    MinDate: function (value) {
                        value = value ? value : new Date(1000, 01, 01);
                        this.Component() ? this.Component().min(value) : this.Component();
                    },
                    MaxDate: function (value) {
                        value = value ? value : new Date(2099, 12, 31);
                        this.Component() ? this.Component().max(value) : this.Component();
                    },
                }
            },
            ComboBox: function (id) {
                return {
                    Component: function () {
                        return $(MSCJS.GetId(id)).data('kendoComboBox')
                    },
                    Clear: function () {
                        this.Component().value('');
                        this.Component().text('');
                        this.Component().dataSource.read();
                    },
                    SelectedItem: function () {
                        var me = this.Component();
                        if (me) { return me.dataItem(); }
                        return {};
                    },
                    Set: function (v, t) {
                        this.Value(v);
                        this.Text(t);
                    },
                    Value: function (v) {
                        var me = this.Component();
                        if (me) {
                            if (v) { me.value(v); }
                            return me.value();
                        }
                        return 0;
                    },
                    Text: function (v) {
                        var me = this.Component();
                        if (me) {
                            if (v) { me.text(v); }
                            return me.text();
                        }
                        return 0;
                    },
                    SetSelectedItem: function (item) {
                        var me = this.Component();
                        if (me) {
                            var index = me.dataSource.add(item);
                            me.select(index);
                            return index;
                        }
                        return !1;
                    },
                    SetDataSource: function (data) {
                        var me = this.Component();
                        if (me) { me.dataSource.data(data); }
                    },
                }
            },
            Toggle: function (id) {
                return {
                    Checkbox: function () {
                        return $("#cmn_toggle_" + id);
                    },
                    disable: function () {
                        this.Checkbox().prop("disabled", true);
                    },
                    enable: function () {
                        this.Checkbox().prop("disabled", false);
                    },
                    value: function (v) {
                        if (v) {
                            $(MSCJS.GetId(id)).val(v);
                            this.Checkbox().prop("checked", v);
                        }
                        return this.Checkbox().prop("checked", v);
                    }
                }
            },
            GetId: function (id) {
                if (typeof (id) == 'string' && id[0] != '#')
                    id = '#' + id
                return id;
            },
            GetClass: function (classname) {
                if (typeof (classname) == 'string' && classname[0] != '.')
                    classname = '.' + classname
                return classname;
            },
            Custombehaviour: {
                canAllow: true,
                NumericTextBox: function () {
                    $("[data-role=numerictextbox]").each(function () {
                        var value = $(this).val();
                        if (value == "0") {
                            $(this).data("kendoNumericTextBox").value("")
                        }
                    })
                },
                DatePicker: function () {
                    $("[data-role=datepicker]").each(function () {
                        var value = $(this).val();
                        if (value == "01-Jan-0001") {
                            $(this).val(" ");
                        }
                    });
                    $("[data-role=datepicker]").on("change", function (e) {
                        var datePicker = $(e.currentTarget).data("kendoDatePicker");
                        var currentDate = kendo.parseDate(datePicker.wrapper.context.value.trim(), datePicker.options.format);
                        if (!currentDate || currentDate == "Invalid Date" || datePicker.wrapper.context.value.trim().length !== datePicker.options.format.length) {
                            datePicker.wrapper.context.value = "";
                        }
                        else {
                            if (datePicker.options.min && datePicker.options.max) {
                                if (new Date(datePicker.wrapper.context.value) < new Date(datePicker.options.min).setHours(0, 0, 0, 0, 0) || new Date(datePicker.wrapper.context.value) > datePicker.options.max.setHours(0, 0, 0, 0, 0)) {
                                    datePicker.wrapper.context.value = "";
                                }
                            }
                        }
                    });
                },
                ComboBox: function () {
                    $("[data-role=combobox]").on("focusout", function (e) {
                        var combobox = $(e.currentTarget).data("kendoComboBox");
                        if ((combobox.selectedIndex === 'undefined' || combobox.selectedIndex === -1) && combobox.text() !== combobox.options.text) {
                            if (combobox.text())
                                combobox.text('');
                            if (combobox.value())
                                combobox.value('');
                        }
                    });
                },
                AcceptNumber: function () {
                    $('.onlynumber [data-role="numerictextbox"]').each(function () {
                        var data = $(this).data("kendoNumericTextBox");
                        data.options.decimals = 0;
                    });
                    $('.onlynumber [data-role="numerictextbox"]').bind('input', function () {
                        this.value = this.value.replace(/[^0-9]/g, '')
                    });
                },
                Execute: function () {
                    if (this.canAllow) {
                        this.All();
                    }
                },
                All: function () {
                    this.AcceptNumber();
                    this.ComboBox();
                    this.DatePicker();
                    this.NumericTextBox();
                }
            },
            Constants: {
                FileUpload: {
                    FileExtenstion: {
                        None: 'None',
                        All: 'all',
                        // PDF: 'pdf',
                        Excel: {
                            All: 'excel',
                            XLS: 'xls',
                            XLSX: 'xlsx'
                        },
                        Word: {
                            All: 'word',
                            DOCX: 'docx',
                            DOC: 'doc'
                        },
                        Image: {
                            All: 'image',
                            JPEG: 'jpeg',
                            JPG: 'jpg',
                            GIF: 'gif',
                            PNG: 'png'
                        }
                    }
                },
                WindowHelper: {
                    Css: {
                        Overlay: "k-overlay"
                    }
                },
                Message: {
                    Css: {
                        Warning: 'icon-warning',
                        Error: 'icon-cross',
                        Information: 'icon-error',
                        LeftCtr: 'ovmessageleft icon',
                        RightCtr: 'ovmessageright',
                        ContentCtr: 'ovmessagecontent',
                        MessageCtr: 'message dialogDetailContent',
                        AdditonalCtr: 'additonal dialogDetailContent',
                        InnerCtr: 'inner dialogDetailContent',
                        dialog: 'windowwidth2',
                        ButtonCtr: 'window-footer buttonctr pull-right',
                        OkButtonClass: 'k-button mar10',
                        CancelButtonClass: 'k-button hidden cancel mar10',
                        MailButtonClass: 'k-button hidden mar10',
                        IcnText: 'blue'
                    }
                }
            },
            InvokeClient: function (entity, event, args, scope) {
                var s = scope ? scope : window;
                this.HTMLHelpers.ClientEvents[entity][event].apply(s, args);
            },
            InvokeDetailclientFn: function (entity, event, args, scope) {
                var s = scope ? scope : window;
                this.HTMLHelpers.DetailGrid[entity][event].apply(s, args);
            },
            Common: {
                Helper: {
                    GetMethod: function (method) {
                        if (typeof method === 'string') { return w[method]; }
                        return method;
                    },
                    CheckIfMethodExist: function (m) {
                        return (typeof m === 'function');
                    },
                    CheckIfMethodExistFromName: function (m) {
                        return (typeof this.GetMethod(m) === 'function');
                    },
                    ExecuteMethod: function (method, args, scope, ou) {
                        if (!ou) { ou = []; }
                        var fn = this.GetMethod(method);
                        if (this.CheckIfMethodExist(fn)) {
                            if (scope) { return fn.apply(scope, args); }
                            ou["isExecuted"] = true;
                            return fn.apply(w, args);
                        }
                        else { ou["isExecuted"] = false; }
                    }
                }
            },
            Message: {
                YesNoMessageBox: function (e, message, yesAction) {
                    if ($("#msgBox").length !== 0) {
                        $("#msgBox").remove();
                    }
                    var div = document.createElement("DIV");
                    div.setAttribute('id', 'msgBox');

                    $(div).appendTo("body");

                    var ConformWindow = $(div).kendoWindow({
                        title: "Confirm",
                        resizable: false,
                        width: 300,
                        height: 100,
                        modal: true
                    });
                    ConformWindow.data("kendoWindow").wrapper.addClass('windowwidth2');
                    ConformWindow.data("kendoWindow")
                        .content('<p class="clear-message">' + message + '</p>' +
                                    '<div class="window-footer buttonctr pull-right"><button class="clear-confirm k-button" onclick="' + yesAction + '()">Ok</button>' +
                                    '<button class="clear-cancel k-button">Cancel</button></div>')
                        .center().open();
                    ConformWindow.find(".clear-confirm,.clear-cancel")
                        .click(function () {
                            ConformWindow.data("kendoWindow").close();
                        }).end()
                },
                MessageBox: function (title, message) {
                    if ($("#msgBox").length !== 0) { $("#msgBox").remove(); }
                    var div = document.createElement("DIV");
                    div.setAttribute('id', 'msgBox');
                    $(div).appendTo("body");
                    var ConformWindow = $(div).kendoWindow({
                        title: title || 'Message',
                        resizable: false,
                        width: 300,
                        height: 100,
                        modal: true
                    });
                    var binders = [];
                    var content = '<p class="clear-message">' + message + '</p><div class="window-footer buttonctr pull-right">', i = 2;
                    for (; i < arguments.length; i++) {
                        var arg = arguments[i];
                        if (arg && typeof (arg) === typeof ({})) {
                            var btn = document.createElement("button");
                            btn.className = arg.css || (!arg.isClose ? 'clear-confirm' : 'clear-cancel');
                            btn.className += ' k-button'
                            btn.textContent = arg.text || 'OK';
                            btn.type = 'button';
                            btn.id = arg.text + '_btn_info';
                            content += btn.outerHTML;
                            binders.push({
                                id: '#' + btn.id,
                                fn: function () {
                                    if (arg.action) {
                                        arg.isClose = arg.action(ConformWindow);
                                    }
                                    if (arg.isClose) {
                                        ConformWindow.data("kendoWindow").close();
                                    }
                                }
                            });
                        }
                        content += '</div>';
                    };
                    ConformWindow.data("kendoWindow").wrapper.addClass('windowwidth2');
                    ConformWindow.data("kendoWindow")
                        .content(content)
                        .center().open();
                    ConformWindow.find(".clear-confirm,.clear-cancel")
                        .click(function () {
                            ConformWindow.data("kendoWindow").close();
                        }).end()
                    binders.forEach(function (v) { $(v.id).click(v.fn); })
                },
                ShowError: function (title, msg, innerMessage, additionalMessage) {
                    this.ShowDialog(MSCJS.Constants.Message.Css.Error, title, msg, innerMessage, additionalMessage);
                },
                ShowInformation: function (title, msg, innerMessage, additionalMessage, innerMessage, additionalMessage) {
                    this.ShowDialog(MSCJS.Constants.Message.Css.Information, title, msg);
                },
                ShowWarning: function (title, msg, innerMessage, additionalMessage, innerMessage, additionalMessage) {
                    this.ShowDialog(MSCJS.Constants.Message.Css.Warning, title, msg);
                },
                ShowDialog: function (cssclass, title, msg, innerMessage, additionalMessage) {
                    this.Intialize();
                    var win = $("#dialog").data("kendoWindow");
                    win.wrapper.addClass(MSCJS.Constants.Message.Css.dialog);
                    win.content(this.MessageDiv(cssclass, msg, innerMessage, additionalMessage));
                    this.AdditionalMessage();
                    this.InnerMessage();
                    win.title(title);
                    win.open().center();
                },
                Intialize: function () {
                    if (!$("#dialog").data("kendoWindow")) {
                        var data = $("#dialog").kendoWindow({
                            draggable: true,
                            modal: true,
                            resizable: false,
                            visible: false,
                            title: "",
                            width: "",
                        }).data("kendoWindow");
                    }
                },
                ShowMessage: function (type, title, msg, innerMessage, additionalMessage) {
                    if (type === 'W') {
                        if (!title) title = "Warning";
                        this.ShowDialog(MSCJS.Constants.Message.Css.Warning, title, msg, innerMessage, additionalMessage);
                    }
                    else if (type === 'E') {
                        if (!title) title = "Error";
                        this.ShowDialog(MSCJS.Constants.Message.Css.Error, title, msg, innerMessage, additionalMessage);
                    }
                    else if (type === 'I') {
                        if (!title) title = "Information";
                        this.ShowDialog(MSCJS.Constants.Message.Css.Information, title, msg, innerMessage, additionalMessage);
                    }
                },
                AdditionalMessage: function () {
                    var icon = $("#additionalIcon");
                    if ($("#additionalInfo").length > 0) {
                        $("#additionalInfo").slideToggle();
                        icon[0].innerHTML = icon[0].innerHTML.indexOf("-") > -1 ? "+ View More" : "- View More";
                    }
                },
                InnerMessage: function () {
                    var icon = $("#viewDetailsIcon");
                    if ($("#viewDetail").length > 0) {
                        $("#viewDetail").slideToggle();
                        icon[0].innerHTML = icon[0].innerHTML.indexOf("-") > -1 ? "+ View Details" : "- View Details";
                    }
                },
                MessageDiv: function (typecss, msg, innerMessage, additionalMessage) {
                    var newLine = "<div class=\"clearfix\" />";
                    var additionalDetail, additionalIcn, MessageDiv, msgCntTag, msgCntTagClose, msgTextTag, msgTextTagClose, buttonDiv;
                    MessageDiv = "<div class=\"" + MSCJS.Constants.Message.Css.MessageCtr + "\">";
                    MessageDiv += "<i class=\"" + MSCJS.Constants.Message.Css.LeftCtr + " " + typecss + "\" >&nbsp</i>";
                    MessageDiv += "<div class=\"" + MSCJS.Constants.Message.Css.RightCtr + "\">";

                    buttonDiv = "<div class=\"" + MSCJS.Constants.Message.Css.ButtonCtr + "\">";
                    buttonDiv += "<input type='button' value='Ok' onclick='MSCJS.Message.DialogOk()' class=\"" + MSCJS.Constants.Message.Css.OkButtonClass + " \" />";
                    buttonDiv += "<input type='button' value='Mail' onclick='MSCJS.Message.DialogMail()' class=\"" + MSCJS.Constants.Message.Css.MailButtonClass + " \" />";
                    buttonDiv += "<input type='button' value='Cancel' onclick='MSCJS.Message.DialogCancel()' class=\"" + MSCJS.Constants.Message.Css.CancelButtonClass + " \" />";
                    buttonDiv += "</div>"

                    msgCntTag = "<div id='messageContent'>";
                    msgCntTagClose = "</div>";

                    msgTextTag = "<div id='msgIcon' /><div id='messageText' class=\"" + MSCJS.Constants.Message.Css.ContentCtr + "\">" + msg;
                    msgTextTagClose = "</div>";

                    if (additionalMessage) {
                        additionalIcn = "<div id='additionalIcon' class=\"" + MSCJS.Constants.Message.Css.IcnText + "\" onclick='MSCJS.Message.AdditionalMessage()'>- View More</div>";
                        additionalDetail = "<div id='additionalInfo' class=\"" + MSCJS.Constants.Message.Css.AdditonalCtr + "\">" + additionalMessage + "</div>";
                        msgTextTag += additionalIcn + additionalDetail;
                    }
                    msgCntTag += newLine + msgTextTag + msgTextTagClose;

                    if (innerMessage) {
                        viewDetail = "<div id='viewDetail' class=\"" + MSCJS.Constants.Message.Css.InnerCtr + "\">" + innerMessage + "</div>";
                        viewIcon = "<div id='viewIcon' /><div  id='viewDetailsIcon' class=\"" + MSCJS.Constants.Message.Css.IcnText + "\"  onclick='MSCJS.Message.InnerMessage()'>- View Details</div>";
                        msgCntTag += newLine + viewIcon + viewDetail;
                    }

                    MessageDiv += newLine + msgCntTag + msgCntTagClose;

                    MessageDiv += "</div>" + buttonDiv + "</div>";
                    return MessageDiv;
                },
                DialogOk: function () {
                    $("#dialog").data("kendoWindow").close();
                    if ($("#dialogctr").hasClass(MSCJS.Constants.WindowHelper.Css.Overlay)) {
                        $("#dialogctr").removeClass(MSCJS.Constants.WindowHelper.Css.Overlay);
                    }
                },
                DialogCancel: function () {
                    $("#dialog").data("kendoWindow").close();
                    if ($("#dialogctr").hasClass(MSCJS.Constants.WindowHelper.Css.Overlay)) {
                        $("#dialogctr").removeClass(MSCJS.Constants.WindowHelper.Css.Overlay);
                    }
                },
                DialogMail: function () {
                },
                Format: function () {
                    var s = arguments[0], i = 1;
                    for (; i < arguments.length; i += 1) {
                        var reg = new RegExp("\\{" + (i - 1) + "\\}", "gm");
                        s = s.replace(reg, arguments[i]);
                    }
                    return s;
                },
            },
            Resources: {
                WrongFileFormat: function () {
                    return 'Please select a file with {0} file format. The selected ext is ';
                },
                AcceptWordFileFormat: function () {
                    return MSCJS.Message.Format(this.WrongFileFormat(), 'Word');
                },
                AcceptExcelFileFormat: function () {
                    return MSCJS.Message.Format(this.WrongFileFormat(), 'Excel');
                },
                AcceptImageFileFormat: function () {
                    return MSCJS.Message.Format(this.WrongFileFormat(), 'Image');
                },
                AcceptPDFFileFormat: function () {
                    return MSCJS.Message.Format(this.WrongFileFormat(), 'PDF');
                },
                Authorization: function () {
                    return 'Authorization required for this action!';
                },
            },
            HTMLHelpers: {
                ClientEvents: {
                    FileUpload: {
                        OnFileSelect: (function (e, clientFn, fileExt) {
                            var cns = MSCJS.Constants.FileUpload.FileExtenstion;

                            //Converts string to lower case and checks with rhs
                            var ctlnv = function ConvertToLowerCaseAndValidate(f, rhs) { return f.toLowerCase() === rhs; };

                            if (MSCJS.Common.Helper.CheckIfMethodExist(clientFn)) {
                                MSCJS.Common.Helper.ExecuteMethod(clientFn, [s, fileExt]);
                            }
                            else if (fileExt && fileExt !== cns.None) {
                                var extension = e.files[0].extension; // To get Extension of select Files.
                                extension = extension.substring(1); // Remove the (.) from Extension.

                                if (ctlnv(fileExt, cns.All)) {
                                    return true;
                                }
                                else if (cns.hasOwnProperty(fileExt.capitalizeFirstLetter())) {
                                    if (!cns[fileExt.capitalizeFirstLetter()].hasOwnProperty(extension.toUpperCase())) {
                                        MSCJS.Message.ShowError(MSCJS.Message.Format(MSCJS.Resources.WrongFileFormat() + extension, fileExt.capitalizeFirstLetter()));
                                        e.preventDefault();
                                        return false;
                                    }
                                }
                                else if (fileExt.toLowerCase() !== extension) {
                                    alert("Please Select " + fileExt + " File only. The selected ext is " + extension);
                                    e.preventDefault();
                                    return false;
                                }
                            }
                        }),
                        OnFileCancel: clfn(),
                        OnFileError: clfn(),
                        OnFileProgress: clfn(),
                        OnFileRemove: clfn(),
                        OnFileComplete: clfn(),
                        OnFileUpload: clfn(),
                        OnFileSuccess: clfn(),
                    },
                    ComboBox: {
                        OnComboBoxChange: function (s, clientFn, prefix, displayname) {
                            if (s.sender && s.sender.selectedIndex > -1) {
                                var displayFields = displayname ? displayname.split("|").trim() : [];
                                // displayFields = displayFields.trim();
                                var selectedItems = s.sender.dataSource._data[s.sender.selectedIndex];
                                var currentId, currentName, html = "", currentHtml;
                                if (displayFields.indexOf(s.sender.options.dataTextField) < 0) {
                                    displayFields.push(s.sender.options.dataTextField);
                                }
                                if (selectedItems && displayFields) {
                                    s.sender.element.parent().find('.k-input').attr('title', selectedItems[s.sender.options.dataTextField]);
                                    var model = {};
                                    for (var i = 0; i < displayFields.length; i++) {
                                        if (s.sender.options.dataValueField.trim() != displayFields[i].trim()) {
                                            currentId = prefix + "." + displayFields[i].trim();
                                            currentId = currentId.replace(/\./g, '_');
                                            currentHtml = $("#" + currentId);
                                            if (currentHtml.length) {
                                                currentHtml.val(selectedItems["" + displayFields[i] + ""]);
                                            }
                                            else {
                                                html += "<input type=\"hidden\" name=\"" + currentId.replace(/\_/g, '.') + "\" value=\"" + selectedItems["" + displayFields[i] + ""] + "\" >";
                                            }
                                        }
                                    }
                                    if ($("#" + s.sender.element[0].id + "spn").length > 0 && html) {
                                        $("#" + s.sender.element[0].id + "spn")[0].innerHTML = html;
                                    };
                                }
                            }
                            MSCJS.Common.Helper.ExecuteMethod(clientFn, [s]);
                        },
                        OnSelect: clfn(),
                        OnOpen: (function (s, clientFn, dropdownvalue) {
                            //Used to set the dropdown Width of Combobox
                            if (dropdownvalue) {
                                s.sender.list.width(dropdownvalue);
                            }
                            if (s.sender.dataSource && s.sender.dataSource._total <= 0) {
                                s.preventDefault();
                            }
                            if (s.sender.options.minLength > 0) {
                                if (s.sender.dataSource.filter() && s.sender.dataSource.filter().filters[0] && s.sender.dataSource.filter().filters[0].value) {
                                    if (s.sender.options.minLength > s.sender.dataSource.filter().filters[0].value.length) {
                                        s.preventDefault();
                                    }
                                }
                                else {
                                    s.preventDefault();
                                }
                            }
                            MSCJS.Common.Helper.ExecuteMethod(clientFn, [s]);
                        }),
                        OnClose: clfn(),
                        FormatValue: function (comboxSetting, text) {
                        },
                        OnDataBound: (function (s, clientFn) {
                            if (s.sender.list.children() && s.sender.list.children().length > 1 && s.sender.list.children()[1] && s.sender.list.children()[1].children.length > 1) {
                                if (s.sender.dataSource.total() > 5) {
                                    s.sender.list.height("170px");
                                    s.sender.list.children()[1].children[1].style.height = "133px";
                                }
                                else {
                                    s.sender.list.height("");
                                    s.sender.list.children()[1].children[1].style.height = "";
                                }
                            }
                            $(s.sender.items()).each(function (index, item) {
                                $(item).attr("title", item.textContent);
                            });
                            $.each($("#" + s.sender.wrapper.context.id + "-list .widgetItem"), function (e) {
                                var innerValue = this.innerHTML;
                                innerValue = innerValue.replace(/<\/?span[^>]*>/g, "");
                                var filterText = "";
                                if (s.sender.dataSource.filter() && s.sender.dataSource.filter().filters[0] && s.sender.dataSource.filter().filters[0].value)
                                    filterText = s.sender.dataSource.filter().filters[0].value;
                                var textMatcher = new RegExp(filterText, "ig");
                                var innerValue = innerValue.replace(textMatcher, function (match) {
                                    return '<span class="fontbold">' + match + '</span>';
                                });
                                this.innerHTML = innerValue
                            })
                            MSCJS.Common.Helper.ExecuteMethod(clientFn, [s]);
                        }),
                        OnFiltering: clfn(),
                    },
                    DatePicker: {
                        open: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_Open', [e]);
                        },
                        close: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_Close', [e]);
                        },
                        change: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_Change', [e]);
                        }
                    },
                    TimePicker: {
                        open: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_Open', [e]);
                        },
                        close: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_Close', [e]);
                        },
                        change: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_Change', [e]);
                        }
                    },
                    Grid: {
                        FilterToggle: (function (s) {
                            $('#' + s + ' .k-filter-row').toggle();
                            var datepicker = $('#' + s + ' .k-filter-row .k-filtercell .k-datepicker .k-input');
                            $.each(datepicker, function (i, v) {
                                var dateTimePicker = $(v).data("kendoDatePicker");
                                var currentFormat = DefaultFormat.GetDate();
                                dateTimePicker.options.format = currentFormat
                                dateTimePicker.options.parseFormats.push(currentFormat)
                            });
                            return false;
                        }),
                        ExcelExport: (function (e) {
                            var sheet = e.workbook.sheets[0];
                            for (var rowIndex = 1; rowIndex < sheet.rows.length; rowIndex++) {
                                var row = sheet.rows[rowIndex];
                                for (var cellIndex = 0; cellIndex < row.cells.length; cellIndex++) {
                                    if ($.type(row.cells[cellIndex].value) === $.type(new Date())) {
                                        year = row.cells[cellIndex].value.getFullYear();
                                        if (year != "0001") {
                                            row.cells[cellIndex].format = "dd-MMM-yyyy"
                                        }
                                        else {
                                            row.cells[cellIndex].value = "";
                                        }
                                    }
                                }
                            }
                        }),
                        OnGridEdit: (function (e) {
                            var cmb = e.container.find('[data-role="combobox"]').data('kendoComboBox');
                            if (cmb) {
                                cmb.bind("change", function (evt) {
                                    e.model.set("StateInfo", cmb.dataItem(this.select()));
                                });
                            }
                        }),
                        OnCallBack: clfn(),
                        OnGridDataBind: function (s, clientFn) {
                            var gridName = s.sender.element[0].id;
                            $('#' + gridName + ' .k-filter-row').hide();
                            MSCJS.HTMLHelpers.ClientEvents.Grid.InitSelectionMode(s.sender);
                            if ($("#" + gridName + "Toolbar").length > 0) {
                                gridProperties.EnableQueryView(gridName, gridProperties.isQuery);
                            }
                            MSCJS.Common.Helper.ExecuteMethod(clientFn, [s]);
                        },
                        OnGridDataBound: function (s, clientfn) {
                            var gn = s.sender.element[0].id;
                            MSCJS.HTMLHelpers.ClientEvents.Grid.HandleSelection(s.sender, gn);
                            MSCJS.Common.Helper.ExecuteMethod(clientfn, [s]);
                            if (s.sender.dataSource._total == 0) {
                                s.sender.tbody.html("<td class='norecord' colspan='" + s.sender.columns.length + "'>No records found.</td>");
                            }
                            s.sender.options.pdf.allPages = true;
                        },
                        OnGridChangeEvent: function (s, clientFn, handle) {
                            var out = [];
                            MSCJS.Common.Helper.ExecuteMethod(clientFn, [s], undefined, out);
                            if (!out.isExecuted && handle) {
                                var gridName = s.sender.element[0].id;
                                if ($("#" + gridName + "Toolbar").length === 0) {
                                    var item = s.sender.dataItem(s.sender.select());
                                    if (item) {
                                        Ajax.RequestManager().Enqueue({
                                            url: UrlHelper.Action('GetData') + '?id=' + item.Id,
                                            type: "GET",
                                            cache: false,
                                            success: function (data) {
                                                TransactionButton(false, false, true, true, false, false);
                                                gridProperties.isQuery = true;
                                                $('#container').html(data);
                                            },
                                            error: function (data) {
                                                gridProperties.isQuery = false;
                                            }
                                        });
                                    }
                                }
                            }
                        },
                        DetailIcon: function (gridid, gridcnt, cnt, column, fn) {
                            var span = $("<span></span>").addClass("text-center show slideicon");
                            var fnname = 'MSCJS.HTMLHelpers.ClientEvents.Grid.DetailIconClick(this,"' + gridid + '","' + gridcnt + '","' + cnt + '","' + column + '","' + fn + '")';
                            span.attr("onclick", fnname);
                            span.append($("<i></i>").addClass("icon-arrow-right3 font14"));
                            return span.get(0).outerHTML;
                        },
                        DetailIconClick: function (s, gid, gcid, cid, cl, fn) {
                            var rightcss = "icon-arrow-right3";
                            var leftcss = "icon-arrow-left3";
                            var grid = MSCJS.GetGrid(gid);
                            var column = [];
                            var showWrapper;

                            gcid = MSCJS.GetId(gcid);
                            cid = MSCJS.GetId(cid);

                            if (typeof cl !== "undefined") {
                                column = cl.split("|");
                            }

                            if ($(s.children).hasClass(rightcss)) {
                                if (!$(gcid).hasClass("narrow")) {
                                    showWrapper = true;
                                }
                                $(gcid + " [role='gridcell'] .slideicon " + MSCJS.GetClass(leftcss)).toggleClass(leftcss + " " + rightcss);
                                $(s.children).toggleClass(rightcss + " " + leftcss)
                            }
                            else {
                                showWrapper = false;
                                $(s.children).toggleClass(leftcss + " " + rightcss);
                            }

                            if (typeof showWrapper !== "undefined") {
                                $(gcid).toggleClass("narrow");
                                $(cid).toggle();
                                $(gcid).toggleClass("col-xs-3 nopadding");
                                $.each(column, function (i, v) {
                                    grid[showWrapper ? "hideColumn" : "showColumn"](v);
                                })

                                if (showWrapper) {
                                    var container = grid.wrapper.children(".k-grid-content");
                                    container.scrollLeft(grid.scrollables[0].scrollWidth);
                                    $(".k-grid-pager .k-label").attr("style", "display: none !important;")
                                }
                                else {
                                    $(".k-grid-pager .k-label").removeAttr("style")
                                    $(MSCJS.GetId(gid) + ' table[role="grid"]').removeAttr("style");
                                }
                            }
                            window[fn](grid.dataSource.getByUid($(s).closest("tr").attr("data-uid")));
                        },
                        FormatCell: function (data, length, text, istitle) {
                            text = text ? text : "...";
                            length = length ? length : 10;
                            var value = data.length > length + text.length ? data.substring(0, length) + text : data;
                            return MSCJS.Message.Format("<span {0}>{1}</span>", istitle ? "title='" + data + "'" : "", value);
                        },
                        ColumnFormat: function (value, data, format) {
                            var currentValue = kendo.toString(data[value], format);
                            if (currentValue == '01-Jan-0001') {
                                return '';
                            }
                            return currentValue;
                        },
                        InitSelectionMode: function (g) {
                            if (!g.Selection) {
                                g.Selection = function () {
                                    var selectedRows = [];
                                    var selectedItems = [];
                                    var isSelectAll = false;
                                    return {
                                        SetSelectAll: function (f) {
                                            isSelectAll = f;
                                        },
                                        Select: function (v, d) {
                                            selectedRows.push(v);
                                            selectedItems.push(d);
                                        },
                                        Deselect: function (v) {
                                            var index = selectedRows.indexOf(v);
                                            if (index > -1) { selectedRows.splice(index, 1); }
                                            var itemindex = selectedItems.findIndex(function (iv) { return iv.Id == v; });
                                            if (itemindex > -1) { selectedItems.splice(itemindex, 1); }
                                        },
                                        GetSelected: function () {
                                            return {
                                                IsSelectAll: isSelectAll,
                                                Items: selectedRows
                                            };
                                        },
                                        GetSelectedKeys: function () {
                                            return selectedRows;
                                        },
                                        GetSelectedItems: function () {
                                            return selectedItems;
                                        },
                                        IsSelected: function (r) {
                                            return selectedRows.indexOf(r) > -1;
                                        },
                                        Reset: function () {
                                            isSelectAll = false;
                                            selectedRows = [];
                                            selectedItems = [];
                                        }
                                    }
                                }();
                            }
                        },
                        HandleSelection: function (s, gn) {
                            var cbAll = document.getElementById(gn + '_SelectAll');
                            if (s.Selection) {
                                $.each($('.' + gn + '_cb'), function (i, v) {
                                    var key = v.id.split('_')[2];
                                    v.checked = s.Selection.IsSelected(key);
                                });
                            }
                            if (cbAll && cbAll.checked) { MSCJS.HTMLHelpers.ClientEvents.Grid.OnSelectAll(cbAll, gn); }
                        },
                        SelectCheckBox: function (scb, gn, v) {
                            var grid = $('#' + gn).data('kendoGrid');
                            var items = grid.dataSource.data();
                            grid.Selection[scb.checked ? 'Select' : 'Deselect'](v, items.find(function (vi) { return vi.Id == v; }));
                            MSCJS.Common.Helper.ExecuteMethod(gn + '_SelectCheckBox', [scb, grid, v]);
                        },
                        OnSelectAll: function (me, gn) {
                            var grid = $('#' + gn).data('kendoGrid');
                            $.each($('.' + gn + '_cb'), function (i, v) { v.checked = me.checked; });
                            if (!me.checked) { grid.Selection.Reset(); }
                            grid.Selection.SetSelectAll(me.checked);
                            MSCJS.Common.Helper.ExecuteMethod(gn + '_SelectAll', [me, grid]);
                        }
                    },
                    MultiSelect: {
                        OnChange: clfn(),
                        OnSelect: clfn(),
                        OnOpen: (function (s, clientFn, dropdownvalue) {
                            //Used to set the dropdown Width of Combobox
                            if (dropdownvalue) {
                                s.sender.list.width(dropdownvalue);
                            }
                            if (s.sender.dataSource && s.sender.dataSource._total <= 0) {
                                s.preventDefault();
                            }
                            MSCJS.Common.Helper.ExecuteMethod(clientFn, [s]);
                        }),
                        OnClose: clfn(),
                        OnDataBound: clfn(),
                        OnFiltering: clfn()
                    },
                    DetailGrid: {
                        AddDetail: function (gname) {
                            if (!gridProperties.IsButtonEnable(gname, gridProperties.Newcss) || !gridProperties.IsButtonEnable(gname, gridProperties.Clearcss)) {
                                Ajax.RequestManager().Enqueue({
                                    url: UrlHelper.Action('AddDetail') + '?key=' + gname + '&id=' + 0,
                                    type: "GET",
                                    cache: false,
                                    success: function (partialData) {
                                        $('#' + gname + 'ctr').html(partialData);
                                        gridProperties.GridButtonEnable(gname, false, true, false, false, true, true);
                                        gridProperties.ShowGridContainer(gname);
                                        Validation.Load({
                                            ValidationSettings: {
                                                Url: UrlHelper.Action('LoadUIValidationRules'),
                                                Category: gname,
                                                Success: function (rules) {
                                                    ValidationHandler.AddRules(gname, rules);
                                                }
                                            }
                                        })
                                    }
                                });
                            }
                        },
                        CloseDetail: function (gname) {
                            if (!gridProperties.IsButtonEnable(gname, gridProperties.Closecss)) {
                                gridProperties.HideGridContainer(gname);
                                if (gridProperties.isQuery) {
                                    gridProperties.GridButtonEnable(gname, false, false, false, false, false, false);
                                }
                                else {
                                    gridProperties.GridButtonEnable(gname, true, false, true, true, false, false);
                                }
                            }
                        },
                        EditDetail: function (gname, IdProperty) {
                            if (!gridProperties.IsButtonEnable(gname, gridProperties.Editcss)) {
                                var grid = $("#" + gname).data("kendoGrid");
                                var item = grid.dataItem(grid.select());
                                if (item && item[IdProperty]) {
                                    //var Id = $("#" + gname + "ctr #" + IdProperty).val();
                                    Ajax.RequestManager().Enqueue({
                                        url: UrlHelper.Action('AddDetail') + '?key=' + gname + '&id=' + item[IdProperty],
                                        type: "GET",
                                        cache: false,
                                        success: function (partialData) {
                                            $('#' + gname + 'ctr').html(partialData);
                                            gridProperties.GridButtonEnable(gname, false, true, false, false, false, true);
                                            gridProperties.ShowGridContainer(gname);
                                            Validation.Load({
                                                ValidationSettings: {
                                                    Url: UrlHelper.Action('LoadUIValidationRules'),
                                                    Category: gname,
                                                    Success: function (rules) {
                                                        ValidationHandler.AddRules(gname, rules);
                                                    }
                                                }
                                            })
                                        },
                                        error: function (data) {
                                        }
                                    });
                                }
                            }
                        },
                        ValidateGrid: function (mndv) {
                            mndv = MSCJS.GetId(mndv);
                            var data = $(mndv + " .DetailGridToolbar");
                            var message = "";
                            if (data && data.length > 0) {
                                $.each(data, function (i, n) {
                                    var currentId = $(n).attr("id").replace("Toolbar", "");
                                    if ($("#" + currentId + "ctr").html())
                                        message += "Save or Cancel the " + currentId + "! <br />";
                                })
                            }
                            return message;
                        },
                        SaveDetail: function (gname) {
                            if (!gridProperties.IsButtonEnable(gname, gridProperties.Savecss)) {
                                var grid = $("#" + gname).data("kendoGrid");
                                var message = Validation.IsValid({ ContainerId: (gname + "ctr") });
                                checkForValidation = function () {
                                    var fn = window[gname + '_Validation']
                                    if (fn && typeof (fn) == 'function') { message += fn(message); }
                                    if (message === '') { return true; }
                                    else { return false; }
                                };

                                if (checkForValidation()) {
                                    Ajax.RequestManager().Enqueue({
                                        url: UrlHelper.Action('SaveDetail') + '?key=' + gname,
                                        type: "POST",
                                        cache: false,
                                        data: $('#' + gname + 'ctr *').serialize(),
                                        success: function (data) {
                                            if (data.success) {
                                                grid.dataSource.read();
                                                gridProperties.HideGridContainer(gname);
                                                if (!data.title) data.title = "Save";
                                            }
                                            else {
                                                MSCJS.Message.ShowError("Error", data.message);
                                            }
                                        },
                                        error: function (data) {
                                            if (e.responseText.indexOf("\"type\":\"E\"") > 0) {
                                                var error = $.parseJSON(e.responseText);
                                                MSCJS.Message.ShowMessage(error.type, error.title, error.message, error.innerMessage, error.stackTrace);//TODO SHOW ERROR WITH INNER MESSAGE
                                            }
                                        }
                                    });
                                }
                                else {
                                    MSCJS.Message.ShowError("Error", message);
                                };
                            }
                        },
                        DeleteDetail: function (gname, IdProperty) {
                            if (!gridProperties.IsButtonEnable(gname, gridProperties.Deletecss)) {
                                var grid = $("#" + gname).data("kendoGrid");
                                var item = grid.dataItem(grid.select());
                                if (item && item[IdProperty])
                                    Ajax.RequestManager().Enqueue({
                                        url: UrlHelper.Action('DeleteDetail') + '?key=' + gname + '&id=' + item[IdProperty],
                                        type: "POST",
                                        cache: false,
                                        success: function (data) {
                                            if (data.success) {
                                                Validation.Load({
                                                    ValidationSettings: {
                                                        Url: UrlHelper.Action('LoadUIValidationRules'),
                                                        Category: gname,
                                                        Success: function (rules) {
                                                            ValidationHandler.AddRules(gname, rules);
                                                        }
                                                    }
                                                });
                                                grid.dataSource.read();
                                                if (!data.title) data.title = "Delete";
                                                gridProperties.GridButtonEnable(gname, true, false, true, true, false, false);
                                            }
                                            MSCJS.Message.ShowMessage(data.type, data.title, data.message);
                                        },
                                        error: function (data) {
                                        }
                                    });
                            }
                        },
                        QueryDetail: function (gname, IdProperty) {
                            if (!gridProperties.IsButtonEnable(gname, gridProperties.Querycss)) {
                                var grid = $("#" + gname).data("kendoGrid");
                                var item = grid.dataItem(grid.select());
                                if (item[IdProperty]) {
                                    Ajax.RequestManager().Enqueue({
                                        url: UrlHelper.Action('QueryDetail') + '?key=' + gname + '&id=' + item[IdProperty],
                                        type: "GET",
                                        cache: false,
                                        success: function (partialData) {
                                            $('#' + gname + 'ctr').html(partialData);
                                            gridProperties.ShowGridContainer(gname);
                                            gridProperties.GridButtonEnable(gname, false, false, false, false, false, true);
                                        },
                                        error: function (data) {
                                        }
                                    });
                                }
                            }
                        },
                    },
                    Slider: {
                        OnSliderChange: clfn(),
                        OnSliderSlide: clfn()
                    },
                    TabStrip: {
                        OnActivate: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_OnActivate', e);
                        },
                        OnSelect: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_OnSelect', e);
                        }
                    },
                    Window: {
                        OnClose: function (e, clientFn) {
                            var id = e.sender.element[0].id;
                            if ($("#" + id + "ctr").hasClass(MSCJS.Constants.WindowHelper.Css.Overlay)) {
                                $("#" + id + "ctr").removeClass(MSCJS.Constants.WindowHelper.Css.Overlay);
                            }
                            MSCJS.Common.Helper.ExecuteMethod(clientFn, [e]);
                        },
                        OnError: clfn(),
                        OnDeactivate: clfn(),
                        OnOpen: function (e, clientFn) {
                            var id = e.sender.element[0].id;
                            if (!$("#" + id + "ctr").hasClass(MSCJS.Constants.WindowHelper.Css.Overlay)) {
                                $("#" + id + "ctr").addClass(MSCJS.Constants.WindowHelper.Css.Overlay);
                            }
                            MSCJS.Common.Helper.ExecuteMethod(clientFn, [e]);
                        },
                        OnActivate: clfn(),
                        OnDragStart: clfn(),
                        OnDragEnd: clfn(),
                        OnRefresh: clfn(),
                        OnResize: clfn()
                    },
                    AutoComplete: {
                        OnAutoCompleteChange: clfn(),
                        OnSelect: clfn(),
                        OnOpen: (function (s, clientFn, dropdownvalue) {
                            if (dropdownvalue) {
                                s.sender.list.width(dropdownvalue);
                            }
                            MSCJS.Common.Helper.ExecuteMethod(clientFn, [s]);
                        }),
                        OnClose: clfn(),
                        OnDataBound: clfn(),
                        OnFiltering: clfn()
                    },
                    MaskedTextBox: {
                        OnChange: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_OnChange', [e]);
                        }
                    },
                    PivotGrid: {
                        onTextChange: function (id, cur) {
                            var list = MSCJS.GetGrid(id);
                            var idcol = cur.id.split("_");
                            item = list.dataSource.getByUid(idcol[0]);
                            item.set("dirty", true);
                            var colname = idcol.length > 2 ? "_" : "";
                            colname += idcol[idcol.length - 1];
                            item[colname] = cur.value;
                        }
                    },
                    NumericTextBox: {
                        OnSpin: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_Spin', [e]);
                        },
                        OnChange: function (e) {
                            MSCJS.Common.Helper.ExecuteMethod(e.sender.element.context.id + '_Change', [e]);
                        }
                    },
                    CheckBoxGroup: {
                        OnClick: function (c, s) {
                            var clientEvent = c + '_OnClick';
                            if (MSCJS.Common.Helper.CheckIfMethodExistFromName(clientEvent)) {
                                MSCJS.Common.Helper.ExecuteMethod(clientEvent, s);
                            }
                            else {
                                var me = window[c];
                                me.UpdateGroup(me.Items.findIndex(function (d) { return d.id === s; }));
                            }
                        },
                        OnLoad: function (d) {
                            window[d.id] = new CheckBoxGroup(d.id);
                            var cu = window[d.id];
                            if (d.items && d.items.length > 0) {
                                cu.NewComponentAndSelectItem(d, d.items);
                            }
                            else {
                                $.ajax({
                                    url: UrlHelper.Action(d.action),
                                    type: "GET",
                                    cache: false,
                                    dataType: 'json',
                                    success: function (partialData) {
                                        cu.NewComponentAndSelectItem(d, partialData.Data);
                                    },
                                    error: function (data) {
                                    }
                                });
                            }
                        },
                        HiddenFiled: function () {
                            var html = "";
                            $.each($(".chkgrp"), function (i, s) {
                                var cid = s.id.replace("grp", "");
                                var chkgrp = window[cid];
                                var v = chkgrp.GetSelectedItems();
                                $.each(v, function (i, v1) {
                                    var cuid = cid + "_" + i + "__";
                                    var cunm = cid + "[" + i + "].";
                                    html += "<input type='hidden' value='" + v1.item[chkgrp.ValueField] + "' id='" + cuid + chkgrp.ValueField + "' name='" + cunm + chkgrp.ValueField + "' />";
                                    html += "<input type='hidden' value='" + v1.item[chkgrp.TextField] + "' id='" + cuid + chkgrp.TextField + "' name='" + cunm + chkgrp.TextField + "' />";
                                })
                            })
                        }
                    },
                    GroupButton: {
                        AddWrapper: function (d, item) {
                            var wrapper = "";
                            $.each(item, function (i, v) {
                                wrapper += MSCJS.Message.Format("<button class='btn btn-primary {0}' onclick='MSCJS.HTMLHelpers.ClientEvents.GroupButton.OnClick(\"{1}_{2}\",\"{2}\",this)'>{2}</button>", item && v[d.valueField] === d.defaultValue ? "s" : "", d.id, v[d.valueField], v[d.textField]);
                            })
                            wrapper += "<input type='hidden' value='" + d.defaultValue + "' id='" + d.id + "' />";
                            $("#" + d.id + "_grp").html(wrapper);
                        },
                        OnLoad: function (d) {
                            if (d.listData && d.listData.length > 0) {
                                AddWrapper(d, d.listData);
                            }
                            else {
                                $.ajax({
                                    url: UrlHelper.Action(d.methodName),
                                    type: "GET",
                                    cache: false,
                                    dataType: 'json',
                                    success: function (partialData) {
                                        AddWrapper(d, partialData.Data);
                                    },
                                    error: function (data) {
                                    }
                                });
                            }
                        },
                        OnClick: function (id, v, t) {
                            var clientEvent = id + '_OnClick';
                            if (MSCJS.Common.Helper.CheckIfMethodExistFromName(clientEvent)) {
                                MSCJS.Common.Helper.ExecuteMethod(clientEvent, [i, d]);
                            }
                            else {
                                $(MSCJS.GetId(id)).val(v);
                                $(MSCJS.GetId(t.id)).addClass('grpbtnselected');
                                $(MSCJS.GetId(t.id)).siblings().removeClass('grpbtnselected');
                            }
                        }
                    },
                    Menu: {
                        OnSelect: (function (s) {
                            MSCJS.Common.Helper.ExecuteMethod(s.sender.element.context.id + '_Select',  [s]);
                        }),
                        OnOpen: (function (s) {
                            MSCJS.Common.Helper.ExecuteMethod(s.sender.element.context.id + '_Open', [s]);
                        }),
                        OnClose: (function (s) {
                            MSCJS.Common.Helper.ExecuteMethod(s.sender.element.context.id + '_Close', [s]);
                        }),
                        OnActivate: (function (s) {
                            MSCJS.Common.Helper.ExecuteMethod(s.sender.element.context.id + '_Activate', [s]);
                        }),
                        OnDeactivate: (function () {
                            MSCJS.Common.Helper.ExecuteMethod(s.sender.element.context.id + '_Deactivate', [s]);
                        }),
                        OnEqualed: clfn(),
                    },
                    Toggle: {
                        onChange: function (cb, n, v, l) {
                            var values = v ? v.split('|') : [];
                            var label = l ? l.split('|') : [];
                            var ci = cb.checked ? 0 : 1;
                            $("#" + n).val(values.length > 0 ? values[ci] : "");
                            $("#lbl_toggle_" + n).html(label.length > 0 ? label[ci] : "");
                        },
                        onLoad: function (n, v, l, d) {
                            var value = v ? v.split("|") : [];
                            var label = l ? l.split("|") : [];
                            var ci = 1; // default false
                            if (value && value[0] === d) {
                                ci = 0;
                                $("#cmn_toggle_" + n).click();
                            }
                            else {
                                $("#lbl_toggle_" + n).html(l && ci ? label[ci] : "");
                                $("#" + n).val(value && ci ? value[ci] : "");
                            }
                        }
                    },
                    ProgressBar:
                    {
                        onChange: clfn("_Change"),
                        onCompleted: clfn("_Completed"),
                    },
                    ToolTip: {
                        onContentLoad: clfn("_ContentLoad"),
                        onError: clfn("_Error"),
                        onShow: clfn("_Show"),
                        onHide: clfn("_Hide"),
                        onRequestStart: clfn("_Start")
                    }
                },
            },
        };
    })();
})(window);

Ajax = (function () {
    var requestManager;
    function Init() {
        function Start(request, $this) {
            if (request) {
                if (typeof (request) == 'object' && !request['notAjax']) {
                    $.ajax({
                        url: request.url,
                        type: request.type,
                        contentType: request.contentType,
                        cache: request.cache,
                        data: request.data,
                        processData: request.processData,
                        success: function (o) {
                            if (o.type != 'E') {
                                if (request.success) request.success(o);
                                status = 0;
                                if ($this.RequestQueue.length > 0) {
                                    var nextRequest = $this.Dequeue(request.url);
                                    $this.LoadingPanel(nextRequest['message']).Show();
                                    Start(nextRequest, $this);
                                }
                                else {
                                    $this.LoadingPanel().Hide();
                                    Overlay.Stop();
                                }
                                MSCJS.Custombehaviour.Execute();
                            }
                            else {
                                MSCJS.Message.ShowMessage(o.type, o.title, o.message);
                                $this.LoadingPanel().Hide();
                                Overlay.Stop();
                            }
                        },
                        error: function (e) {
                            status = 0;
                            var errorHandled = false;
                            if (request.onError) {
                                request.onError(e);
                                errorHandled = true;
                            }
                            if (e.status == HttpStatus.Forbidden) {
                                MSCJS.Message.ShowInformation(MSCJS.Resources.Authorization());
                            }
                            if (e.responseText.indexOf("\"type\":\"E\"") > 0) {
                                var error = $.parseJSON(e.responseText);
                                MSCJS.Message.ShowMessage(error.type, error.title, error.message, error.innerMessage, error.stackTrace);//TODO SHOW ERROR WITH INNER MESSAGE
                            }
                            else {
                                var reg = /<title>(.*?)<\/title>/;
                                var title = e.responseText.match(reg), txtTitle = "";
                                if (title && title.length > 1) { txtTitle = title[1] }
                                else if (title && title[0]) { txtTitle = title[0]; }
                                MSCJS.Message.ShowError(txtTitle, e.responseText);//TODO SHOW ERROR WITH INNER MESSAGE
                            }
                            $this.LoadingPanel().Hide();
                            Overlay.Stop();
                        },
                        complete: function (result) {
                            if (request.onComplete) {
                                request.onComplete(result);
                            }
                        }
                    });
                }
                else if (typeof (request) == 'object' && request['notAjax']) {
                    if (request) request.method();
                    status = 0;
                    if ($this.RequestQueue.length > 0) Start($this.Dequeue(request.url), $this);
                }
            }
            var HttpStatus = {
                Forbidden: 403
            };
        }
        var Overlay = (function () {
            return {
                GetLoadingPanelAndContent: (function () {
                    //TODO Get the Loading panel from the Outer Layout
                    return {
                        Show: function () {
                            $("#loading").remove();
                            $("<div id='loading' class='loading'><img src='../images/loader.gif'/><span id='loadingMessage'>Please wait ...  </span></div>")
                                .insertAfter("body");
                        },
                        Hide: function () {
                            $("#loading").remove();
                        }
                    };
                }),
                Start: (function () {
                    var panel = this.GetLoadingPanelAndContent();
                    panel.Show();
                }),
                Stop: (function () {
                    var panel = this.GetLoadingPanelAndContent();
                    panel.Hide();
                })
            }
        })();
        return {
            RequestQueue: null,
            status: null,
            //TODO Loading Panel with Show/Hide
            LoadingPanel: function (msg) {
                /*
                .loading {
                    background-color: rgba(17, 17, 17, 0.15);
                    top: 0;
                    height: 100%;
                    width: 100%;
                    z-index: 9999999999;
                    position: absolute;
                }

                .loading img {
                    top: 50%;
                    left: 50%;
                    position: absolute;
                }*/
                var loadingPanel = Overlay.GetLoadingPanelAndContent();
                this.SetMessage(msg);
                return loadingPanel;
            },
            SetMessage: (function (msg) {
                var msgContent = document.getElementById('loadingMessage');
                msgContent.innerHTML = msg ? msg : 'Please wait ...';
            }),
            StopOverlay: (function () {
                Overlay.Stop();
            }),
            Enqueue: function (request) {
                if (!this.RequestQueue)
                    this.RequestQueue = [];
                this.RequestQueue.push(request);
                this.Logger(request.url + ' added!');
                if ((!status) || (status == "0") || this.RequestQueue.length <= 1) {
                    status = 1;
                    if (this.RequestQueue.length > 0) {
                        Overlay.Start();
                        this.LoadingPanel(request['message']).Show();
                        Start(this.Dequeue(request.url), this);
                    };
                }
            },
            Dequeue: function (url) {
                if (this.RequestQueue) {
                    this.Logger(url + ' is pending...');
                    return this.RequestQueue.shift();
                }
                return null;
            },
            Counts: function () {
                return !this.RequestQueue ? 0 : this.RequestQueue.length;
            },
            Logger: function (message) {
                //if (console!='undefined') {
                // console.log(message);
                // }
            }
        };
    }
    return {
        RequestManager: function () {
            if (!requestManager)
                requestManager = Init();
            return requestManager;
        }
    };
})();

var gridProperties = {
    Show: function () { return "dgshow"; },
    Hide: function () { return "dghide"; },
    Savecss: function () { return 'dgsave'; },
    Editcss: function () { return 'dgedit'; },
    Deletecss: function () { return 'dgdelete'; },
    Clearcss: function () { return 'dgclear'; },
    Closecss: function () { return 'dgclose'; },
    Newcss: function () { return 'dgnew'; },
    Querycss: function () { return 'dgquery' },
    isQuery: false,
    Disablecss: function () { return 'dgdisable' },
    ShowGridContainer: function (gname) {
        if ($('#' + gname + 'partial').hasClass(gridProperties.Hide())) {
            $('#' + gname + 'partial').toggleClass(gridProperties.Hide() + ' ' + gridProperties.Show());
            $("#" + gname + "grid").toggleClass(gridProperties.Show() + ' ' + gridProperties.Hide());
        }
    },
    IsButtonEnable: function (gname, cssClass) {
        return $('#' + gname + 'Toolbar .' + cssClass()).prop('disabled');
    },
    HideGridContainer: function (gname) {
        if ($('#' + gname + 'partial').hasClass(gridProperties.Show())) {
            $('#' + gname + 'grid').toggleClass(gridProperties.Hide() + ' ' + gridProperties.Show());
            $("#" + gname + "partial").toggleClass(gridProperties.Show() + ' ' + gridProperties.Hide());
            $("#" + gname + "ctr").html("");
        }
    },
    GridButtonEnable: function (gridname, isNew, isSave, isEdit, isDelete, isClear, isClose) {
        if (this.GetToolbarDetailLength(gridname, this.Newcss) === 0 && this.GetToolbarDetailLength(gridname, this.Savecss) === 0 && this.GetToolbarDetailLength(gridname, this.Editcss) === 0 && this.GetToolbarDetailLength(gridname, this.Deletecss) === 0) {
            $(this.GetToolbarDetail(gridname, this.Querycss)).show();
            this.GridToolbarAddorRemoveDisableClass(gridname, isClose, this.Closecss);
            this.GridToolbarAddorRemoveDisableClass(gridname, !isClose, this.Querycss);
        }
        else {
            this.GridToolbarAddorRemoveDisableClass(gridname, isNew, this.Newcss);
            this.GridToolbarAddorRemoveDisableClass(gridname, isSave, this.Savecss);
            this.GridToolbarAddorRemoveDisableClass(gridname, isEdit, this.Editcss);
            this.GridToolbarAddorRemoveDisableClass(gridname, isDelete, this.Deletecss);
            this.GridToolbarAddorRemoveDisableClass(gridname, isClear, this.Clearcss);
            this.GridToolbarAddorRemoveDisableClass(gridname, isClose, this.Closecss);
        }
    },
    GetToolbarDetail: function (gridname, cssClass) {
        return MSCJS.GetId(gridname + 'Toolbar .' + cssClass());
    },
    GetToolbarDetailLength: function (gridname, cssClass) {
        return $(MSCJS.GetId(gridname + 'Toolbar .' + cssClass())).length;
    },
    GridToolbarAddorRemoveDisableClass: function (gridname, enable, cssClass) {
        var currentToolbar = $('#' + gridname + 'Toolbar .' + cssClass());
        if (!enable && !currentToolbar.hasClass(this.Disablecss())) {
            currentToolbar.addClass(this.Disablecss());
        }
        else if (enable && currentToolbar.hasClass(this.Disablecss())) {
            $('#' + gridname + 'Toolbar .' + cssClass()).removeClass(this.Disablecss());
        }
        currentToolbar.prop("disabled", !enable);
    },
    EnableQueryView: function (gname, isEnable) {
        if (isEnable === true) {
            $("#" + gname + "Toolbar ." + this.Querycss()).show();

            gridProperties.GridButtonEnable(gname, false, false, false, false, false, false);
        }
        else {
            $("#" + gname + "Toolbar ." + this.Querycss()).hide();
            gridProperties.GridButtonEnable(gname, true, false, true, true, false, false);
        }
    }
};

(function MSCExtensions() {
    String.prototype.In = (function (set) {
        var value = this, has = false;
        if (typeof (set) === 'string')
            set = set.split(/,/g);
        for (var i = 0; i < set.length; i++)
            if (!has && set[i] === value)
                has = true;
        return has;
    });
    String.prototype.NotIn = (function (set) {
        return !this.In(set);
    });
    String.prototype.capitalizeFirstLetter = function () {
        return this.charAt(0).toUpperCase() + this.slice(1);
    },
    Array.prototype.trim = function () {
        i = 0;
        var L = this.length;
        while (i < L) {
            this[i] = this[i].trim();
            i++;
        }
        return this;
    };
})();

DefaultFormat = function () {
    var dateFormat = "dd-MMM-yyyy", dateTimeFormat = "dd-MMM-yyyy hh:mm:tt";
    return {
        SetDate: function (df) {
            dateFormat = df;
        },
        SetDateTime: function (dtf) {
            dateTimeFormat = dtf;
        },
        GetDate: function () {
            return dateFormat;
        },
        GetDateTime: function () {
            return dateTimeFormat;
        }
    }
}();

function TextAreaPopUpInit(s) {
} //todo

UrlHelper = function () {
    var cname = '';
    return {
        SetControllerName: function (n) {
            cname = n;
        },
        Action: function (n) {
            //return cname + '/' + n;
            return n;
        }
    }
}();

var Validation = (function () {
    return {
        Load: (function (s) {
            this.Category = s.ValidationSettings.Category || "Header";
            var self = this;
            $.ajax({
                url: UrlHelper.Action("LoadUIValidationRules"),
                type: 'POST',
                data: { groupId: ValidationHandler.Category.GetRulesetID(this.Category) },
                success: function (Result) {
                    $.each(Result.Rule, function (i, e) {
                        var rule = self.Json.Decode(e);
                        self.Rules.GetRules(self.Category).push(rule);
                        self.Register(rule);
                    });
                }
            });
        }),
        Json: (function () {
            return {
                Decode: (function (r) {
                    r[1] = r[1].replace(/\t/g, '');
                    r[2] = r[2].replace(/\t/g, '');
                    return {
                        Id: r[0],
                        Label: document.getElementById("spn" + r[1]) ? document.getElementById("spn" + r[1]) : { id: "spn" + r[1] },
                        Entity: document.getElementById(r[1]) ? document.getElementById(r[1]) : { id: r[1] },
                        EntityType: r[3],
                        DataType: r[4],
                        MinLength: r[5],
                        MaxLength: r[6],
                        MinDecimal: r[7],
                        MaxDecimal: r[8],
                        IsUpper: r[9],
                        RegularExpression: r[10],
                        MessageType: r[11],
                        CompareExpression: r[12],
                        CompareEntity: document.getElementById(r[13]) ? document.getElementById(r[13]) : { id: r[13] },
                        MinLengthMessage: r[14],
                        MaxLengthMessage: r[15],
                        MinDecimalMessage: r[16],
                        MaxDecimalMessage: r[17],
                        MinDateMessage: r[18],
                        MaxDateMessage: r[19],
                        IsUpperMessage: r[20],
                        CompareMessage: r[21],
                    };
                })
            };
        })(),
        CompareExpressions: (function () {
            return {
                LessThan: "<",
                GreaterThan: ">",
                LessThanOrEquals: "<=",
                GreaterThanOrEquals: ">=",
                Equals: "==",
                NotEquals: "!="
            };
        })(),
        EntityType: (function () {
            return {
                Label: 0,
                TextBox: 1,
                ListSingle: 2,
                ListMulti: 3,
                Checkbox: 4,
                Radiobutton: 5,
                Webcombo: 6,
                AutoComplete: 7,
                DateControl: 8,
                ComboBox: 10
            };
        })(),
        DataType: (function () {
            return {
                Anything: 0,
                RejectNegativeandDecimalDot: 1,//integers
                RejectNegativeButNotDecimalDot: 2,//double >0
                AcceptNegativeButNotDecimalDot: 3,//whole numbers
                AcceptNegativeAndDecimalDot: 4,//dobule with minus
                AcceptLetterAndDigitOnly: 10,//alphanumeric
                AcceptNamingLetters: 11,//valid naming strings
                AnythingButNotSpecial: 12,
                AcceptDate: 20,//dates
                Email: 30,//valid emails
                CreditCard: 40,
                PhycalPath: 50,
                RelativePath: 51,
                RegularExpression: 52,
                Temperature: 5
            };
        })(),
        Register: (function (r) {
            this.Refresh(r);
            this.RequiredFieldValidator(r);
            if (r.IsUpper) {
                $(r.Entity).css('text-transform', 'uppercase').change(function () {
                    this.value = this.value.toUpperCase()
                });
            }
            $(r.Entity).bind('keypress', this.EventHandler.OnKeyPress);
            $(r.Entity).bind('change', this.EventHandler.OnChange);
            $(r.Entity).bind('paste', this.EventHandler.OnPaste);
        }),
        Refresh: (function (rule) {
            if (rule && rule.Label) {
                var entityId = rule.Entity.id || rule.Entity;
                var labelId = rule.Label.id || rule.Label;
                rule.Entity = document.getElementById(entityId) || rule.Entity;
                rule.Label = document.getElementById(labelId) || rule.Label;
            }
        }),
        RequiredFieldValidator: (function (r) {
            if (r && r.MinLength === 1 && r.Label && r.Label.innerHTML) {
                r.Label.innerHTML = r.Label.innerHTML.replace(/\<span(.+)\>/g, '');
                if (r.Entity.value != undefined && r.Entity.value.trim() !== '') {
                    r.Label.innerHTML = r.Label.innerHTML.replace(/\<\/label\>/g, '').trim() + '<span>*</span>' + '</label>';
                }
                else if (r.Entity.value == undefined || r.Entity.value.trim() === '') {
                    r.Label.innerHTML = r.Label.innerHTML.replace(/\<\/label\>/g, '').trim() + '<span title="' + r.MinLengthMessage + '" class="ValidationSummary" validation_focus="' + r.Entity.id + '">*</span></label>';
                }
            } else if (r.CompareExpression) {
                $(r.Label).attr('data-cmp-val', r.CompareMessage);
                $(r.Label).addClass('CompareSummary');
            }
        }),
        CompareValidator: (function (r) {
            if (r.CompareExpression) {
                switch (r.DataType) {
                    case this.DataType.AcceptDate:
                        var d1 = this.DateFormat(r.Entity.value);
                        var d2 = this.DateFormat(r.CompareEntity.value);
                        this.Compare(d1, d2, r.CompareExpression, r.Label, r.CompareMessage);
                        break;
                    case this.DataType.Anything:
                        this.Compare(r.Entity.value, r.CompareEntity.value, r.CompareExpression, r.Label, r.CompareMessage);
                        break;
                }
            }
        }),
        Compare: (function (v1, v2, op, lbl, msg) {
            switch (op) {
                case this.CompareExpressions.LessThan:
                    if (v1 < v2) {
                        $(lbl).attr('data-cmp-val', '');
                        $(lbl).removeClass('CompareSummary');
                    } else {
                        $(lbl).attr('data-cmp-val', msg);
                        $(lbl).addClass('CompareSummary');
                    }
                    break;
                case this.CompareExpressions.LessThanOrEquals:
                    if (v1 <= v2) {
                        $(lbl).attr('data-cmp-val', '');
                        $(lbl).removeClass('CompareSummary');
                    } else {
                        $(lbl).attr('data-cmp-val', msg);
                        $(lbl).addClass('CompareSummary');
                    }
                    break;
                case this.CompareExpressions.Equals:
                    if (v1 == v2) {
                        $(lbl).attr('data-cmp-val', '');
                        $(lbl).removeClass('CompareSummary');
                    } else {
                        $(lbl).attr('data-cmp-val', msg);
                        $(lbl).addClass('CompareSummary');
                    }
                    break;
                case this.CompareExpressions.NotEquals:
                    if (v1 != v2) {
                        $(lbl).attr('data-cmp-val', '');
                        $(lbl).removeClass('CompareSummary');
                    } else {
                        $(lbl).attr('data-cmp-val', msg);
                        $(lbl).addClass('CompareSummary');
                    }
                    break;
                case this.CompareExpressions.GreaterThanOrEquals:
                    if (v1 >= v2) {
                        $(lbl).attr('data-cmp-val', '');
                        $(lbl).removeClass('CompareSummary');
                    } else {
                        $(lbl).attr('data-cmp-val', msg);
                        $(lbl).addClass('CompareSummary');
                    }
                    break;
                case this.CompareExpressions.GreaterThan:
                    if (v1 > v2) {
                        $(lbl).attr('data-cmp-val', '');
                        $(lbl).removeClass('CompareSummary');
                    } else {
                        $(lbl).attr('data-cmp-val', msg);
                        $(lbl).addClass('CompareSummary');
                    }
                    break;
            }
        }),
        DateFormat: (function (d) {
            var dsplit = d.replace("-", " ");
            return d = new Date(dsplit);
        }),
        IsValid: (function (s) {
            return Validation.IsValidAndFocus(s).length > 0 ? Validation.IsValidAndFocus(s)[0].ErrorMessage : "";
        }),
        IsValidAndFocus: (function (s) {
            var DisplayMessage = [];
            var msg = '';
            var summary = $('#' + s.ContainerId).find('.ValidationSummary');
            var controls = this.GetHtmlControls();
            controls = controls.split(',');
            $(controls).each(function (i, c) {
                var self = Validation;
                if (c) {
                    var rule = self.GetRuleById(c);
                    if (rule == null) {
                        return true;
                    }
                    else {
                        self.CompareValidator(rule);
                    }
                }
            });
            var cmpsummary = $('#' + s.ContainerId).find('.CompareSummary');
            $.each(cmpsummary, function (i, e) {
                msg += e.getAttribute("data-cmp-val") + " <br> ";
            });
            $.each(summary, function (i, e) {
                msg += e.title + " <br> ";
            });
            msg += MSCJS.HTMLHelpers.ClientEvents.DetailGrid.ValidateGrid(s.ContainerId);
            msg ? DisplayMessage.push({ ErrorMessage: msg, FocusId: summary[0].attributes[2].value }) : DisplayMessage;
            return DisplayMessage;
        }),
        ValidationFocus: (function (id) {
            $("#" + id).focus();
        }),
        EventHandler: (function () {
            var getTextBoxValue = (function (event) {
                var currentTarget = event.target || window.event.target;
                var self = Validation;
                var r = self.GetRuleById(event.target.id);
                if (currentTarget.selectionStart == 0 && currentTarget.selectionEnd == r.MaxLength) {
                    return String.fromCharCode(event.which);
                } else {
                    return currentTarget.value.slice(0, currentTarget.selectionStart)
                                + String.fromCharCode(event.which)
                                + currentTarget.value.slice(currentTarget.selectionStart, currentTarget.value.length);
                }
            });
            return {
                /// <summary>
                /// Validates the entity when the key is pressed
                /// </summary>
                OnKeyPress: (function (e) {
                    if (!window.event
                        && e.key !== "Spacebar"
                        && e.key !== "MozPrintableKey"
                        && (e.which === 0 || e.which == 8)
                        && e.charCode === 0) { return true; }
                    var v = getTextBoxValue(e);
                    var self = Validation, value = getTextBoxValue(e), r = self.GetRuleById(e.target.id);
                    if (r == null) {
                        return true;
                    }
                    switch (r.DataType) {
                        case self.DataType.AcceptNegativeAndDecimalDot:
                            return value.match(self.GetExpressionByRule(r)) != null;
                            break;
                        case self.DataType.AcceptNegativeButNotDecimalDot:
                            if (e.key === self.Constants.Minus && value === '') return true;
                            else if (e.key === self.Constants.Zero) return false;
                            return self.GetExpressionByRule(r).test(value);
                            break;
                        case self.DataType.RejectNegativeandDecimalDot:
                            return value.match(self.GetExpressionByRule(r)) != null;
                            break;
                        case self.DataType.RejectNegativeButNotDecimalDot:
                            return value.match(self.GetExpressionByRule(r)) != null;
                            break;
                        case self.DataType.AcceptNamingLetters:
                            return self.GetExpressionByRule(r).test(value);
                            break;
                        case self.DataType.AcceptLetterAndDigitOnly:
                            return self.GetExpressionByRule(r).test(value);
                            break;
                        case self.DataType.RegularExpression:
                            return self.GetExpressionByRule(r).test(value);
                            break;
                        case self.DataType.Anything:
                            return self.GetExpressionByRule(r).test(value);
                            break;
                        case self.DataType.Temperature:
                            return value.match(self.GetExpressionByRule(r)) != null;
                            break;
                    }
                }),
                OnChange: (function (e) {
                    var self = Validation;
                    var rule = self.GetRuleById(e.target.id);
                    if (rule == null) {
                        return true;
                    }
                    else {
                        self.Refresh(rule);
                        self.RequiredFieldValidator(rule);
                        if (rule.DataType == self.DataType.Email && rule.Entity.value.trim() !== '') {
                            return self.GetExpressionByRule(rule).test(rule.Entity.value) ? true : alert("Invalid Email");
                        }
                    }
                }),
                /// <summary>
                /// Validates the entity when the value is pasted
                /// </summary>
                OnPaste: (function (e) {
                    setTimeout(function () {
                        var self = Validation,
                        r = self.GetRuleById(e.target.id);
                        if (r == null) {
                            //console.log("No Element found for " + e.target.id);
                        }
                        else {
                            var expression = self.GetExpressionByRule(r);
                            if (r.DataType === self.DataType.AcceptNegativeAndDecimalDot
                                || r.DataType === self.DataType.RejectNegativeButNotDecimalDot
                                || r.DataType === self.DataType.Temperature) {
                                expression = self.GetExpressionByRule(r).Second;
                                if (self.Constants.PointRegExp.test(e.target.value)) {
                                    expression = self.GetExpressionByRule(r).First;
                                }
                            }
                            if (!expression.test(r.Entity.value)) {
                                if (r.Entity.value.length > r.MaxLength) {
                                    r.Entity.value = r.Entity.value.substr(0, r.MaxLength);
                                }
                                self.RequiredFieldValidator(r);
                            }
                        }
                    }, 0);
                }),
            };
        })(),

        // added
        Constants: (function () {
            return {
                EmptyString: '',
                Dot: '.',
                Minus: '-',
                Zero: '0',
                MinusZero: '-0',
                PointZero: '.0',
                PointRegExp: /\./g,
                MinusRegExp: /-/g,
                DotRegExp: /./g,
                ZeroRegExp: /^-?0{1,}$/,
                ConsecutiveZeroRegExp: /^-?0{2,}$/,
                DotWithConsecutiveZeroRegExp: /^\.0{2,}$/,
                MinusOrDotRegExp: /^-\.?$/,
                HeaderCategory: 'form1',
                DefaultCategory: 'Header',
                MessageTypeClass: {
                    73: 'clsInformation',
                    87: 'clsWarning',
                    69: 'clsException'
                },
                MessageType: {
                    Information: 73,
                    Warning: 87,
                    Exception: 69
                }
            };
        })(),
        GetRuleById: (function (entityId) {
            var self = this, rule = null, getRuleById = (function (rules, isdefaultCatagoryCall) {
                for (var i = 0; i < rules.length; i++) {
                    if (rules[i].Entity.id === entityId) {
                        return rules[i];
                    }
                }
                if (!isdefaultCatagoryCall) { value = getRuleById(self.Rules.GetRules("Header"), true); }
                else { value = null; }
                return value;
            });
            var category = entityId.replace(/_/g, '.');
            return getRuleById(this.Rules.GetRules(category.split('.')[0]), false);
        }),
        GetExpressionByRule: (function (r) {
            var expression = null;
            switch (r.DataType) {
                case this.DataType.AcceptLetterAndDigitOnly:
                    if (r.MinLength >= 0 && r.MaxLength > 0)
                        expression = new RegExp('^\\w{' + r.MinLength + ',' + r.MaxLength + '}$');
                    else if (r.MinLength > 0 && r.MaxLength == 0)
                        expression = new RegExp('^\\w{' + r.MinLength + ',}$');
                    else expression = new RegExp('^\\w+$');
                    return expression;
                    break;
                case this.DataType.AcceptNamingLetters:
                    if (r.MinLength > 0 && r.MaxLength > 0)
                        expression = new RegExp('^[a-zA-Z ._]{' + r.MinLength + ',' + r.MaxLength + '}$');
                    else if (r.MinLength == 0 && r.MaxLength > 0)
                        expression = new RegExp('^[a-zA-Z ._]{1,' + r.MaxLength + '}$');
                    else expression = new RegExp('^[a-zA-Z ._]+$');
                    return expression;
                    break;
                case this.DataType.AcceptNegativeAndDecimalDot:
                    if (r.MinLength == 0 && r.MaxLength > 0)
                        expression = new RegExp('^-?(\\d{1,' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                    if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal == 0 && r.MaxDecimal == 0)
                        expression = new RegExp('^-?\\d+$');
                    if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal > 0 && r.MaxDecimal > 0)
                        expression = new RegExp('^-?(\\d+)?(\\.?|\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                    expression = RegExp('^-?(\\d{' + r.MinLength + ',' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                    return expression;
                    break;
                case this.DataType.AcceptNegativeButNotDecimalDot:
                    if (r.MinLength > 0 && r.MaxLength > 0)
                        expression = new RegExp('^-?\\d{' + r.MinLength + ',' + r.MaxLength + '}$');
                    else if (r.MinLength == 0 && r.MaxLength > 0)
                        expression = new RegExp('^-?\\d{1,' + r.MaxLength + '}$');
                    else expression = new RegExp('^-?\\d+$');
                    return expression;
                    break;
                case this.DataType.Email:
                    expression = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+$/;
                    return expression;
                    break;
                case this.DataType.RejectNegativeandDecimalDot:
                    if (r.MinLength > 0 && r.MaxLength > 0)
                        expression = new RegExp('^\\d{' + r.MinLength + ',' + r.MaxLength + '}$');
                    else if (r.MinLength == 0 && r.MaxLength > 0)
                        expression = new RegExp('^\\d{1,' + r.MaxLength + '}$');
                    else expression = new RegExp('^\\d+$');
                    return expression;
                    break;
                case this.DataType.RejectNegativeButNotDecimalDot:
                    if (r.MinLength == 0 && r.MaxLength > 0)
                        expression = new RegExp('^(\\d{1,' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                    if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal == 0 && r.MaxDecimal == 0)
                        expression = new RegExp('^\\d+$');
                    if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal > 0 && r.MaxDecimal > 0)
                        expression = new RegExp('^(\\d+)?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                    expression = RegExp('^(\\d{' + r.MinLength + ',' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                    return expression;
                    break;
                case this.DataType.AnythingButNotSpecial:
                    return new RegExp(/^([a-zA-Z0-9_\s\-]*)$/);
                    break;
                case this.DataType.RegularExpression:
                    return new RegExp(r.RegularExpression);
                    break;
                case this.DataType.Anything:
                    if (r.MinLength > 0 && r.MaxLength > 0)
                        expression = new RegExp('^[\\S\\s]{' + r.MinLength + ',' + r.MaxLength + '}$');
                    else if (r.MinLength == 0 && r.MaxLength > 0)
                        expression = new RegExp('^[\\S\\s]{1,' + r.MaxLength + '}$');
                    else expression = new RegExp('^[\\S\\s]*$');
                    return expression;
                    break;
                case this.DataType.Temperature:
                    if (r.MinLength == 0 && r.MaxLength > 0)
                        expression = new RegExp('^-?(\\d{1,' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                    if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal == 0 && r.MaxDecimal == 0)
                        expression = new RegExp('^-?\\d+$');
                    if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal > 0 && r.MaxDecimal > 0)
                        expression = new RegExp('^-?(\\d+)?(\\.?|\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                    expression = RegExp('^-?(\\d{' + r.MinLength + ',' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                    return expression;
                    break;
            }
            return expression;
        }),
        Rules: (function () {
            var container = {};
            return {
                GetRules: (function (category) {
                    if (category) {
                        if (!container[category])
                            container[category] = [];
                        return container[category];
                    }
                })
            }
        })(),
        GetHtmlControls: (function () {
            var HtmlControls = $('#form1').find('input[type="text"],textarea,select,input[type="radio"]'), Controls = '';
            if (HtmlControls != null && HtmlControls != 'undefined') {
                $.each(HtmlControls, function (index, obj) {
                    Controls += obj.id + ',';
                });
                Controls = Controls.slice(0, Controls.length - 1);
            }
            return Controls;
        })
    };
})();

var ValidationHandler = (function () {
    var handlers = {};
    var getHtmlControls = (function () {
        var HtmlControls = $('#form1').find('input[type="text"],textarea,select,input[type="radio"]'), Controls = '';
        if (HtmlControls != null && HtmlControls != 'undefined') {
            $.each(HtmlControls, function (index, obj) {
                Controls += obj.id + ',';
            });
            Controls = Controls.slice(0, Controls.length - 1);
        }
        return Controls;
    });

    var exception = {
        tracker: null,
        handlerName: null
    };
    return {
        /// <summary>
        /// Act as a container for holding all the handlers
        /// </summary>
        Handler: (function () {
            return {
                Add: (function (key, value) {
                    this[key] = value;
                    return this;
                }),
                Get: (function (key) {
                    return this[key];
                })
            };
        })(),
        /// <summary>
        /// Validation Handlers are isolated by the category
        /// </summary>
        Category: (function () {
            var containers = {};
            var ruleset = {};
            var customRulesetAccessHandlers = {};
            return {
                Add: (function (key, value, container, rulesetID) {
                    this[key] = value;
                    if (container) {
                        containers[key] = '#' + container.replace(/#/g, '');
                    }
                    if (rulesetID) {
                        ruleset[key] = rulesetID;
                    }
                }),
                Serialize: (function (category) {
                    return $(containers[category] + ' *').serializeArray();
                }),
                GetRulesetID: (function (category) {
                    return ruleset[category];
                }),
                AddCustomRulesetAccessHandler: (function (category, handler) {
                    if (typeof (handler) === 'function') {
                        if (!customRulesetAccessHandlers[category]) {
                            customRulesetAccessHandlers[category] = handler;
                        }
                    }
                    else throw Error('Custom ruleset access handler should be function');
                }),
                GetCustomRulesetAccessHandler: (function (category) {
                    return (customRulesetAccessHandlers[category]) ? customRulesetAccessHandlers[category] : null;
                })
            };
        })(),
        /// <summary>
        /// Contains the messages isolated by category
        /// </summary>
        MessageStore: (function () {
            var key = 'Message';
            return {
                Add: (function (handler, category, msg) {
                    if (!handlers[category][key]) handlers[category][key] = {};
                    if (!handlers[category][key][handler]) handlers[category][key][handler] = {};
                    if (typeof (msg) == 'string') handlers[category][key][handler] = '<li>' + msg + '</li>';
                    else handlers[category][key][handler] = msg;
                }),
                GetMessage: (function (category) {
                    if (!handlers[category][key]) return null;
                    return handlers[category][key];
                }),
                GetMessageById: (function (category, id) {
                    var message = "";
                    if (!handlers[category][key]) return null;
                    $.each(handlers[category].Rules, function (i, rule) {
                        if (rule[0] == id && message == "") {
                            message = rule[1];
                        }
                    });
                    return message;
                }),
                FormatMessage: (function (category, handlerName, arg1, arg2, arg3, arg4, arg5) {
                    var message = handlers[category][key][handlerName];
                    if (arg1) message = message.format(arg1);
                    if (arg2) message = message.format(arg2);
                    if (arg3) message = message.format(arg3);
                    if (arg4) message = message.format(arg4);
                    if (arg5) message = message.format(arg5);
                    handlers[category][key][handlerName] = message;
                })
            };
        })(),
        /// <summary>
        /// Used to add the validation handler
        /// </summary>
        Add: (function (handler, category, fn, errorMsg) {
            var h = 'Handlers', r = 'Rules', results = 'Results';
            handler = handler.toString();
            if (!handlers[category]) handlers[category] = {};
            if (!handlers[category][h]) handlers[category][h] = {};
            if (handlers[category][h][handler])
                throw Error('The handler (' + handler + ') has been already  added!');
            else handlers[category][h][handler] = fn;
            if (!handlers[category][r]) handlers[category][r] = [];
            if (!handlers[category][results]) handlers[category][results] = {};
            this.MessageStore.Add(handler, category, errorMsg);
        }),
        /// <summary>
        /// Used to load the validation rules for the perticular category
        /// </summary>
        Load: (function (category, url) {
            if (handlers[category].Rules.length == 0) {
                Ajax.RequestManager().Enqueue({
                    url: url,
                    type: 'POST',
                    data: { htmlControls: getHtmlControls() },
                    success: function (Result) {
                        handlers[category].Rules = Result.Rule;
                    },
                    message: 'Loading validation rules ...'
                });
            }
        }),
        /// <summary>
        /// Used to clears the rules of the category
        /// </summary>
        ClearRules: (function (category) {
            if (handlers[category])
                handlers[category].Rules = [];
        }),
        /// <summary>
        /// Used to re - load the validation rules for the perticular category
        /// </summary>
        Reload: (function (category, url) {
            if (IboxV5.UI.Toolbar.GetMode().Equals(IboxV5.UI.Toolbar.Edit) || IboxV5.UI.Toolbar.GetMode().Equals(IboxV5.UI.Toolbar.Clear)) {
                if (handlers[category].Rules.length == 0 || category === 'Header') {
                    Ajax.RequestManager().Enqueue({
                        url: url,
                        type: 'POST',
                        data: { htmlControls: getHtmlControls() },
                        success: function (Result) {
                            handlers[category].Rules = Result.Conditional;
                        },
                        message: 'Loading validation rules ...'
                    });
                }
            }
        }),
        /// <summary>
        /// Used to append the rules of the particular category
        /// </summary>
        AddRules: (function (category, rules) {
            IboxV5.TryCatch(function () {
                if (rules.length > 0) {
                    if (!handlers[category])
                        throw Error('The category ' + category + ' is not found!');
                    handlers[category].Rules = rules;
                }
            });
        }),
        /// <summary>
        /// Serializes the form fields, and converts it into the actual client side model
        /// </summary>
        GetModel: (function (formCollection, excludeProperties) {
            formCollection = formCollection || $('#form1').serializeArray();
            var serialize = function () {
                var duplication = {};
                formCollection = formCollection
                    .filter(function (e, i, a) {
                        var canInclude = true;
                        if (e.name === '__RequestVerificationToken') canInclude = false;
                        else if (e.name.match(/_DDDWS/g)
                            || e.name.match(/_DDD_LDeletedItems/g)
                            || e.name.match(/_DDD_LInsertedItems/g)
                            || e.name.match(/_DDD_LCustomCallback/g)
                            || e.name.match(/_VI/g)
                            || e.name.match(/\$DXFREditorcol/g)
                            || e.name.match(/_DXHFPWS/g)
                            || e.name.match(/_DXPagerBottom_PSPSI/g)
                            || e.name.match(/\$DXSelInput/g)
                            || e.name.match(/\$DXKVInput/g)
                            || e.name.match(/\$CallbackState/g)
                            || e.name.match(/\$DXSyncInput/g)
                            || e.name.match(/_DXFilterRowMenuCI/g)
                            || e.name.match(/_ListWS/g)
                            || e.name.match(/DXScript/g)
                            || e.name.match(/DXMVCEditorsValues/g)
                            || e.name.match(/_Raw/g)
                            || e.name.match(/_DDD_C_FNPWS/g)
                            || e.name.match(/\$DDD\$C/g)
                            ) canInclude = false;
                        else if (e.name.match(/\$DDD\$L/g)) {
                            e.name = e.name.replace(/\$DDD\$L/g, '');
                            duplication[e.name] = e.value;
                            canInclude = false;
                        }
                        else if (e.value === 'false') {
                            if (duplication[e.name] === 'true') {
                                canInclude = false;
                            }
                            else duplication[e.name] = e.value;
                        }
                        else if (e.value === 'true') {
                            if (duplication[e.name] === 'false') {
                                duplication[e.name] = e.value;
                                canInclude = false;
                            }
                            else duplication[e.name] = e.value;
                        }
                        return canInclude;
                    });
                formCollection = formCollection.filter(function (e, i, a) {
                    if (duplication[e.name] && duplication[e.name] !== 'false') {
                        e.value = duplication[e.name];
                    }
                    return true;
                });
                duplication = null;
                var model = {};
                convertToObject(formCollection, model);
                return model;
            },
                convertToObject = function (arr, model) {
                    for (var i = 0; i < arr.length; i++) {
                        var properties;
                        if (excludeProperties) {
                            if (arr[i].name.indexOf(excludeProperties) == -1) {
                                properties = arr[i].name.split('.');
                                bind(model, properties, arr[i].value);
                            }
                        }
                        else {
                            properties = arr[i].name.split('.');
                            bind(model, properties, arr[i].value);
                        }
                    }
                },
                bind = function (model, propArr, value) {
                    for (var i = 0; i < propArr.length; i++) {
                        if (i == propArr.length - 1) {
                            model[propArr[i]] = value;
                        }
                        else {
                            if (!model[propArr[i]]) model[propArr[i]] = {};
                            var arr = propArr.splice(0, 1);
                            bind(model[arr[0]], propArr, value);
                        }
                    }
                };
            return serialize();
        }),
        /// <summary>
        /// Executes all the handlers of the particular category and returns the error message
        /// </summary>
        Execute: (function (category, vType) {
            var model = this.GetModel($('#form1').serializeArray(), category);
            //if (!vType) { if (console) { console.log("No Validation Type Found:" + category + "\nCallee:" + arguments.callee.toString()) } }
            model['Details'] = model['Details'] || {};
            model['Details'][category] = model['Details'][category] || this.GetModel(this.Category.Serialize(category))[category];
            var key = 'Message';
            this.Message = '';
            var handler = handlers[category];
            if (handler) {
                var rules = null;
                if (vType) { rules = handler.Rules.filter(function (r) { return IboxV5.Validator.GetMessageType(r[2]) === vType; }); }
                else { rules = handler.Rules; }
                var self = this;
                $.each(handler.Handlers, function (fnName, h) {
                    self.ExceptionTraker().SetHandler(fnName);
                    var msg = null;
                    var has = rules.some(function (e, index, a) {
                        var f = e[0] == fnName;
                        if (f) {
                            if (e[1] === '')
                                handler[key][fnName] = '<li>No message is defined for the rule \'' + fnName + '\'</li>';
                            else
                                handler[key][fnName] = '<li title="' + fnName + '">' + e[1] + '</li>';
                        }
                        return f;
                    });
                    if (has) {
                        if (h(model, self, handlers[category]['Results']) == false) {
                            if (typeof (handler[key][fnName]) === 'string')
                                self.Message += handler[key][fnName];
                            handlers[category]['Results'][fnName] = false;
                        }
                        else handlers[category]['Results'][fnName] = true;
                    }
                    self.ExceptionTraker().ReleaseHandler();
                });
            }
            return this.Message;
        }),
        /// <summary>
        /// Used to check whether the form fiedls is valid or not
        /// </summary>
        IsValid: (function (category) {
            return this.Message == null;
        }),
        /// <summary>
        /// Used to hold the validation failure message
        /// </summary>
        Message: null,
        /// <summary>
        /// Used to track the last handler that causing the exception
        /// </summary>
        ExceptionTraker: (function () {
            var initTracker = (function () {
                return {
                    SetHandler: (function (name) {
                        exception.handlerName = name;
                    }),
                    ReleaseHandler: (function () {
                        exception.handlerName = null;
                    }),
                    GetHandler: (function () {
                        return exception.handlerName;
                    }),
                    IsExceptionTracked: (function () {
                        return exception.handlerName != null;
                    })
                };
            });
            if (!exception.tracker) exception.tracker = initTracker();
            return exception.tracker;
        })
    };
})();

function GetStatusDetail(value, desc) {
    var cssClass;
    if (value == 'A')
        cssClass = 'actstat';
    else if (value == 'I')
        cssClass = 'inactstat';
    else if (value == 'PA')
        cssClass = 'penstat';
    else if (value == 'DEL')
        cssClass = "delstat";
    else if (value == "D")
        cssClass = "draftstat";
    else if (value == "R")
        cssClass = "rejstat";
    else if (value == "NI")
        cssClass = "notimportedstat";
    else if (value == "TR")
        cssClass = "toreviewstat";
    return "<div class='" + cssClass + "'>" + desc + "</div>";
}

function CheckBoxGroup(id) {
    var me = this;
    this.TextField = "";
    this.Id = id;
    this.ValueField = "";
    this.DataSource = "";
    this.Holder = "";
    this.isbool = false;
    this.InputElement = "";
    this.Items = [];
    this.Wrapper = [];
    this.PreviousSelectedData = [];
    this.Component = function (id) {
        return this.Components[id];
    };
    this.AddItems = function (data) {
        $.each(data, function (i, v) {
            me.AddItem(v, i);
        })
    };
    this.AddItem = function (data) {
        var i = me.Items.length;
        me.AddItem(data, i);
    };
    this.AddItem = function (v, i) {
        me.Items[i] = {
            item: v,
            index: i,
            isSelected: false,
            id: me.Id + "_" + i,
            wrapper: me.ItemTempalte(me.Id + "_" + i, v[me.ValueField], v[me.TextField])
        }
        me.Wrapper += me.Items[i].wrapper;
    };
    this.SelectedItems = function (data) {
        $.each(data, function (i, v) {
            me.UpdateGroup(me.Items.findIndex(function (d) { return d.item[me.ValueField] === v[me.ValueField]; }));
        })
    };
    this.GetSelectedItems = function () {
        return me.Items.filter(function (v) { return v.isSelected === true; })
    }
    this.ItemTempalte = function (id, val, lbl) {
        return '<div class="form-group"><input class="k-checkbox" data-val="true" id="' + id + '_chk" type="checkbox" onclick="MSCJS.HTMLHelpers.ClientEvents.CheckBoxGroup.OnClick(\'' + me.Id + '\',\'' + id + '\')" value="' + val + '"><label class="k-checkbox-label" for="' + id + '_chk">' + lbl + '</label></div>'
    };
    this.NewComponentAndSelectItem = function (d, i) {
        this.NewComponent(d, i);
        $("#" + d.id + "_grp").html(me.Wrapper);
        this.SelectedItems(d.selectedItems);
    },
    this.NewComponent = function (detail, items) {
        me.id = detail.id;
        me.ValueField = detail.valueField;
        me.TextField = detail.textField;
        me.DataSource = {
            controller: detail.controller,
            actionname: detail.action,
        }
        me.Wrapper = "";
        if (items) {
            me.AddItems(items);
        }
    };
    this.UpdateGroup = function (i) {
        if (i >= 0) {
            if (me.Items[i]) {
                me.Items[i].isSelected = !me.Items[i].isSelected;
                $("#" + me.Items[i].id + "_chk").prop("checked", me.Items[i].isSelected);
            }
        }
    }
}