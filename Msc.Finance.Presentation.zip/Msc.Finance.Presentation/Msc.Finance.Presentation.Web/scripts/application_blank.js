
/* ========================================================
*
* Londinium - premium responsive admin template
*
* ========================================================
*
* File: application_blank.js;
* Description: Minimum of necessary js code for blank page.
* Version: 1.0
*
* ======================================================== */



$(function () {




    /* # Default Layout Options
    ================================================== */

    //===== Wrapping content inside .page-content =====//

    $('.page-content').wrapInner('<div class="page-content-inner"></div>');



    //===== Applying offcanvas class =====//

    $(document).on('click', '.offcanvas', function () {
        $('body').toggleClass('offcanvas-active');
    });



    //===== Default navigation =====//

    $('.navigation ul').find('li.active').parents('li').addClass('active');
    $('.navigation ul').find('li').not('.active').has('ul').children('ul').addClass('hidden-ul');
    $('.navigation ul').find('li').has('ul').children('a').parent('li').addClass('has-ul');
    SetParentMenuToDefault();

    $(document).on('click', '.sidebar-toggle', function (e) {
        e.preventDefault();

        $('body').toggleClass('sidebar-narrow');

        if ($('body').hasClass('sidebar-narrow')) {
            $('.navigation').children('li').children('ul').css('display', '');

            $('.sidebar-content').hide().delay().queue(function () {
                $(this).show().addClass('animated fadeIn').clearQueue();
            });
        }

        else {


            $('.sidebar-content').hide().delay().queue(function () {
                $(this).show().addClass('animated fadeIn').clearQueue();
            });
        }
    });


    $('.navigation').find('li').has('ul').children('a').on('click', function (e) {
        e.preventDefault();

        if ($('body').hasClass('sidebar-narrow')) {
            $(this).parent('li > ul li').not('.disabled').toggleClass('active').children('ul').slideToggle(250);
            $(this).parent('li > ul li').not('.disabled').siblings().removeClass('active').children('ul').slideUp(250);
        }

        else {
            $(this).parent('li > ul li').not('.disabled').toggleClass('active').children('ul').slideToggle(250);
            $(this).parent('li > ul li').not('.disabled').siblings().removeClass('active').children('ul').slideUp(250);
        }
    });



    //===== Panel Options (collapsing, closing) =====//

    /* Collapsing */
    $('[data-panel=collapse]').click(function (e) {
        e.preventDefault();
        var $target = $(this).parent().parent().next('div');
        if ($target.is(':visible')) {
            $(this).children('i').removeClass('icon-arrow-up9');
            $(this).children('i').addClass('icon-arrow-down9');
        }
        else {
            $(this).children('i').removeClass('icon-arrow-down9');
            $(this).children('i').addClass('icon-arrow-up9');
        }
        $target.slideToggle(200);
    });

    /* Closing */
    $('[data-panel=close]').click(function (e) {
        e.preventDefault();
        var $panelContent = $(this).parent().parent().parent();
        $panelContent.slideUp(200).remove(200);
    });



    //===== Disabling main navigation links =====//

    $('.navigation .disabled a, .navbar-nav > .disabled > a').click(function (e) {
        e.preventDefault();
    });


});


function jsUpdateSize() {
    // Get the dimensions of the viewport
    var width = window.innerWidth ||
                document.documentElement.clientWidth ||
                document.body.clientWidth;
    var height = window.innerHeight ||
                 document.documentElement.clientHeight ||
                 document.body.clientHeight;

    mediaquery();
};
window.onload = jsUpdateSize;       // When the page first loads
window.onresize = jsUpdateSize;

jQuery(function ($) {

    $('#filter').on('click', function () {
        var $el = $(this),
            textNode = this.lastChild;

        if (textNode.nodeValue == 'SHOW FILTER') {
            textNode.nodeValue = "HIDE FILTER";
        }
        else {
            textNode.nodeValue = "SHOW FILTER";
        }

    });
});

$('#filter').on('click', function () {
    var panel = $('#slide-panel');
    if (panel.hasClass("visible")) {
        panel.removeClass('visible').animate({ 'display': 'block !important' });
    } else {
        panel.addClass('visible').animate({ 'display': 'none !important' });
    }
    return false;
});

function mediaquery() {
    if ($(window).width() < 1170) {

        $('body').addClass('sidebar-narrow');

    }
    else {
        $('body').removeClass('sidebar-narrow');
    }

}

function ToggleSideBar(hide, show) {
    $(hide).toggle("slide");
    setTimeout(function () {
        $(show).toggle("slide");
    }, 1);

}

function LoadPage(parentDiv, viewName, needToogle) {
    var url = viewName;
    $.get(url, function (data) {
        $('#' + parentDiv).html(data);
    });
    if (needToogle) { $('#' + parentDiv).toggleClass('hidden'); }
    return false;
}

function accordionarrow() {
    $('.panel-collapse').on('shown.bs.collapse', function () {
        $(this).parent().find(".icon-arrow-right5").removeClass(".icon-arrow-right5").addClass("icon-arrow-down5");
    }).on('hidden.bs.collapse', function () {
        $(this).parent().find("icon-arrow-down5").removeClass("icon-arrow-down5").addClass(".icon-arrow-right5");
    });
}

function SetParentMenuToDefault() {
    $.each($('.submenu li a.activestat'), function (i, v) {
        $(v).parents('.submenu').css("display", "block");
        $(v).parents('.has-ul').addClass('active');
    });
}