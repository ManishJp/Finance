/**
 * Created by windmill version 0.1.2
 */

(function(root) {
	root.msc = {
		routeChart: {}
	};

	root.msc.routeChart.PaperWrapperView = Backbone.View.extend({
		initialize: function() {
			this.paper = new joint.dia.Paper({
				tagName: 'div',
			    className: 'chart-container',
			    width: 600,
			    height: 250,
			    model: this.model,
			    gridSize: 1,
			    linkView : joint.shapes.routeChart.LinkView,
			    interactive: function(cellView) {
			        if (cellView.model instanceof joint.dia.Link) {
			            // Disable the default vertex add functionality on pointerdown.
			            if (graph.getCell(cellView.model.get("source").id) instanceof  joint.shapes.routeChart.LegItem) {
			                return false;
			            }
			            return { vertexAdd: false };
			        } else if (cellView.model instanceof joint.shapes.routeChart.ChartItem) {
			            return false;
			        }
			        return true;
			    }
			});
			this.confirmation = new kendo.backbone.ConfirmationView ({
				el: '#routeChart .delete-confirmation-window',
				model: this.model
			});
			this.model.on("updatePaper", this._updatePaper, this);
			this.paper.on("cell:mouseover", _.bind(this.model._onLinkOver, this.model));
			this.paper.on("cell:mouseout", _.bind(this.model._onLinkOut, this.model));
			this.render();
		},

		render : function () {
		    this.$el.append(this.paper.render().el);
		},
		_updatePaper: function (width, height, scrollOffset) {
		    var svgW = Math.max(width, $("#routeChart .chart-container").width());
		    var svgH = Math.max(height, $("#routeChart .chart-container").height());
		    if (scrollOffset != 0) {
		    	var element = $("#routeChart .chart-container");
		    	element.scrollLeft(element.scrollLeft() + scrollOffset);
		    }
		    this.paper.setDimensions(svgW, svgH);
            if (svgW != width) {
                var allCells = graph.getCells ();
                _.each (allCells, function (c) {
                    c.translate ((svgW-width)/2, 0);
                });
            }
		}
	})

})(this);
