(function() {
	'use strict';
	
	// definition
	msc.routeChart.Services = Backbone.Collection.extend({
	    url: 'http://azsa-fte.cloudapp.net:49421/api/service',
		parse: function(response) {
			console.info('Received services');
        	return response;
        }
    });
})();