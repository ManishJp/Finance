(function() {
	'use strict';
	
	// definition
	msc.routeChart.DwellTime = Backbone.Model.extend({
	    url: 'http://azsa-fte.cloudapp.net:49421/api/port/dwell',
		parse: function(response) {
        	var result = {
        		time: response
        	};
        	console.info('Received dwell time');
        	return result;
        }
    });
})();