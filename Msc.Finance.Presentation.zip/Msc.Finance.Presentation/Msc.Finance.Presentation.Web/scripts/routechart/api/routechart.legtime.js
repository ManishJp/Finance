(function() {
	'use strict';
	
	// definition
	msc.routeChart.LegTime = Backbone.Model.extend({
	    url: 'http://azsa-fte.cloudapp.net:49421/api/service/leg',
		parse: function(response) {
        	var result = {
        		time: response
        	};
        	console.info('Received leg time');
        	return result;
        }
    });
})();