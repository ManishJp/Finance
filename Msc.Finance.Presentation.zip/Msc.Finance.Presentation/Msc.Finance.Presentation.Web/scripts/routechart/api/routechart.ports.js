(function() {
	'use strict';

	// definition
	msc.routeChart.Ports = Backbone.Collection.extend({
	    url: 'http://azsa-fte.cloudapp.net:49421/api/port',
		parse: function(response) {
			console.info('Received ports');
        	return response;
        }
    });
})();
