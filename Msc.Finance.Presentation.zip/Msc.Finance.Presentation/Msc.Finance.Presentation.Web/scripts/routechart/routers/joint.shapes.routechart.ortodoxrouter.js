/**
 * Created by windmill version 0.1.2
 */

(function() {
	joint.routers.OrtodoxRouter = function(vertices, opt, linkView) {
	
	    var padding = opt.padding || 12;
	    var gap = opt.gap || 25;
	    var sourceBBox = linkView.sourceBBox;
	    var targetBBox = linkView.targetBBox;
	    var sourcePoint = sourceBBox.center();
	    var targetPoint = targetBBox.center();
	
	    var source = linkView.model.graph.getCell (linkView.model.get("source").id)
	    var sourceIsService = source ? !(source.isService ()) : false;
	
	    // move the points from the center of the element to outside of it.
	    if (sourceIsService) {
	        sourcePoint['x'] += (sourceBBox['width'] / 2 + (gap - padding));
	        targetPoint['x'] += -1 * (targetBBox['width'] / 2 + padding);
	    } else {
	        sourcePoint['x'] += (sourceBBox['width'] / 2 + padding);
	        targetPoint['x'] += -1 * (targetBBox['width'] / 2 + (gap - padding));
	    }
	
	    return [sourcePoint].concat(vertices, targetPoint);
	};
})();