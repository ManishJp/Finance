/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    // definition
    joint.shapes.routeChart.LegItem = joint.shapes.routeChart.ChartItem.extend({
        defaults: joint.util.deepSupplement({
            type: 'routeChart.LegItem'
        }, joint.shapes.routeChart.ChartItem.prototype.defaults)
    });

})();
