/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    // globals
    var graphSequence = {};
    var linkSequence = {};
    var legsSequence = {};

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    // definition
    joint.shapes.routeChart.Graph = joint.dia.Graph.extend({
        defaults: {
            layoutOptions: {gap: 60, padding: 50, elementWidth: 180, elementHeight: 160, yOffset1:45, yOffset2:135, legYOffset:-40}
        },
        initialize: function(attrs, options) {
            joint.dia.Graph.prototype.initialize.apply(this, arguments);

            var exposedEvents = _.uniq(_.union(
                joint.shapes.routeChart.ServiceItem.getEventsList()
                ,joint.shapes.routeChart.TSPItem.getEventsList()
            )).join(" ");

            this.on(exposedEvents, this._dispatchExternalEvent, this);
            this._addListeners();
        },

        _dispatchExternalEvent : function () {
          console.debug ("dispatch external", arguments);
          this.trigger ("patternChanged");
        },

        getPattern: function() {
        	var pattern = [];
        	graphSequence[this.cid].forEach(function(element) {
        		if (element.isService()) {
        			var service = {
        				serviceCode: element.get('serviceCode')
        			}
        			var sourcePortItem = element.getSourcePortItem();
        			if (sourcePortItem !== undefined) {
        				service.polCode = sourcePortItem.get('portCode');
        				service.polTerminal = sourcePortItem.get('dispatchTerminal');
                        service.polCallId = sourcePortItem.get ('dispatchCallId');
        			}
        			var destinationPortItem = element.getDestinationPortItem();
        			if (destinationPortItem !== undefined) {
        				service.podCode = destinationPortItem.get('portCode');
        				service.podTerminal = destinationPortItem.get('loadingTerminal');
                        service.podCallId = destinationPortItem.get ('loadingCallId');
                    }
        			pattern.push(service);
        		}
        	});
        	return pattern;
        },
        getValidRoutes: function() {
        	if (_.every(graphSequence[this.cid], function(element) {
        		if (element.isService()) {
        			return (element.get('overallStatus') == 3 || element.get('overallStatus') == 2);
        		} else {
        			return true;
        		}
        	})) {
        		var polList = this._getConnectedPols();
        		var podList = this._getConnectedPods();

        		return _.filter(this._inputRoutes, function(route) {
        			return polList.indexOf(route.polCode) !== -1 && podList.indexOf(route.podCode) !== -1;
        		})
        	} else {
        		return [];
        	}
        },
        setData: function(routes, pattern) {
            this._inputRoutes = routes;
            this._sourcePorts = _.filter(_.map(routes, function(route) {
                return route.polCode;
            }), function(portCode, index, array) {
                return array.lastIndexOf(portCode) === index;
            });
            this._destinationPorts = _.filter(_.map(routes, function(route) {
                return route.podCode;
            }), function(portCode, index, array) {
                return array.lastIndexOf(portCode) === index;
            });
            this._createElements(this._sourcePorts, pattern, this._destinationPorts);
        },
        _listenersAdded:false,
        _addListeners : function () {

            if(!this._listenersAdded) {
                this.on('remove', this._onRemoveElements, this);
                this.on('addItemBefore', this._insertServiceItemBefore, this);
                this.on('addItemAfter', this._insertServiceItemAfter, this);

                this.on('change:legTime', this._updateLegItem, this);
                this.on('change:dwellTime', this._updateLegItem, this);

                this.trigger("listenersAdded");
                this._listenersAdded = true;
            }
        },

        _removeListeners : function () {

            if (this._listenersAdded) {
                this.off('remove', this._onRemoveElements, this);
                this.off('addItemBefore', this._insertServiceItemBefore, this);
                this.off('addItemAfter', this._insertServiceItemAfter, this);
                this.off('changeModel', this._updateItemModel, this);

                this.off('change:legTime', this._updateLegItem, this);
                this.off('change:dwellTime', this._updateLegItem, this);

                this.trigger ("listenersRemoved");
                this._listenersAdded = false;
            }
        },

        _updateLegItem: function (cell) {

            console.debug ("_updateItemModel", arguments);
            var index = _.indexOf(graphSequence[this.cid], cell);
            var leg = legsSequence[this.cid][index-1];
            if (leg) {
                if (_.has(cell.changed, "legTime")) {
                    leg.set({
                        time: cell.changed.legTime,
                        index: index,
                        type: joint.shapes.routeChart.ServiceItem
                    });
                } else if (_.has(cell.changed, "dwellTime")) {
                    leg.set({
                        time: cell.changed.dwellTime,
                        index: index,
                        type: joint.shapes.routeChart.TSPItem
                    });
                }
            }
        },
        _getConnectedPols: function() {
        	if (_.every(graphSequence[this.cid], function(element) {
        		if (element.isService()) {
        			return (element.get('overallStatus') == 3 || element.get('overallStatus') == 2);
        		} else {
        			return true;
        		}
        	})) {
                var serviceItem = graphSequence[this.cid][0];

                var selectedService = serviceItem.getSelectedService();
                if (selectedService !== undefined) {
                	var destinationReachable = _.some(serviceItem._portCollection.models, function(portModel) {
    	        		return _.some(serviceItem.getDestinationPorts(), function(destinationPortCode) {
    	            		return portModel.get('Code') === destinationPortCode;
    	            	});
                	});
                	if (destinationReachable) {
                		return _.filter(serviceItem.getSourcePorts(), function(sourcePortCode) {
                			return _.some(serviceItem._portCollection.models, function(portModel) {
                				return portModel.get('Code') === sourcePortCode;
                        	});
	            		});
                	}
                }
        	}
        	return [];
        },
        _getConnectedPods: function() {
        	if (_.every(graphSequence[this.cid], function(element) {
        		if (element.isService()) {
        			return (element.get('overallStatus') == 3 || element.get('overallStatus') == 2);
        		} else {
        			return true;
        		}
        	})) {
	        	var serviceItem = graphSequence[this.cid][graphSequence[this.cid].length - 1];

	        	var selectedService = serviceItem.getSelectedService();
	        	if (selectedService !== undefined) {
                	var sourceReachable = _.some(serviceItem._portCollection.models, function(portModel) {
    	        		return _.some(serviceItem.getSourcePorts(), function(sourcePortCode) {
    	            		return portModel.get('Code') === sourcePortCode;
    	            	});
                	});
                	if (sourceReachable) {
                		return _.filter(serviceItem.getDestinationPorts(), function(destinationPortCode) {
                			return _.some(serviceItem._portCollection.models, function(portModel) {
                				return portModel.get('Code') === destinationPortCode;
                        	});
	            		});
                	}
                }
        	}
        	return [];
        },
        _clearGraph: function() {
            this.clear();
            graphSequence[this.cid] = [];
            legsSequence[this.cid] = [];
            linkSequence[this.cid] = [];
        },

        _createElements: function(polPorts, pattern, podPorts) {
            var sourcePorts;
            var destinationPorts;
            var previousPort;
            var nextPort;
            var service;

            console.info('Started the graph initialization');
            this._clearGraph();
            if (pattern === undefined || pattern.length <= 1) {
                var serviceLink = (pattern != undefined && pattern.length === 1) ? pattern[0] : undefined;
                graphSequence[this.cid].push(this._createService(polPorts, podPorts, serviceLink));
            } else {

                for (var index = 0; index < pattern.length; index++) {
                    if (index === 0) {
                        sourcePorts = polPorts
                    } else {
                        sourcePorts = [pattern[index].polCode];
                    }
                    if (index === pattern.length - 1) {
                        destinationPorts = podPorts;
                    } else {
                        destinationPorts = [pattern[index].podCode]
                    }
                    service = this._createService(sourcePorts, destinationPorts, pattern[index]);
                    graphSequence[this.cid].push(service);
                    if (previousPort !== undefined) {
                        previousPort.setPrevLoadingTerminal (pattern[index]);
                        this._connectPortServiceSequence(previousPort, service);
                    }
                    if (index != pattern.length - 1) {
                        nextPort = this._createPort(
                            pattern[index].podCode,
                            pattern[index].podTerminal,
                            pattern[index].podCallId
                        );
                        graphSequence[this.cid].push(nextPort);
                        this._connectServicePortSequence(service, nextPort)
                    }
                    previousPort = nextPort;
                }
            }
            this.addCells(graphSequence[this.cid]);
            this._createLegs();
            this._createLinks();
            this._sequencePositions();
            console.info('Graph initialization complete');
        },
        _insertServiceItemBefore: function(serviceItem) {

        	var index = _.findIndex(graphSequence[this.cid], function(element) {
        		return serviceItem.id === element.id;
        	});
        	var sourcePortItem = serviceItem.get('sourcePortItem');
        	var newServiceItem = this._createService(serviceItem.get('sourcePorts'), []);
        	var newPortItem = this._createPort();

        	this._connectServicePortSequence(newServiceItem, newPortItem);
        	this._connectPortServiceSequence(sourcePortItem, newServiceItem);
        	this._connectPortServiceSequence(newPortItem, serviceItem);

        	var serviceLeg, portLeg;
            if (graphSequence[this.cid].length != 1) {
	        	if (index == 0) {
	                serviceLeg = this._createLeg(graphSequence[this.cid][index], index);
	            } else {
	                serviceLeg = this._createLeg(newServiceItem, index + 1);
	            }
	        	portLeg = this._createLeg(newPortItem, index + 2);
	        	legsSequence[this.cid].splice(index, 0, serviceLeg, portLeg);

	        	this.addCells([newServiceItem, newPortItem, serviceLeg, portLeg]);
            } else {
               	portLeg = this._createLeg(newPortItem, 0);
                legsSequence[this.cid].splice(index, 0, portLeg);
            	this.addCells([newServiceItem, newPortItem, portLeg]);
            }
        	graphSequence[this.cid].splice(index, 0, newServiceItem, newPortItem);
            
        	this._sequencePositions('addLeft');

            this._removeListeners();
            this._removeLinks ();
            this._createLinks ();
            this._addListeners();

        },
        _insertServiceItemAfter: function(serviceItem) {

        	var index = _.findIndex(graphSequence[this.cid], function(element) {
        		return serviceItem.id === element.id;
        	});
        	var destinationPortItem = serviceItem.get('destinationPortItem');
        	var newServiceItem = this._createService([], serviceItem.get('destinationPorts'));
        	var  newPortItem = this._createPort();

        	this._connectPortServiceSequence(newPortItem, newServiceItem);
        	this._connectServicePortSequence(newServiceItem, destinationPortItem);
        	this._connectServicePortSequence(serviceItem, newPortItem);
        	if (destinationPortItem !== undefined) {
	        	newServiceItem.setDestinationPortItem(destinationPortItem);
	        	destinationPortItem.setSourceServiceItem(newServiceItem);
        	}

            var portLeg, serviceLeg;
            if (graphSequence[this.cid].length != 1) {
                if (index >= graphSequence[this.cid].length -1) {
                    serviceLeg = this._createLeg (graphSequence[this.cid][index], index);
                } else {
                    serviceLeg = this._createLeg (newServiceItem, index + 2);
                }
	            portLeg = this._createLeg (newPortItem, index + 1);
	            legsSequence[this.cid].splice(index + 1, 0, portLeg, serviceLeg);
	        	this.addCells([newPortItem, newServiceItem, portLeg, serviceLeg]);
            } else {
               	portLeg = this._createLeg(newPortItem, 0);
	            legsSequence[this.cid].splice(index + 1, 0, portLeg);
	        	this.addCells([newPortItem, newServiceItem, portLeg]);
	        }
            graphSequence[this.cid].splice(index + 1, 0, newPortItem, newServiceItem);

        	this._sequencePositions('addRight');

            this._removeListeners();
            this._removeLinks ();
            this._createLinks ();
            this._addListeners();

        },

        _onRemoveElements: function (cell) {

            if (cell.isLink()) {
                this._lastRemovedLink = cell;
            }
        },

        _lastRemovedLink:null,

        cancelRemove : function () {

            this._lastRemovedLink = null;

            this._removeListeners();
            this._removeLinks();
            this._createLinks();
            this._addListeners();

            _.each (graphSequence[this.cid], function (cell) {
                cell.set ("highlight", false);
            })
        },

        confirmRemove : function () {

            if (!this._lastRemovedLink) return;

            this._removeListeners();

            var cell = this._lastRemovedLink;
            var srcCell = this.getCell(cell.attributes.source.id);
            var targetCell = this.getCell(cell.attributes.target.id);
            var action = ''
            if (srcCell.isService()) {
            	action = 'removeRight';
            } else {
            	action = 'removeLeft';
            }

            var index, legIndex, leg, removeSrc=true, removeTarget=true, services = this._getServices(),
                prevItem, nextItem;

            var outboundLinks = this.getConnectedLinks(srcCell);
            _.each(outboundLinks, function (link) {
                link.disconnect();
            });
            outboundLinks = this.getConnectedLinks(targetCell);
            _.each(outboundLinks, function (link) {
                link.disconnect();
            });

            if (srcCell.isService) removeSrc = (services.length > 1);
            if (targetCell.isService) removeTarget = (services.length > 1);

            if (removeTarget) {

                index = _.findIndex(graphSequence[this.cid], function(element) {
                    return targetCell.id === element.id;
                });
                if (index < graphSequence[this.cid].length-1) nextItem = graphSequence[this.cid][index+1]

                targetCell.remove();
                graphSequence[this.cid].splice(index, 1);

            }

            if (removeSrc) {
                index = _.findIndex(graphSequence[this.cid], function(element) {
                    return srcCell.id === element.id;
                });
                if (index > 0) prevItem = graphSequence[this.cid][index -1];
                srcCell.remove();
                graphSequence[this.cid].splice(index, 1);

            }

            // remove legs
            while ((legsSequence[this.cid].length > graphSequence[this.cid].length-2) && (legsSequence[this.cid].length> 0)) {
                legsSequence[this.cid][0].remove ();
                legsSequence[this.cid].splice (0, 1);
            }

            // update rest legs
            _.each (graphSequence[this.cid], function (cell) {
                this._updateLegItem (cell);
            }, this)

            // reconnect items
            if (prevItem && nextItem) {
                if (prevItem.isService ()) this._connectServicePortSequence(prevItem, nextItem);
                else if (nextItem.isService ()) this._connectPortServiceSequence(prevItem, nextItem);
            } else if (prevItem) {
                prevItem.setDestinationPortItem (void 0);
                prevItem.setDestinationPorts (targetCell.getDestinationPorts ());
            } else if (nextItem) {
                nextItem.setSourcePortItem (void 0);
                nextItem.setSourcePorts (srcCell.getSourcePorts ());
            }

            this._sequencePositions(action);
            this.trigger ("confirmationClose", {});
        },
        _connectServicePortSequence: function(serviceItem, portItem) {
        	serviceItem.setDestinationPortItem(portItem);
        	if (portItem !== undefined) {
        		portItem.setSourceServiceItem(serviceItem);
        	}
        },
        _connectPortServiceSequence: function(portItem, serviceItem) {
        	if (portItem !== undefined) {
        		portItem.setDestinationServiceItem(serviceItem);
        	}
        	serviceItem.setSourcePortItem(portItem);
        },


        _createLinks : function () {

            linkSequence[this.cid] = [];
            _.forEach(graphSequence[this.cid], function(element, index, array) {
                if (index != 0) {
                    linkSequence[this.cid].push(new joint.shapes.routeChart.LinkItem ({
                            source: {id: array[index - 1].id, port: "out"},
                            target: {id: element.id, port: "in"}
                        }
                    ));
                }
            }, this);

            _.forEach(legsSequence[this.cid], function(element, index, array) {
                if (index > 0) {
                    linkSequence[this.cid].push(new joint.shapes.routeChart.LegLinkItem ({
                            source: {id: array[index - 1].id, port: "out"},
                            target: {id: element.id, port: "in"}
                        }
                    ));
                }
            }, this);
            this.addCells (linkSequence[this.cid]);
        },

        _removeLinks: function () {

            this._removeListeners();
            var links = this.getLinks();
            _.each (links, function (link) {
                link.disconnect();
                link.remove();
            });
            this._addListeners();
        },

        _createLegs: function () {

            _.forEach(graphSequence[this.cid], function(element, index, array) {

               var leg;
                if (index > 0 && index < array.length-1) {
                    leg =  this._createLeg (element, index);
                    legsSequence[this.cid].push (leg);
                }
            }, this);

            this.addCells (_.without(legsSequence[this.cid], undefined));
        },

        _createLeg : function (item, index) {

            var code;
            if (item instanceof joint.shapes.routeChart.ServiceItem) {
                code = item.serviceCode;
            } else if (item instanceof joint.shapes.routeChart.TSPItem) {
                code = item.portCode;
            }

            var leg =  new joint.shapes.routeChart.LegItem({
                elementCode:code,
                elementIndex:index,
                position: { x: 0, y: 0 },
                size: { width: 100, height: 32}
            });

            return leg;
        },

        _createService: function(sourcePorts, destinationPorts, serviceLink) {
            return new joint.shapes.routeChart.ServiceItem({
                position: { x: 0, y: 0 },
                size: { width: this.get("layoutOptions").elementWidth, height: this.get("layoutOptions").elementHeight},
                sourcePorts: sourcePorts,
                destinationPorts: destinationPorts,
                serviceCode: serviceLink !== undefined ? serviceLink.serviceCode : undefined,
                serviceName: serviceLink !== undefined ? serviceLink.serviceName: undefined
            });
        },
        _createPort: function(portCode, dispatchTerminal, dispatchCallId) {
            return new joint.shapes.routeChart.TSPItem({
                position: { x: 0, y: 0 },
                size: { width: this.get("layoutOptions").elementWidth, height: this.get("layoutOptions").elementHeight},
                portCode: portCode,
                dispatchTerminal: dispatchTerminal,
                dispatchCallId: dispatchCallId
            });
        },
        _sequencePositions: function(action) {
            var that = this;
            var x = 0, y = 0;
            var options = that.get("layoutOptions"); // no need to get it in each iteration

            var itemCount = graphSequence[that.cid].length;
            var paperWidth =  itemCount * options.elementWidth + options.gap *(itemCount - 1) + options.padding * 2;
            var paperHeight = y + options.elementHeight * 2

            _.forEach(graphSequence[that.cid], function(element, index) {
                x = options.padding + index * (options.elementWidth + options.gap);
                y = (index % 2 == 0) ? options.yOffset1 : options.yOffset2;
                element.position(x, y);
                var leg = legsSequence[this.cid][index-1];
                if (leg !== undefined) {
                    var bbox = leg.getBBox();
                	leg.position (x + (options.elementWidth - bbox.width)/2, options.yOffset1 + options.legYOffset);
                }
            }, this);
            var scrollOffset = 0;
        	if (action === 'addLeft') {
        		scrollOffset = (2 * (options.elementWidth + options.gap));
            } else if (action === 'removeLeft') {
        		scrollOffset = -(2 * (options.elementWidth + options.gap));
        		console.log(scrollOffset);
            }
        	this.trigger ("updatePaper", paperWidth, paperHeight, scrollOffset);
        },

        _onLinkOver : function (cellView, evt) {

            if (cellView.model.isLink ()) {

                var arr = this._getRelatedElements (cellView.model);

                if (_.intersection (legsSequence[this.cid], arr).length > 0) return;

                _.each (arr, function (cell) {
                    cell.set ("highlight", true);
                })
            }
        },

        _onLinkOut : function (cellView, evt) {

            if (cellView.model.isLink ()) {

                var arr = this._getRelatedElements (cellView.model);
                _.each (arr, function (cell) {
                    cell.set ("highlight", false);
                })
            }

        },

        /* helpers */

        _getRelatedElements : function (link) {
            var srcCell = this.getCell(link.get("source").id);
            var targetCell = this.getCell(link.get("target").id);

            var cells = [];
            if (srcCell) cells.push (srcCell);
            if (targetCell) cells.push (targetCell);

            return cells;

        },

        _getServices: function () {
            return graphSequence[this.cid].filter(function (cell) {
                return cell.isService ();
            }).slice(0);
        },

        getItemIndex : function (cell) {
            return _.indexOf (graphSequence[this.cid], cell);
        }

    });


})();
