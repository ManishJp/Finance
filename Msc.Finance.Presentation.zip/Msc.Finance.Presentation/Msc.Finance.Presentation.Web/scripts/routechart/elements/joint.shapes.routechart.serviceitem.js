/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    // definition
    joint.shapes.routeChart.ServiceItem = joint.shapes.routeChart.ChartItem.extend({

        defaults: joint.util.deepSupplement({
            type: 'routeChart.ServiceItem'
        }, joint.shapes.routeChart.ChartItem.prototype.defaults),

        initialize: function() {
            joint.shapes.routeChart.ChartItem.prototype.initialize.apply(this, arguments);
            console.info('Create a service:' + this.id + ' with service code:' + this.get('serviceCode'));
            this._serviceCollection = new msc.routeChart.Services();
            this._portCollection = new msc.routeChart.Ports();
            this._legTimeModel = new msc.routeChart.LegTime();
            this._portCollection.on('reset', this._portsLoaded, this);
            this._legTimeModel.on('sync', this._legTimeLoaded, this);
            this._prevServiceCode = this.get('serviceCode');
            this._loadServiceCollection();
            this._loadPorts();
        },
        getSourcePortItem: function() {
        	return this.get("sourcePortItem");
        },
        setSourcePortItem: function(portItem) {
            var sourcePortItem = this.getSourcePortItem();
            if (sourcePortItem !== undefined) {
                sourcePortItem.off('changePort', this.setSourcePorts, this);
                sourcePortItem.off('changeLoadingTerminal', this._onChangeLoadingTerminal, this);
            }
            this.set("sourcePortItem", portItem);
            if (portItem !== undefined) {
            	console.info('Service: ' + this.id + ' source port item is set to port: ' + portItem.id);
	            portItem.on('changePort', this.setSourcePorts, this);
	            portItem.on('changeLoadingTerminal', this._onChangeLoadingTerminal, this);
	            var currentSelectedPort = portItem.get('portCode');
	            if (currentSelectedPort === undefined) {
	            	this.setSourcePorts([]);
	            } else {
	            	this.setSourcePorts([currentSelectedPort]);
	            }
            } else {
            	console.info('Service: ' + this.id + ' source port item is set none');
	        }
        },
        getDestinationPortItem: function() {
        	return this.get("destinationPortItem");
        },
        setDestinationPortItem: function(portItem) {
            var destinationPortItem = this.getDestinationPortItem();
            if (destinationPortItem !== undefined) {
                destinationPortItem.off('changePort', this.setDestinationPorts, this)
                destinationPortItem.off('changeDispatchTerminal', this._onChangeDispatchTerminal, this);

            }
            this.set("destinationPortItem", portItem);
            if (portItem !== undefined) {
            	console.info('Service: ' + this.id + ' destination port item is set to port: ' + portItem.id);

            	portItem.on('changePort', this.setDestinationPorts, this);
            	portItem.on('changeDispatchTerminal', this._onChangeDispatchTerminal, this);
 	            var currentSelectedPort = portItem.get('portCode')
	            if (currentSelectedPort === undefined) {
	            	this.setDestinationPorts([]);
	            } else {
	            	this.setDestinationPorts([currentSelectedPort]);
	            }
            } else {
            	console.info('Service: ' + this.id + ' destination port item is set none');
	        }
        },
        getSourcePorts: function() {
        	return this.get('sourcePorts');
        },

        setSourcePorts: function(sourcePorts) {
        	console.info('Service: ' + this.id + ' source ports are set to' + JSON.stringify(sourcePorts));

        	var currentPorts = this.getSourcePorts();
        	if (currentPorts.length !== sourcePorts.length ||
        		(currentPorts.length !== 0 && currentPorts[0] !== sourcePorts[0])) {
        		console.info('Service:' + this.id + ', source ports set as:' + JSON.stringify(sourcePorts));
	    		this.set('sourcePorts', sourcePorts);
	        	this._loadServiceCollection();
	        	this._updateModel();
        	}
        },
        getDestinationPorts: function() {
        	return this.get('destinationPorts');
        },
        setDestinationPorts: function(destinationPorts) {
        	console.info('Service: ' + this.id + ' destination ports are set to' + JSON.stringify(destinationPorts));

        	var currentPorts = this.getDestinationPorts();
        	if (currentPorts.length !== destinationPorts.length ||
        		(currentPorts.length !== 0 && currentPorts[0] !== destinationPorts[0])) {
        		console.info('Service:' + this.id + ', destination ports set as:' + JSON.stringify(destinationPorts));
	    		this.set('destinationPorts', destinationPorts);
        		this._loadServiceCollection();
	        	this._updateModel();
        	}
        },
        getSelectedService : function () {
            return this.get('selectedService');
        },
        setSelectedService: function(selectedService) {
        	console.info('Service: ' + this.id + ' selected service is change to: ' + (selectedService !== undefined ? selectedService.get('Code') : undefined));

        	var currentService = this.getSelectedService();
            var newCode;

	    	if (selectedService === undefined || currentService === undefined) {
	    		if (currentService !== selectedService) {
		    		this.set('selectedService', selectedService);
		    		if (selectedService !== undefined) {
                        newCode = selectedService.get('Code')
		            	this.set('serviceCode', newCode);
		            	this.set('serviceName', selectedService.get('Name'));
		            	this.set('serviceStatus', selectedService.get('ServiceStatus'));
		            } else {
		            	this.unset('serviceStatus');
		            }

                    if (this._prevServiceCode != newCode) {
                        console.info('Service: ' + this.id + ' Trigger external event from setSelectedService');
                        this.trigger("changeServiceExternal");
                        this._prevServiceCode = newCode;
                    }
		    		this._loadPorts();
	    		}

	    	} else if (currentService.get('Code') !== selectedService.get('Code')) {
                this.set('selectedService', selectedService);
	    		if (selectedService !== undefined) {
                    newCode = selectedService.get('Code')
	            	this.set('serviceCode', newCode);
	            	this.set('serviceName', selectedService.get('Name'));
	            	this.set('serviceStatus', selectedService.get('ServiceStatus'));
	            } else {
	            	this.unset('serviceName');
	            	this.unset('serviceStatus');
	            }

                if (this._prevServiceCode != newCode) {
                    console.info('Service: ' + this.id + ' Trigger external event from setSelectedService');
                    this.trigger("changeServiceExternal");
                    this._prevServiceCode = newCode;
                }
	    		this._loadPorts();
	    	}
        },
        getServiceCollection: function() {
        	return this._serviceCollection;
        },
        _loadServiceCollection: function() {
            var sourcePorts = this.getSourcePorts();
            var destinationPorts = this.getDestinationPorts();
            if (sourcePorts !== undefined && destinationPorts !== undefined) {
            	this._serviceCollection.fetch({
            		traditional: true,
            		data: {
            			sourcePorts: sourcePorts.join(','),
            			destinationPorts: destinationPorts.join(',')
            		},
            		reset: true,
            		cache: true
            	});
            } else {
            	this._serviceCollection.reset();
            }
            console.info("Service: " + this.id + ' loading options');
        },
        getPorts: function() {
        	return this._portCollection.models;
        },
        _loadPorts: function() {
        	var selectedService = this.getSelectedService();
            var serviceCode =((selectedService !== undefined) ? selectedService.get('Code') : null)
        	this._portCollection.fetch({
	    		traditional: true,
	    		data: {
	    			serviceCodes:serviceCode
	    		},
	    		reset: true,
                cache: true
	    	});
        	console.info("Service: " + this.id + ' loading ports for service selected:' + serviceCode);
        },
        _portsLoaded: function() {
        	console.info('Service:' + this.id + ' ports loaded')
        	this.trigger('changeService', this);
            this._updateModel();
         },
         _onChangeDispatchTerminal: function() {
         	// Dispatch
         	console.info("Service: " +  this.id + ' dispatch terminal changed');
         	this._getLegTime ();
         },
         _onChangeLoadingTerminal : function () {
         	// Loading
         	console.info("Service: " +  this.id + ' loading terminal changed');
         	this._getLegTime ();
         },
         _legTimeLoaded: function(result) {
        	this.set('legTime', result.get('time'));
        },
        isService : function () {
            return this;
        },
        _addPrevSibling: function (e) {
            e.preventDefault();
            this.trigger("addItemBefore", this);
        },
        _addNextSibling: function (e) {
            e.preventDefault();
            this.trigger("addItemAfter", this);
        },
        _updateModel: function() {
        	this._calculateOverallStatus();
        	this.trigger('changeModel', this);
        },
        _calculateOverallStatus: function() {
        	// 0 - Not operational
        	// 1 - Not connected
        	// 2 - Partially connected
        	// 3 - Fully connected
        	var that = this;
        	if (this.get('serviceStatus') == 0) {
        		this.set('overallStatus', 0);
        	} else {
        		var selectedService = this.get('selectedService');
        		var sourcePorts = this.get('sourcePorts');
        		var destinationPorts = this.get('destinationPorts');
        		if (selectedService === undefined) {
        			this.set('overallStatus', 1);
        		} else if (sourcePorts.length === 1 && destinationPorts.length === 1) {
        			this.set('overallStatus', 3);
        		} else {
        			var fullyConnected = sourcePorts.every(function(sourcePort) {
        				return _.findIndex(that._portCollection.models, function(portModel) {
        					return portModel.get('Code') === sourcePort;
        				}) !== -1;
        			}) && destinationPorts.every(function(destinationPort) {
        				return _.findIndex(that._portCollection.models, function(portModel) {
        					return portModel.get('Code') === destinationPort;
        				}) !== -1;
        			}) 
        			if (fullyConnected) {
        				this.set('overallStatus', 3);
        			} else {
        				this.set('overallStatus', 2);
        			}

        		}
        	}
        },
        _getLegTime: function() {
        	var that = this;
            var lastSourceIndex;
            var firstDestinationIndex;

            var sourcePortItem = this.getSourcePortItem();
            var selectedService = this.getSelectedService();
            var destinationPortItem = this.getDestinationPortItem();

            if (selectedService !== undefined && sourcePortItem !== undefined && destinationPortItem != undefined) {
            	var sourcePortCallId = sourcePortItem.get('loadingCallId');
            	var destinationPortCallId = destinationPortItem.get('dispatchCallId');
            }
            if (sourcePortCallId !== undefined && destinationPortCallId != undefined) {
            	this._legTimeModel.fetch({
	            		data: {
                            fromPortId: sourcePortCallId,
                            toPortId: destinationPortCallId,
		            		serviceCode: selectedService.get('Code')
		                },
		                cache: true
	            	});
            } else {
            	this.unset('legTime');
            }
        }
    },
    // static props
    {
        eventsList:[
            "changeServiceExternal"
        ]
    });

})();
