/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    // definition
    joint.shapes.routeChart.ChartItem = joint.shapes.basic.Rect.extend({
        defaults: joint.util.deepSupplement({
            type: 'routeChart.ChartItem',
            attrs: {
                rect: {stroke: 'none', 'fill-opacity': 0}
            }
        }, joint.shapes.basic.Rect.prototype.defaults),

        isService : function () {
            return false;
        },

        isTSP : function () {
            return false;
        }
    },
       // statics
    {
        getEventsList : function () {
            return this.eventsList;
        }
    });

})();
