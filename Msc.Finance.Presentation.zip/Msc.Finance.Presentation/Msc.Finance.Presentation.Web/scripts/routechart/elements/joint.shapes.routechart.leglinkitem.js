/**
 * Created by windmill version 0.1.2
 */ 

(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    // definition
    joint.shapes.routeChart.LegLinkItem = joint.dia.Link.extend({
        defaults: joint.util.deepSupplement({
            type: 'routeChart.LegLinkItem',
            attrs: {'.connection': {'stroke-width': 0, stroke: '#ccc'}},
            markup: [
                '<path class="connection" stroke="black" d="M 0 0 0 0"/>',
                '<g  class="arrow">',
                '<g transform="scale (0.1) translate (-110, -140)">',
                '<path fill="#ccc" d="M265.171,125.577l-80-80c-4.881-4.881-12.797-4.881-17.678,0c-4.882,4.882-4.882,12.796,0,17.678l58.661,58.661H12.5 c-6.903,0-12.5,5.597-12.5,12.5c0,6.902,5.597,12.5,12.5,12.5h213.654l-58.659,58.661c-4.882,4.882-4.882,12.796,0,17.678 c2.44,2.439,5.64,3.661,8.839,3.661s6.398-1.222,8.839-3.661l79.998-80C270.053,138.373,270.053,130.459,265.171,125.577z"/>',
                '<title>Leg</title>',
                '</g>',
                '</g>'
            ].join(''),
            toolMarkup: [
                '<g class="link-tool">',
                '</g>'
            ].join('')
        }, joint.dia.Link.prototype.defaults),
    });

})();
