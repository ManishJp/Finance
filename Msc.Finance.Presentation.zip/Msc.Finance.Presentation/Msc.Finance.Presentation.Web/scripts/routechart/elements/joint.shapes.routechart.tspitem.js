/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    // definition
    joint.shapes.routeChart.TSPItem = joint.shapes.routeChart.ChartItem.extend({
        defaults: joint.util.deepSupplement({
            type: 'routeChart.TSPItem'
        }, joint.shapes.routeChart.ChartItem.prototype.defaults),
        initialize: function() {
        	joint.shapes.routeChart.ChartItem.prototype.initialize.apply(this, arguments);
        	console.info('Created a port:' + this.id + ' with port code:' + this.get('portCode') + ' dis: '
                +  this.get ('dispatchTerminal') + ' lod:' +  this.get ('loadingTerminal'));
        	this._portCollection = new  Backbone.Collection ();//msc.routeChart.Ports();
        	this._viewPortCollection = new  Backbone.Collection ();//msc.routeChart.Ports();
        	this._dwellTimeModel = new msc.routeChart.DwellTime();
        	this._dwellTimeModel.on('sync', this._dwellTimeLoaded, this);
        	this._dwellTimeModel.on('error', this._dwellTimeLoadError, this);
            this._prevPortCode = this.get('portCode');
            this._prevLODCode = this.get ('loadingTerminal');
            this._prevDISCode = this.get ('dispatchTerminal');

        },
        _lastDwellKey:null,
        setPrevLoadingTerminal : function (serviceLink) {
            this.set('loadingTerminal', serviceLink.polTerminal);
            this.set('loadingCallId', serviceLink.polCallId);
            this._prevLODCode = this.get ('loadingTerminal');
        },
	    getSourceServiceItem: function() {
	    	return this.get('sourceServiceItem');
	    },
	    setSourceServiceItem: function(serviceItem) {
	        var sourceServiceItem = this.getSourceServiceItem();
	        if (sourceServiceItem !== undefined) {
	            sourceServiceItem.off('changeService', this._setSourceService, this);
	        }
	        this.set("sourceServiceItem", serviceItem);
	        this._setSourceService();
            serviceItem.on('changeService', this._setSourceService, this);
	    },
	    getDestinationServiceItem: function() {
	    	return this.get('destinationServiceItem');
	    },
	    setDestinationServiceItem: function(serviceItem) {
	        var destinationServiceItem = this.getDestinationServiceItem();
	        if (destinationServiceItem !== undefined) {
	            destinationServiceItem.off('changeService', this._setDestinationService, this);
	        }
	        this.set("destinationServiceItem", serviceItem);
	        this._setDestinationService();
            serviceItem.on('changeService', this._setDestinationService, this);
	    },
	    getSourceService: function() {
	    	return this.get('sourceService');
	    },
	    _setSourceService: function() {
	    	var sourceServiceItem = this.getSourceServiceItem();
	    	var sourceService = sourceServiceItem.getSelectedService();

	    	console.info('Port:' + this.id + ' source service changed:' + (sourceService === undefined ? undefined : sourceService.get('Code')));
        	this.set('sourceService', sourceService);
	    	this._mergeOptions();
	    	this._calculateModel();
	    },
	    getDestinationService: function() {
	    	return this.get('destinationService');
	    },
	    _setDestinationService: function() {
	    	var destinationServiceItem = this.getDestinationServiceItem();
	    	var destinationService = destinationServiceItem.getSelectedService();
	    	console.info('Port:' + this.id + ' destination service changed:' + (destinationService === undefined ? undefined : destinationService.get('Code')));
        	this.set('destinationService', destinationService);
	    	this._mergeOptions();
	    	this._calculateModel();
	    },
	    getPortCollection: function() {
        	return this._viewPortCollection;
        },
        getPortTerminals: function (portCode, service) {
            var ports = service.getPorts();
            if (ports) {
                return _.chain(ports).filter(function (port) {
                    return port.get('Code') === portCode;
                }).map(function(port) {
                	return _.map(port.get('TerminalList'), function(terminal) {
                		return {
                			"Code": terminal.Code,
                			"CallId": port.get("PortCallId"),
                			"Name": terminal.Name + '(' + terminal.Direction + ')'
                		}
                	})
                }).flatten(true).value();
            }
        },

        getSelectedPort: function() {
	    	return this.get('selectedPort');
	    },

	    setSelectedPort: function(selectedPort) {
                console.info('Port:' + this.id + ' selected port changed:' + (selectedPort === undefined ? undefined : selectedPort.get('Code')));

            this.set('selectedPort', selectedPort);
                if (selectedPort !== undefined) {
                    this.set('portCode', selectedPort.get('Code'));
                    this.set('portName', selectedPort.get('Name'));
                    this.set('portStatus', selectedPort.get('Status'));
                    this.trigger('changePort', [selectedPort.get('Code')]);
                    if (this._prevPortCode != selectedPort.get('Code')) {
                        console.info('Port:' + this.id + ' Trigger external event from setSelectedPort');
                        this.trigger ("changePortExternal");
                        this._prevPortCode = selectedPort.get('Code');
                    }
                } else {
                    this.unset('portStatus');
                    this.unset('dwellTime');
                    this.trigger('changePort', []);
                    if (this._prevPortCode !== undefined) {
                        console.info('Port:' + this.id + ' Trigger external event from setSelectedPort');
                        this.trigger ("changePortExternal");
                        this._prevPortCode = undefined;
                    }
                }
            this._calculateModel();
         },
	    _mergeOptions: function() {
        	var options = [], viewOptions;
	    	var sourceServiceItem = this.getSourceServiceItem();
	    	if (sourceServiceItem !== undefined) {
	    		var sourceService = sourceServiceItem.getSelectedService();
	    	}
        	var destinationServiceItem = this.getDestinationServiceItem();
	    	if (destinationServiceItem !== undefined) {
	    		var destinationService = destinationServiceItem.getSelectedService();
		    }
	    	if (sourceService === undefined && destinationService == undefined) {
        		if (sourceServiceItem !== undefined) {
					options = sourceServiceItem.getPorts();
                    viewOptions = _.map (options , function (port) {
                        return {group:"Left Service", Code:port.get ("Code"), Name:port.get ("Name"), Status:port.get ("Status")};
                    })
				}
			} else if (sourceService !== undefined && destinationService === undefined) {
				options = this._dedup(sourceServiceItem.getPorts());
                viewOptions = _.map (options , function (port) {
                    return {group:"Left Service", Code:port.get ("Code"), Name:port.get ("Name"), Status:port.get ("Status")};
                })

            } else if (sourceService === undefined && destinationService !== undefined) {
				options = this._dedup(destinationServiceItem.getPorts());
                viewOptions = _.map (options , function (port) {
                    return {group:"Right Service", Code:port.get ("Code"), Name:port.get ("Name"), Status:port.get ("Status")};
                })

			} else {
				var sourcePorts = this._dedup(sourceServiceItem.getPorts());
	        	var destinationPorts = this._dedup(destinationServiceItem.getPorts());
	        	options = this._unionPorts(this._intersectPorts(sourcePorts, destinationPorts),
						this._unionPorts(sourcePorts, destinationPorts));

                viewOptions = _.map (options, function (port) {

                    var leftInc = _.find(sourcePorts, function(sourcePort) {
                        return port.get('Code') == sourcePort.get('Code');
                    });
                    var rightInc = _.find(destinationPorts, function(destinationPort) {
                        return port.get('Code') == destinationPort.get('Code');
                    });

                    if (leftInc && rightInc) {
                        return {group:"Both Services", Code:port.get ("Code"), Name:port.get ("Name"), Status:port.get ("Status")};
                    } else if (leftInc) {
                       return {group:"Left Service", Code:port.get ("Code"), Name:port.get ("Name"), Status:port.get ("Status")};
                    } else {
                       return {group:"Right Service", Code:port.get ("Code"), Name:port.get ("Name"), Status:port.get ("Status")};
                    }
                })
			}
			console.info('Port:' + this.id + ' options merged');
        	console.log(options);

			this._portCollection.reset(options);
			this._viewPortCollection.reset(viewOptions);
	    },
	    _dedup: function(ports) {
	    	return _.filter(ports, function(port, index) {
	    		return _.findIndex(ports, function(tmpPort) {
	    			return tmpPort.get('Code') === port.get('Code');
	    		}) === index;
	    	});
	    },
	    _intersectPorts: function(firstList, secondList) {
	    	return _(firstList).chain().map(function(firstPort) {
	    	    return _.find(secondList, function(secondPort) {
	    	    	return firstPort.get('Code') == secondPort.get('Code');
	    	    });
	    	}).compact().value();
	    },
	    _unionPorts: function(firstList, secondList) {
	    	return _.chain(arguments)
		        	.flatten(true)
		        	.uniq(function(port) {return port.get('Code');})
		        	.value();
	    },
	    _dwellTimeLoaded: function(result) {
            this._lastDwellKey = null;
	    	this.set('dwellTime', result.get('time'));
	    },
        _dwellTimeLoadError: function() {
            this._lastDwellKey = null;
        },
	    _calculateModel: function() {
	    	this._calculateOverallStatus();
	    	this.trigger('changeModel', this);
	    },
	    _calculateOverallStatus: function() {
	    	// 0 - Not operational
	    	// 1 - Not connected
	    	// 2 - Fully connected
	    	if (this.get('portStatus') === 0) {
	    		this.set('overallStatus', 0);
	    	} else {
	    		var selectedPort = this.getSelectedPort();
	    		var sourceService = this.getSourceService();
	    		var destinationService = this.getDestinationService();
	    		if (selectedPort === undefined || sourceService === undefined || destinationService === undefined) {
	    			this.set('overallStatus', 1);
	    		} else {
	    			this.set('overallStatus', 3);
	    		}
	    	}
	    	this.trigger('changeModel', this);
	    },
	    setDispatchTerminal: function(dispatchTerminal) {
	    	if (dispatchTerminal != undefined) {
	    		console.info('Port:' + this.id + ' dispatch terminal changed to:' + dispatchTerminal.Code);
                this.set('dispatchTerminal', dispatchTerminal.Code);
		    	this.set('dispatchCallId', dispatchTerminal.CallId);
		    	this.trigger("changeDispatchTerminal");
		    	this._resetDwellTime();

	            if (this._prevDISCode !== dispatchTerminal.Code) {
	                console.info('Port:' + this.id + ' Trigger external event from setDispatchTerminal');
	                this.trigger ("changeDispatchTerminalExternal");
	                this._prevDISCode = dispatchTerminal.Code;
	            }
	    	} else {
	    		console.info('Port:' + this.id + ' dispatch terminal changed to undefined');
                this.unset('dispatchTerminal');
		    	this.unset('dispatchCallId');
		    	this.trigger("changeDispatchTerminal");
		        if (this._prevDISCode !== undefined) {
	                console.info('Port:' + this.id + ' Trigger external event from setDispatchTerminal');
	                this.trigger ("changeDispatchTerminalExternal");
	                this._prevDISCode = undefined;
	            }
	    	}
	    },
	    setLoadingTerminal: function(loadingTerminal) {
	    	if (loadingTerminal != undefined) {
	    		console.info('Port:' + this.id + ' loading terminal changed to:' + loadingTerminal.Code);
                this.set('loadingTerminal', loadingTerminal.Code);
		    	this.set('loadingCallId', loadingTerminal.CallId);
		    	this.trigger ("changeLoadingTerminal");
		 	    this._resetDwellTime();
	            if (this._prevLODCode !== loadingTerminal.Code) {
	                console.info('Port:' + this.id + ' Trigger external event from changeLoadingTerminalExternal');
	                this.trigger ("changeLoadingTerminalExternal");
	                this._prevLODCode = loadingTerminal.Code;
	            }
	    	} else {
	    		console.info('Port:' + this.id + ' loading terminal changed to undefined');

	    		this.unset('loadingTerminal');
		    	this.unset('loadingCallId');
		    	this.trigger ("changeLoadingTerminal");
		        if (this._prevLODCode !== undefined) {
		        	console.info('Port:' + this.id + ' Trigger external event from changeLoadingTerminalExternal');
		        	this.trigger ("changeLoadingTerminalExternal");
		            this._prevLODCode = undefined;
		        }
		    }
	    },
	    _resetDwellTime: function() {
	    	var sourceServiceItem = this.getSourceServiceItem();
	    	if (sourceServiceItem !== undefined) {
	    		var sourceService = sourceServiceItem.getSelectedService();
	    	}

	    	var destinationServiceItem = this.getDestinationServiceItem();
	    	if (destinationServiceItem !== undefined) {
	    		var destinationService = destinationServiceItem.getSelectedService();
	    	}

	    	var selectedPort = this.getSelectedPort();
			var dispatchCallId = this.get('dispatchCallId');
            var loadingCallId = this.get('loadingCallId');

	    	if (sourceService !== undefined && destinationService !== undefined &&
	    			selectedPort !== undefined && dispatchCallId !== undefined && loadingCallId !== undefined) {
                var options = {
                    data:{
                        fromServiceCode: sourceService.get('Code'),
                        toServiceCode: destinationService.get('Code'),
                        fromTerminalId: dispatchCallId,
                        toTerminalId: loadingCallId
                    },
                    cache: true
                };

                // prevent request duplication before filling cache with first server response
                var cacheKey = Backbone.fetchCache.getCacheKey (this._dwellTimeModel, options);
	    		if (cacheKey !== this._lastDwellKey) {
                    this._lastDwellKey = cacheKey;
                    this._dwellTimeModel.fetch(options);
                }
	    	} else {
	    		this.unset('dwellTime');
	    	}
	    },
	    isTSP : function () {
	        return this;
	    }

    },
        // static props
    {
        eventsList:[
            "changePortExternal", "changeDispatchTerminalExternal", "changeLoadingTerminalExternal"
        ]
    });
})();
