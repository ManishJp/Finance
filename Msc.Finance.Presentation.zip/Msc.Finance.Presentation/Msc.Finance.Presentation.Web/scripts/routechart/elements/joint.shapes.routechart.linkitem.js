/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    // definition
    joint.shapes.routeChart.LinkItem = joint.dia.Link.extend({
        defaults: joint.util.deepSupplement({
            type: 'routeChart.LinkItem',
            router: {name:"OrtodoxRouter", args:{padding:12, gap:25}},
            attrs: {'.connection': {'stroke-width': 2, stroke: '#004b97'}},
            toolMarkup: [
                '<g class="link-tool">',
                '<g class="tool-remove" event="remove">',
                '<circle r="11" />',
                '<path transform="scale(.6) translate(-16, -16)" d="M24.778,21.419 19.276,15.917 24.777,10.415 21.949,7.585 16.447,13.087 10.945,7.585 8.117,10.415 13.618,15.917 8.116,21.419 10.946,24.248 16.447,18.746 21.948,24.248z"/>',
                '<title>Remove items</title>',
                '</g>',
                '</g>'
            ].join('')
        }, joint.dia.Link.prototype.defaults)
    });
})();
