/**
 * Created by windmill version 0.1.2
 */

Backbone.fetchCache.localStorage = false;

var originalSync = Backbone.sync;
var handlePreloading =  function(method, model, options) {
    $("#routeChart .chart-modal").addClass ("active");
    // call original Backbone.sync
    var promise = originalSync(method, model, options);
    promise.done(function() {
        $("#routeChart .chart-modal").removeClass ("active");
    });
    promise.fail(function() {
        $("#routeChart .chart-modal").removeClass ("active");
    });
    return promise;
};
Backbone.sync = handlePreloading;

var layoutOptions = {layoutOptions: {
    gap: 25, padding: 50, elementWidth: 140,
    elementHeight: 170, yOffset1:45, yOffset2:85, legYOffset:-40
}};
var graph = new joint.shapes.routeChart.Graph(layoutOptions);


var paperWrapper = new msc.routeChart.PaperWrapperView({
	el: '#routeChart',
	model: graph
});


$('#output').click(function() {
	console.log(JSON.stringify(graph.getPattern()));
	console.log(JSON.stringify(graph.getValidRoutes()));
});


graph.on("patternChanged", function () {
	console.log(JSON.stringify(graph.getPattern()));
	console.log(JSON.stringify(graph.getValidRoutes()));
});

graph.setData([{
	polCode: "BRNVT",
	podCode: "DKAAR"
}, {
	polCode: "BRNVT",
	podCode: "DKFRC"
}, {
	polCode: "BRNVT",
	podCode: "DKCPH"
}, {
	polCode: "BRPNG",
	podCode: "DKAAR"
}, {
	polCode: "BRPNG",
	podCode: "DKFRC"
}, {
	polCode: "BRPNG",
	podCode: "DKCPH"
}],
[]);
