/**
 * Created by windmill version 0.1.2
 */


(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    //definition
    joint.shapes.routeChart.ChartItemView  = joint.dia.ElementView.extend({
        initialize: function() {
            _.bindAll(this, 'updateBox');
            joint.dia.ElementView.prototype.initialize.apply(this, arguments);

            this.$box = $(_.template(this.template)());
            // Prevent paper from handling pointerdown.
            this.$box.find('input,select').on('mousedown click', function(evt) { evt.stopPropagation(); });
            this.model.on('change', this.updateBox, this);
            this.model.on('remove', this.destroy, this);
            this.model.on('change:highlight', this.updateHighLight, this);

            this.updateBox();
        },
        destroy:function () {
            this.model.off ();
            this.removeBox ();
        },
        render: function() {
            joint.dia.ElementView.prototype.render.apply(this, arguments);
            this.paper.$el.prepend(this.$box);
            this.updateBox();
            return this;
        },
        updateBox: function() {
            // Set the position and dimension of the box so that it covers the JointJS element.
            var bbox = this.model.getBBox();
            this.model.resize (bbox.width, this.$box.outerHeight(true));
            this.$box.css({ width: bbox.width, left: bbox.x, top: bbox.y, transform: 'rotate(' + (this.model.get('angle') || 0) + 'deg)' });
            //this.$box.css({ width: bbox.width, height: bbox.height, left: bbox.x, top: bbox.y, transform: 'rotate(' + (this.model.get('angle') || 0) + 'deg)' });
        },
        removeBox: function() {
            this.$box.remove();
        },
        updateHighLight: function () {
            if (this.model.get ("highlight") == true) {
                this.$box.addClass ("item-highlight");
            } else {
                this.$box.removeClass ("item-highlight");
            }
        },

        changeModel : function () {
            this.$box.css("border-color", "#ccc");
        },

        $: function(selector) {
            return this.$box.find(selector);
        }

    });

})();
