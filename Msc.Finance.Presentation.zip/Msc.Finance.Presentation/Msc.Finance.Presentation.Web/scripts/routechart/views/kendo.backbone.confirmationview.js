/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    kendo = kendo || {};
    kendo.backbone = kendo.backbone || {};

    kendo.backbone.ConfirmationView = Backbone.View.extend ({
        initialize : function () {

            this.model.on("listenersAdded", this._addListeners, this);
            this.model.on("listenersRemoved", this._removeListeners, this);
            this.model.on("confirmationClose", this._closeMe, this);
            this._addListeners ();
        },

        _closeMe : function () {

            var windowHolder = $ (".delete-confirmation-window");
            var window = windowHolder.data("kendoWindow");
            window.close ();
        },

        _addListeners : function () {
            this.model.on ('remove', this._showConfirmation, this);
        },

        _removeListeners : function () {
            this.model.off ('remove', this._showConfirmation, this);
        },

        _createWindow : function () {

            var windowHolder = $(this.el);
            if (!windowHolder.data("kendoWindow")) {
                windowHolder.kendoWindow({
                    actions: ["Close"],
                    title: "Do you want to delete these items?",
                    close: _.bind (this._cancelRemove, this),
                    height: "auto",
                    width: "400px",
                    modal: true,
                    draggable: false,
                    resizable: false,
                    visible: false, /*don't show it yet*/
                    appendTo:"#routeChart"
                });
                var window = windowHolder.data("kendoWindow");
                windowHolder.find (".k-i-close").closest ("a.k-button-icontext")
                    .on ("click", function () {window.close ()});
                windowHolder.find (".k-i-tick").closest ("a.k-button-icontext")
                    .on ("click", $.proxy (this._confirmRemove, this));
                window.bind("close", this._onWindowClosed);
            }
        },

        _showConfirmation : function (cell) {

            if (!cell.isLink ()) return;

            this._createWindow ();

            var windowHolder = $ (".delete-confirmation-window");
            var srcCell = this.model.getCell(cell.attributes.source.id);
            var targetCell = this.model.getCell(cell.attributes.target.id);

            // service
            var service = srcCell.isService () || targetCell.isService ();
            var serviceIndex = this.model.getItemIndex (service);

            windowHolder.find (".confirmation-content > h4:first-child")
                .contents().filter(function() {
                    return this.nodeType == 3
                }).replaceWith("Service "+ (serviceIndex/2+1));

            var serviceName = service.get ("serviceName");
            windowHolder.find (".confirmation-content > h4:first-child > span")
                .text (serviceName || '');

            // tsp
            var tsp = srcCell.isTSP () || targetCell.isTSP ();
            var tspIndex = this.model.getItemIndex (tsp);

            windowHolder.find (".confirmation-content > h4:last-child")
                .contents().filter(function() {
                    return this.nodeType == 3
                }).replaceWith("TSP " + (Math.ceil(tspIndex/2)));

            var tspName = tsp.get ("portName");
            windowHolder.find (".confirmation-content > h4:last-child > span")
                .text (tspName || '');

            var window = windowHolder.data("kendoWindow");
            window.center ().open ();
        },

        _cancelRemove : function () {
            this.model.cancelRemove ();
        },

        _confirmRemove : function () {
            this.model.confirmRemove ();
        },

        _onWindowClosed : function () {
            var windowHolder = $ (".delete-confirmation-window");
            var window = windowHolder.data("kendoWindow");
            if (window) {
                window.unbind("close");
                window.destroy();
            }
        }
    })

})();
