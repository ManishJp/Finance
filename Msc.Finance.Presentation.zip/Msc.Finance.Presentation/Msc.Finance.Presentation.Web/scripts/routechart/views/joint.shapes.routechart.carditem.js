/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    //definition
    joint.shapes.routeChart.CardItem = {
        // broken styles used for not-operational state to
        _statusLabelClasses : ["broken-label-color", "broken-label-color", "partial-label-color", "good-label-color"],
        _statusBorderClasses : ["broken-border", "broken-border", "partial-border", "good-border"],
        _statusLabels : ["--", "Broken", "Partially", ""],
        _updateStatus: function () {
            var overallStatus = this.model.get('overallStatus');

            var borderStyles = this._statusBorderClasses.slice (0);
            var labelStyles = this._statusLabelClasses.slice (0);
            var labelTexts = this._statusLabels.slice (0);

            var styles = this._getRemoveAddStyles (borderStyles, overallStatus);
            this.$box.removeClass(styles.toRemove).addClass(styles.toAdd);

            styles = this._getRemoveAddStyles (labelStyles, overallStatus);
            this.$box.find('.status-label').text(labelTexts[overallStatus])
                .removeClass(styles.toRemove)
                .addClass(styles.toAdd);
        },

        _getRemoveAddStyles : function (stylesArray, status) {
            var setStyles = stylesArray.splice (status, 1).join(" ").trim();
            var removeStyles = stylesArray.join(" ").trim();
            return {toRemove:removeStyles, toAdd:setStyles};
        }
    }

}) ();
