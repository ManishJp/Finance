/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    //definition
    joint.shapes.routeChart.ServiceItemView = joint.shapes.routeChart.ChartItemView.extend(_.extend({}, joint.shapes.routeChart.CardItem, {
        template: [
            '<div class="card-element service-item">',
            '<div class="add-elements">',
            '<a href="" class="add-before"><span class="icon-plus-circle2"></span></a>',
            '<a href="" class="add-after"><span class="icon-plus-circle2"></span></a>',
            '</div>',
            '<div class="card-info">',
            '<h6  class="type-label">Service <span class="status-label extra-title loading">--</span></h6>',
            '<h4 class="name-label">Empty service</h4>',
            '</div>',
            '<div class="select-card">',
            '<select></select>',
            '</div>',
            '</div>'
        ].join(''),
        kendoUIEvents: {
            "change .select-card select": "onChangeService"
        },
        initialize: function() {
            joint.shapes.routeChart.ChartItemView.prototype.initialize.apply (this, arguments);

            this.$box.find('.add-before').on('click', _.bind(this.model._addPrevSibling, this.model));
            this.$box.find('.add-after').on('click', _.bind(this.model._addNextSibling, this.model));
            this.dropdown = this.$box.find (".select-card > select").kendoDropDownList ({
                dataTextField: "Name",
                dataValueField: "Code",
            	filter: "contains"
            }).data("kendoDropDownList");

            this.dropdown.list.addClass ("card-dropdown");

            kendo.Backbone.ViewEvents.delegate(this);

            this.listenTo(this.model.getServiceCollection(), 'reset', this.resetOptions);
            this.listenTo(this.model, 'changeModel', this.changeModel);
            this.changeModel();
        },
        destroy:function () {
            this.dropdown.destroy();
            joint.shapes.routeChart.ChartItemView.prototype.destroy.apply (this, arguments);
        },
        resetOptions: function(options) {
            var serviceCode = this.model.get('serviceCode');
            console.log(options.models);
            var optionsDataSource =  new kendo.Backbone.DataSource({
            	collection: options
            });
            this.dropdown.setDataSource(optionsDataSource);

            var selectedServiceIndex = _.findIndex(options.models, function(option) {
            	return option.get('Code') === serviceCode;
            });
	       	this.dropdown.select(selectedServiceIndex);
            if (selectedServiceIndex !== -1) {
            	this.model.setSelectedService(options.models[selectedServiceIndex]);
            } else {
            	this.model.setSelectedService();
            }

            //BUG: don't remove crutch-fix for updating box size
            this.updateBox ();

        },
        onChangeService: function(e) {
            var selectedItem = e.sender.dataItem(e.item);
            this.model.setSelectedService(selectedItem);
        },
        changeModel: function() {
        	this._updateName();
        	this._updateStatus();
            //BUG: don't remove crutch-fix for updating box size
            this.updateBox ();
        },
        _updateName: function() {
        	if (this.model.has("serviceName")) {
            	this.$box.find (".name-label").text(this.model.get('serviceName'));
        	} else {
        		this.$box.find (".name-label").text('');
        	}
        }
    }));

})();
