/**
 * Created by windmill version 0.1.2
 */

(function () {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    //definition
    joint.shapes.routeChart.TSPItemView = joint.shapes.routeChart.ChartItemView.extend(_.extend({}, joint.shapes.routeChart.CardItem, {
        template: [
            '<div class="card-element tsp-item">',
            '<div class="card-info">',
            '<h6 class="type-label">TSP<span class="status-label extra-title loading">--</span></h6>',
            '<h4 class="name-label">Port name</h4>',
            '</div>',
            '<div class="select-card">',
            '<select></select>',
            '</div>',
            '<div class="time-info">',
            'Dwell Time:<span>Not applicable</span>',
            '</div>',
            '<div class="extra-info">',
            '<div class="info-row"><span>DIS:</span><select></select></div>',
            '<div class="info-row"><span>LOD:</span><select></select></div>',
            '</div>',
            '</div>'
        ].join(''),
        kendoUIEvents: {
            "change .select-card select": "onChangePort",
            "change .extra-info .info-row:first-child select": "onChangeDIS",
            "change .extra-info .info-row:last-child select": "onChangeLOD"
        },
        initialize: function () {

            joint.shapes.routeChart.ChartItemView.prototype.initialize.apply(this, arguments);

            this.dropdown = this.$box.find(".select-card > select").kendoDropDownList({
                dataTextField: "Name",
                dataValueField: "Code",
                filter:"contains",
                fixedGroupTemplate:"#:data#",
                groupTemplate: "#:data#"
            }).data("kendoDropDownList");

            this.dropdown.list.addClass ("card-dropdown");

            this.disSelector = this.$box.find(".extra-info .info-row:first-child select").kendoDropDownList({
                dataTextField: "Name",
                dataValueField: "Code"
            }).data("kendoDropDownList");

            this.disSelector.list.addClass ("terminal-dropdown");

            this.lodSelector = this.$box.find(".extra-info .info-row:last-child select").kendoDropDownList({
                dataTextField: "Name",
                dataValueField: "Code"
            }).data("kendoDropDownList");

            this.lodSelector.list.addClass ("terminal-dropdown");

            this.listenTo(this.model.getPortCollection(), 'reset', this.resetOptions);
            this.listenTo(this.model, 'changeModel', this.changeModel);
            this.listenTo(this.model, 'change:dwellTime', this._changeDwell);
            kendo.Backbone.ViewEvents.delegate(this);
        },
        destroy:function () {
            this.dropdown.destroy();
            this.disSelector.destroy();
            this.lodSelector.destroy();
            joint.shapes.routeChart.ChartItemView.prototype.destroy.apply (this, arguments);
        },
        updateHighLight: function () {
            if (this.model.get("highlight") == true) {
                this.$box.addClass("item-highlight");
                this.$box.find(".extra-info").addClass("item-highlight");
            } else {
                this.$box.removeClass("item-highlight");
                this.$box.find(".extra-info").removeClass("item-highlight");
            }
        },
        changeModel: function () {
            this._updateName();
            this._updateStatus();

            //BUG: don't remove crutch-fix for updating box size
            this.updateBox();
        },
        _updateName: function () {
            if (this.model.has("portName")) {
                this.$box.find(".name-label").text(this.model.get('portName'));
            } else {
                this.$box.find(".name-label").text('');
            }
        },
        _updateStatus: function () {

            joint.shapes.routeChart.CardItem._updateStatus.apply(this, arguments);

            var overallStatus = this.model.get('overallStatus');
            var borderStyles = this._statusBorderClasses.slice (0);
            var styles = this._getRemoveAddStyles (borderStyles, overallStatus);
            this.$box.find(".extra-info").removeClass(styles.toRemove).addClass(styles.toAdd);
        },
        _changeDwell: function () {
            if (this.model.has("dwellTime")) {
                var t = this.model.get("dwellTime");
                this.$box.find(".time-info > span").text(t + "D");
            } else {
                this.$box.find('div.time-info span').text('n/a');
            }
        },
        resetOptions: function (options) {
            var portCode = this.model.get('portCode');

            options.comparator = function(model) {
                return model.get('Name');
            }
            options.sort();
            var optionsDataSource = new kendo.Backbone.DataSource({
                collection: options,
                group:{field:'group'}
            });
            this.dropdown.setDataSource(optionsDataSource);

            optionsDataSource.read();
            console.log(optionsDataSource.view());
            var selectedPortIndex = _.findIndex(options.models, function (option) {
                return option.get('Code') === portCode;
            });
            this.dropdown.select(selectedPortIndex);

            if (selectedPortIndex !== -1) {
            	this.model.setSelectedPort(options.models[selectedPortIndex]);
            }
            this._updateDISSelector(portCode);
            this._updateLODSelector(portCode);
            //BUG: don't remove crutch-fix for updating box size
            this.updateBox();

        },

        _updateDISSelector : function (portCode) {
            var service = this.model.getSourceServiceItem();
            var terminals = this.model.getPortTerminals(portCode, service);

            this.disSelector.setDataSource(new kendo.Backbone.DataSource({
                collection: new Backbone.Collection(terminals)
            }));

            var dispatchTerminal = this.model.get("dispatchTerminal");
            var dispatchCallId = this.model.get("dispatchCallId");
            var index = _.findIndex(terminals, function (terminal) {
                return (terminal.Code === dispatchTerminal && terminal.CallId === dispatchCallId);
            });
            if (terminals.length == 1) {
            	index = 0;
            }
            this.disSelector.select(index);
            if (index !== -1) {
            	this.model.setDispatchTerminal(terminals[index]);
            } else if (terminals.length > 0) {
            	this.model.setDispatchTerminal();
            }
        },
        _updateLODSelector : function (portCode) {
            var service = this.model.getDestinationServiceItem();
            var terminals = this.model.getPortTerminals(portCode, service);

            this.lodSelector.setDataSource(new kendo.Backbone.DataSource({
                collection: new Backbone.Collection(terminals)
            }));

            var loadingTerminal = this.model.get("loadingTerminal");
            var loadingCallId = this.model.get("loadingCallId");
            var index = _.findIndex(terminals, function (terminal) {
                return (terminal.Code === loadingTerminal && terminal.CallId === loadingCallId);
            });
            if (terminals.length == 1) {
            	index = 0;
            }
            this.lodSelector.select(index);
            if (index !== -1) {
            	this.model.setLoadingTerminal(terminals[index]);
            } else if (terminals.length > 0) {
            	this.model.setLoadingTerminal();
            }
        },
        onChangePort: function (e) {
            var selectedItem = e.sender.dataItem(e.item);
            this.model.setSelectedPort(selectedItem);

            //BUG: don't remove crutch-fix for updating box size
            this.updateBox();

        },
        onChangeDIS: function (e) {
            this.model.setDispatchTerminal(e.sender.dataItem(e.item));
        },
        onChangeLOD: function (e) {
        	this.model.setLoadingTerminal(e.sender.dataItem(e.item));
        }
    }));

})();
