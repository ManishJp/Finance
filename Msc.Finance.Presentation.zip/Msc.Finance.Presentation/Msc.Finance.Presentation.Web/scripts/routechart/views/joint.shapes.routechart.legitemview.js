/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    //definition
    joint.shapes.routeChart.LegItemView = joint.shapes.routeChart.ChartItemView.extend({
        template: [
            '<div class="leg-element">',
            '<h6 class="type-label"><span class="map-icon icon-map-marker"></span>LEG</h6>',
            '</div>'
        ].join(''),
        initialize: function() {
            joint.shapes.routeChart.ChartItemView.prototype.initialize.apply (this, arguments);

            this.listenTo(this.model, 'change:time', this.updateLegTime);
            this.updateLegTime ();
        },

        updateBox: function() {
            // Set the position and dimension of the box so that it covers the JointJS element.
            var bbox = this.model.getBBox();
            this.$box.css({ width: bbox.width, height: bbox.height, left: bbox.x, top: bbox.y, transform: 'rotate(' + (this.model.get('angle') || 0) + 'deg)' });
        },

        serviceTemplate:"LEG {N} ({T}D)",
        tspTemplate:"{N} (DT{T})",

        updateLegTime: function () {

            var tpl
            var time = this.model.get("time");
            var type = this.model.get("type");
            var index = this.model.get("index") || 0;

            if (type == joint.shapes.routeChart.ServiceItem && time !== undefined) {
                this.$box.find (".map-icon").hide ();
                index = index/2+1;
                tpl = this.serviceTemplate.replace ("{T}", time);
                tpl = tpl.replace ("{N}", index);
            } else if (type == joint.shapes.routeChart.TSPItem && time !== undefined) {
                this.$box.find (".map-icon").show ();
                index = Math.ceil((index)/2);
                tpl = this.tspTemplate.replace ("{T}", time);
                tpl = tpl.replace ("{N}", index);
            } else {
                this.$box.find (".map-icon").hide ();
                tpl = "(no data)";
            }

            this.$box.find("h6.type-label").contents().filter(function() {
                return this.nodeType == 3
            }).replaceWith(tpl);
        },
    });

})();
