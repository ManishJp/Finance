/**
 * Created by windmill version 0.1.2
 */

(function() {
    'use strict';

    // namespace
    joint.shapes.routeChart = joint.shapes.routeChart || {};

    //definition
    joint.shapes.routeChart.LinkView = joint.dia.LinkView.extend ({

        render: function() {

            this.$el.empty();

            // A special markup can be given in the `properties.markup` property. This might be handy
            // if e.g. arrowhead markers should be `<image>` elements or any other element than `<path>`s.
            // `.connection`, `.connection-wrap`, `.marker-source` and `.marker-target` selectors
            // of elements with special meaning though. Therefore, those classes should be preserved in any
            // special markup passed in `properties.markup`.
            var model = this.model;
            var children = V(model.get('markup') || model.markup);

            // custom markup may contain only one children
            if (!_.isArray(children)) children = [children];

            // Cache all children elements for quicker access.
            this._V = {}; // vectorized markup;
            _.each(children, function(child) {
                var c = child.attr('class');
                c && (this._V[$.camelCase(c)] = child);
            }, this);

            // Only the connection path is mandatory
            if (!this._V.connection) throw new Error('link: no connection path in the markup');

            // partial rendering
            this.renderTools();
            this.renderVertexMarkers();
            this.renderArrowheadMarkers();

            this.vel.append(children);

            // rendering labels has to be run after the link is appended to DOM tree. (otherwise <Text> bbox
            // returns zero values)
            this.renderLabels();

            // start watching the ends of the link for changes
            this.watchSource(model, model.get('source'))
                .watchTarget(model, model.get('target'))
                .update();

                return this;
        },


        updateConnection: function(opt) {

            opt = opt || {};

            var model = this.model;
            var route;

            if (opt.translateBy && model.isRelationshipEmbeddedIn(opt.translateBy)) {
                // The link is being translated by an ancestor that will
                // shift source point, target point and all vertices
                // by an equal distance.
                var tx = opt.tx || 0;
                var ty = opt.ty || 0;

                route = this.route =  _.map(this.route, function(point) {
                    // translate point by point by delta translation
                    return g.point(point).offset(tx, ty);
                });

                // translate source and target connection and marker points.
                this._translateConnectionPoints(tx, ty);

            } else {
                // Necessary path finding
                route = this.route = this.findRoute(model.get('vertices') || [], opt);
                // finds all the connection points taking new vertices into account
                this._findConnectionPoints(route);
            }

            var pathData = this.getPathData(route);

            // The markup needs to contain a `.connection`
            this._V.connection.attr('d', pathData);
            this._V.connectionWrap && this._V.connectionWrap.attr('d', pathData);

            this._translateAndAutoOrientArrows(this._V.markerSource, this._V.markerTarget);

            if (this._V.arrow) {
                var tool = this._V.arrow;
                var connectionElement = this._V.connection.node;
                var connectionLength = this.getConnectionLength();
                // Firefox returns connectionLength=NaN in odd cases (for bezier curves).
                // In that case we won't update tools position at all.
                if (!_.isNaN(connectionLength)) {

                    var toolPosition = connectionElement.getPointAtLength(connectionLength / 2);
                    var scale = '';
                    tool.attr('transform', 'translate(' + toolPosition.x + ', ' + toolPosition.y + ') ' + scale);
                }
            }
        },

        renderTools: function() {

            if (!this._V.linkTools) return this;
            var $tools = $(this._V.linkTools.node).empty();
            var toolTemplate = _.template(this.model.get('toolMarkup') || this.model.toolMarkup);
            var tool = V(toolTemplate());
            $tools.append(tool.node);
            this._toolCache = tool;
            if (this.options.doubleLinkTools) {
                var tool2;
                if (this.model.get('doubleToolMarkup') || this.model.doubleToolMarkup) {
                    toolTemplate = _.template(this.model.get('doubleToolMarkup') || this.model.doubleToolMarkup);
                    tool2 = V(toolTemplate());
                } else {
                    tool2 = tool.clone();
                }
                $tools.append(tool2.node);
                this._tool2Cache = tool2;
            }

            return this;
        },

        updateToolsPosition: function() {

            if (!this._V.linkTools) return this;
            var scale = '';
            var offset = 0//this.options.linkToolsOffset;
            var connectionLength = this.getConnectionLength();

            // Firefox returns connectionLength=NaN in odd cases (for bezier curves).
            // In that case we won't update tools position at all.
            if (!_.isNaN(connectionLength)) {

                // If the link is too short, make the tools half the size and the offset twice as low.

                /*if (connectionLength < this.options.shortLinkLength) {
                    scale = 'scale(.75)';
                    offset /= 2;
                }
                */

                var toolPosition = this.getPointAtLength(connectionLength/2);

                this._toolCache.attr('transform', 'translate(' + toolPosition.x + ', ' + toolPosition.y + ') ' + scale);

                if (this.options.doubleLinkTools && connectionLength >= this.options.longLinkLength) {

                    var doubleLinkToolsOffset = this.options.doubleLinkToolsOffset || offset;

                    toolPosition = this.getPointAtLength(connectionLength - doubleLinkToolsOffset);
                    this._tool2Cache.attr('transform', 'translate(' + toolPosition.x + ', ' + toolPosition.y + ') ' + scale);
                    this._tool2Cache.attr('visibility', 'visible');

                } else if (this.options.doubleLinkTools) {

                    this._tool2Cache.attr('visibility', 'hidden');
                }
            }

            return this;
        }
    })

})();
