﻿//-----------------------------------------------------------------------
// <copyright file="DocumentTypeDefinitionController.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox. OneVision Project.
// </copyright>
// <summary> DocumentTypeDefinition Controller method.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Presentation.Web.Controllers
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using Framework.Common.Model.Pagination;
    using Framework.Common.Utility;
    using Framework.UI.Helper;
    using Msc.Framework.UI.Session;
    using Msc.Template.UI;
    using UIServices;
    using ViewModels;
    
    /// <summary>
    /// DocumentTypeDefinition Controller.
    /// </summary>
    [BaseActionFilter]
    public class DocumentTypeDefinitionController : BaseTransactionController
    {
        /// <summary>
        /// The title
        /// </summary>
        public readonly string Title = "General Code";

        /// <summary>
        /// Session Manager.
        /// </summary>
        private readonly SessionManager manager = new SessionManager("ibox@iboxtek.com");

        public override string FunctionCode
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["DocumentTypeDefinition"]; }
        }

       

        public override ActionResult Clear()
        {
            throw new NotImplementedException();
        }

        public override ActionResult Close()
        {
            try
            {
                //this.TaxData = new TaxHeaderView() { GeneralCodeDetail = new GeneralCodeView { ValueType = "A" } };
                return this.View("DocumentTypeDefinitionGrid");
            }
            catch (Exception ex)
            {
                return this.ShowMessage("DocumentTypeDefinition", ex);
            }
        }

        /// <summary>
        /// Create action.
        /// </summary>
        /// <returns> Returns an exception. </returns>
        public ActionResult Create()
        {
            try
            {
                return this.View("DocumentTypeDetail");
                //return this.View("DocumentTypeDetail", new DocumentTypeHeaderView());
            }
            catch (Exception ex)
            {
                return this.ShowMessage("DocumentTypeDetail", ex);
            }
        }

        public override ActionResult DataFilters()
        {
            try
            {
                return this.View(new DocumentTypeViewModel());
            }
            catch (Exception ex)
            {
                return this.ShowMessage("DocumentTypeDefinition", ex);
            }
        }

        public override ActionResult Delete()
        {
            throw new NotImplementedException();
        }

        public override ActionResult Draft()
        {
            throw new NotImplementedException();
        }

        public override ActionResult Edit()
        {
            throw new NotImplementedException();
        }

        public override ActionResult Initialize()
        {
            try
            {
                //this.TaxData = new TaxHeaderView() { GeneralCodeDetail = new GeneralCodeView { ValueType = "A" } };
                return this.View();
            }
            catch (Exception ex)
            {
                return this.ShowMessage("DocumentTypeDefinition", ex);
            }
        }

        public override ActionResult LoadUIValidationRules(long groupId)
        {
            throw new NotImplementedException();
        }

        public override ActionResult Save()
        {
            throw new NotImplementedException();
        }

        public override ActionResult Search()
        {
            try
            {
                return this.View("DocumentTypeDefinitionGrid");
            }
            catch (Exception ex)
            {
                return this.ShowMessage("DocumentTypeDefinition", ex);
            }
        }

        /// <summary>
        /// Filter Dictionary.
        /// </summary>
        /// <returns> Returns FilterData. </returns>
        private IDictionary FilterDictionary()
        {
            IDictionary filterData = new Dictionary<string, object>();
            filterData.Add("CountryDetail.Id", 0);
            filterData.Add("CountryDetail.Name", string.Empty);
            filterData.Add("Code", string.Empty);
            filterData.Add("Description", string.Empty);
            filterData.Add("Percentage", string.Empty);
            filterData.Add("SurchargeDetail.Description", string.Empty);
            filterData.Add("ValidFrom", default(DateTime));
            filterData.Add("ValidTo", default(DateTime));
            filterData.Add("GeneralCodeDetail.Description", string.Empty);
            filterData.Add("TaxTypeDetail.Description", string.Empty);
            return filterData;
        }

        public ActionResult LoadPage(string view)
        {
            return View(view);
        }

        public ActionResult DTD_View_DocumentType()
        {
            return View();
        }

        public ActionResult DTD_View_LI_CC()
        {
            return View();
        }

        #region Callback Methods

        /// <summary>
        /// Generals the code grid call back.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="generalCode">The general code.</param>
        /// <returns>General Code Data with total.</returns>
        [Callback]
        public async Task<ActionResult> DocumentTypeDefinitionCallBack(CallbackRequestData request, DocumentTypeViewModel documentType)
        {
            try
            {
                //IList<DocumentTypeGridView> documentTypeView = new List<DocumentTypeGridView>();

                //documentTypeView.Add(new DocumentTypeGridView { Id=1, SubModuleName = "Customer Invoice" , DocumentType = "INTINV", Description = "Intermodel Invoice", BusinessCode = "02", Status = "A"  });

                //return this.CustomData(documentTypeView, count: 0);

                PageResponse<DocumentTypeViewModel> documentTypes = await DocumentTypeService.Current.GetDocumentTypes(request, documentType);
                if (documentTypes != null && documentTypes.Items != null && documentTypes.Items.Any())
                {
                    return this.CustomData(documentTypes.Items, SimpleConvert.ConvertInt16(documentTypes.TotalCount));
                }

                return this.CustomData(new List<DocumentTypeViewModel>(), count: 0);
            }
            catch (Exception ex)
            {
                return this.ShowMessage(this.Title, ex);
            }
        }

        #endregion Callback Methods
    }
}