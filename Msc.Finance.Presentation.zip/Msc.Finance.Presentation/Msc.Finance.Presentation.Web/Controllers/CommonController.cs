﻿// ***********************************************************************
// <copyright file="CommonController.cs"  company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox
//   OneVision Project
// </copyright>
// <summary>This is the Controller for Common.</summary>
// ***********************************************************************
namespace Msc.MasterData.Presentation.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using Finance.Presentation.Web.UIServices;
    using Finance.Presentation.Web.ViewModels;
    using Framework.Common.Model.Pagination;
    using Framework.Common.Utility;
    using Msc.Framework.UI.Helper;
    //using Msc.MasterData.Presentation.Resources.ValidationErrors;
    //using Msc.MasterData.Presentation.Web.Models;
    //using Msc.Support.Services.Client;
    using Msc.Template.UI;
    //using UIServices;
    using TranslationReader = Msc.MasterData.Service.Proxies.Readers.TranslationReaderService;
    /// <summary>
    /// Class CommonController.
    /// </summary>
    /// <seealso cref="Msc.Template.UI.BaseController" />
    public class CommonController : BaseController
    {
        /// <summary>
        /// Gets the function code.
        /// </summary>
        /// <value>The function code.</value>
        public override string FunctionCode
        {
            get;
        }

        ///// <summary>
        ///// Method for getting message from resource file.
        ///// </summary>
        ///// <param name="keyName">Message code from database.</param>
        ///// <param name="folderName">Folder name of the resource file.</param>
        ///// <param name="resourceFileName">Resource file name from which the message is loaded.</param>
        ///// <returns>Returns The Resource String.</returns>
        //public static string GetResourceString(string keyName, string folderName, string resourceFileName)
        //{
        //    var resourceManager = new System.Resources.ResourceManager("Msc.MasterData.Presentation.Resources." + folderName + "." + resourceFileName, typeof(ValidationMessage).Assembly);
        //    DictionaryEntry entry =
        //        resourceManager.GetResourceSet(Thread.CurrentThread.CurrentCulture, createIfNotExists: true, tryParents: true)
        //          .OfType<DictionaryEntry>()
        //          .FirstOrDefault(e => e.Key.ToString() == keyName);
        //    return entry.Value.ToString();
        //}

        /// <summary>
        /// Method to get sort option details.
        /// </summary>
        /// <param name="request">Call back request.</param>
        /// <returns>Returns a array of strings.</returns>
        public static Dictionary<string, object> GetFilterDetail(CallbackRequestData request)
        {
            Dictionary<string, object> dict = null;
            if (request != null && request.FilterOptions != null && request.FilterOptions.Any())
            {
                dict = new Dictionary<string, object>();
                foreach (var fl in request.FilterOptions)
                {
                    if (dict.ContainsKey(fl.Member))
                    {
                        dict[fl.Member] = fl.Value;
                    }
                    else
                    {
                        dict.Add(fl.Member, fl.Value);
                    }
                }
            }

            return dict;
        }

        ///// <summary>
        ///// Method for UI Validation.
        ///// </summary>
        ///// <param name="functionID">Function ID.</param>
        ///// <param name="sequenceId">Sequence ID.</param>
        ///// <returns>Returns list of UI Validation.</returns>
        //public IEnumerable<object[]> GetUIValidations(string functionID, long sequenceId)
        //{
        //    var helper = new ValidationClient();
        //    return from record in helper.GetUIValidation(functionID, sequenceId).ToList()
        //           select new object[]
        //           {
        //                                   record.Id,
        //                                   record.EntityName,
        //                                   record.PropertyName,
        //                                   record.EntityType,
        //                                   record.DataType,
        //                                   record.MinimumLength,
        //                                   record.MaximumLength,
        //                                   record.MinimumDecimal,
        //                                   record.MaximumDecimal,
        //                                   record.IsUpper,
        //                                   record.RegularExpression,
        //                                   record.MessageType,
        //                                   record.CompareExpression,
        //                                   record.CompareEntity,
        //                                   GetResourceString(record.MinimumLengthMessage, folderName: "ValidationErrors", resourceFileName: "ValidationMessage"),
        //                                   record.MaximumLengthMessage,
        //                                   record.MinimumDecimalMessage,
        //                                   record.MaximumDecimalMessage,
        //                                   record.MinimumDateMessage,
        //                                   record.MaximumDateMessage,
        //                                   record.IsUpperMessage,
        //                                   record.CompareExpressionMessage,
        //                                   record.MinimumDate,
        //                                   record.MaximumDate
        //                          };
        //}

        /// <summary>
        /// General Code Combo-box.
        /// </summary>
        /// <param name="request">Callback Request Data.</param>
        /// <param name="referenceName">Name of the reference.</param>
        /// <param name="lifeCycle">LifeCycle Value.</param>
        /// <param name="id">Id Value of.</param>
        /// <param name="status">Status Value.</param>
        /// <returns>Return List of Data.</returns>
        [Callback]
        public async Task<ActionResult> GetGeneralCodeListByLifeCycle(CallbackRequestData request, string referenceName, string lifeCycle, long id, string status)
        {
            try
            {
                if (request != null)
                {
                    SearchResponse<GeneralCodeBaseViewModel> generalCode = await GeneralCodeService.Current.SearchGeneralCodes(request, referenceName);
                    if (generalCode != null && generalCode.Items != null && generalCode.Items.Any())
                    {
                        return this.CustomData(generalCode.Items, SimpleConvert.ConvertInt32(generalCode.TotalCount));
                    }
                }

                return this.CustomData(new List<GeneralCodeBaseViewModel>(), count: 0);
            }
            catch (Exception ex)
            {
                return this.ShowMessage(title: "GeneralCode Widget", ex: ex);
            }
        }

        /// <summary>
        /// General Code Combo-box.
        /// </summary>
        /// <param name="request">Callback Request Data.</param>
        /// <param name="referenceName">Name of the reference.</param>
        /// <returns>Return List of Data.</returns>
        [Callback]
        public async Task<ActionResult> GetGeneralCodeList(CallbackRequestData request, string referenceName)
        {
            try
            {
                if (request != null)
                {
                    SearchResponse<GeneralCodeBaseViewModel> generalCode = await GeneralCodeService.Current.SearchGeneralCodes(request, referenceName);
                    if (generalCode != null && generalCode.Items != null && generalCode.Items.Any())
                    {
                        return this.CustomData(generalCode.Items, SimpleConvert.ConvertInt32(generalCode.TotalCount));
                    }
                }

                return this.CustomData(new List<GeneralCodeBaseViewModel>(), count: 0);
            }
            catch (Exception ex)
            {
                return this.ShowMessage(title: "GeneralCode Widget", ex: ex);
            }
        }

        ///// <summary>
        ///// Translation List of.
        ///// </summary>
        ///// <param name="request">Request Value.</param>
        ///// <param name="parentId">Parent Id Value.</param>
        ///// <param name="objectName">Object Name.</param>
        ///// <param name="fieldName">Field Name.</param>
        ///// <param name="referrenceName">Reference Name.</param>
        ///// <returns>Reference Name Of.</returns>
        //public async Task<ActionResult> TranslationList(CallbackRequestData request, long parentId, string objectName, string fieldName, string referrenceName)
        //{
        //    PageResponse<TranslationViewModel> translations = await TranslationService.Current.GetTranslations(request);
        //    if (translations != null && translations.Items != null && translations.Items.Any())
        //    {
        //        return this.CustomData(translations.Items, SimpleConvert.ConvertInt16(translations.TotalCount));
        //    }

        //    return this.CustomData(new List<TranslationViewModel>(), count: 0);
        //}

        /// <summary>
        /// Adds the service filter.
        /// </summary>
        /// <typeparam name="T">Generic Class</typeparam>
        /// <param name="key">The key.</param>
        /// <param name="value">The value.</param>
        /// <returns>Filter value.</returns>
        private TranslationReader.Filter AddServiceFilter<T>(string key, T value)
        {
            return new TranslationReader.Filter()
            {
                Criteria = value?.ToString(),
                Member = key,
                CriteriaTypeName = value?.GetType().FullName
            };
        }
    }
}