﻿namespace Msc.Finance.Presentation.Web.Controllers
{
    using Framework.Common.Model.Pagination;
    using Framework.Common.Utility;
    using Framework.UI.Helper;
    using MasterData.Service.Proxies.Readers.GeneralCodeReaderService;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web;
    using System.Web.Mvc;
    using Template.UI;
    using UIServices;
    using ViewModels;
    using DocumentSequenceReadService = Service.Proxies.Readers.DocumentSequenceReaderService;

    [BaseActionFilter]
    public class DocumentSequenceController : BaseTransactionController
    {
        public readonly string Title = "Document Sequence Definition";

        public override string FunctionCode
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["DocumentSequence"];
            }
        }

        public override ActionResult Clear()
        {
            try
            {
                return this.View("DocumentSequenceDetails", new DocumentSequenceViewModel());
            }
            catch (Exception ex)
            {
                return this.ShowMessage("Document Sequence Definition", ex);
            }
        }

        public override ActionResult Close()
        {
            try
            {
                return this.View("DocumentSequenceGrid");
            }
            catch (Exception ex)
            {
                return this.ShowMessage("Document Sequence Definition", ex);
            }
        }

        public override ActionResult DataFilters()
        {
            try
            {
                return this.View();
            }
            catch (Exception ex)
            {
                return this.ShowMessage(this.Title, ex);
            }
        }

        public override ActionResult Delete()
        {
            throw new NotImplementedException();
        }

        public override ActionResult Draft()
        {
            throw new NotImplementedException();
        }

        public override ActionResult Edit()
        {
            throw new NotImplementedException();
        }

        public override ActionResult Initialize()
        {
            try
            {
                return this.View();
            }
           catch(Exception ex)
            {
                return this.ShowMessage(this.Title, ex);
            }
        }

        public override ActionResult LoadUIValidationRules(long groupId)
        {
            throw new NotImplementedException();
        }

        public override ActionResult Save()
        {
            throw new NotImplementedException();
        }

        public override ActionResult Search()
        {
            try
            {
                return this.View("DocumentSequenceGrid");
            }
            catch(Exception ex)
            {
                return this.ShowMessage(this.Title, ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult Create()
        {
            try
            {
                return this.View("DocumentSequenceDetails");
            }
            catch (Exception ex)
            {
                return this.ShowMessage("Document Sequence Definition", ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <param name="documentSequence"></param>
        /// <returns></returns>
        [Callback]
        public async Task<ActionResult> DocumentSequenceGridCallBack(CallbackRequestData request, DocumentSequenceGridViewModel documentSequence)
        {
            try
            {
                if (documentSequence == null)
                {
                    documentSequence = new DocumentSequenceGridViewModel();
                }

                PageResponse<DocumentSequenceGridViewModel> sequences = await DocumentSequenceService.Current.GetDocumentSequences(request, documentSequence);
                if (sequences != null && sequences.Items != null && sequences.Items.Any())
                {
                    return this.CustomData(sequences.Items, sequences.Count);
                }

                return this.CustomData(new List<DocumentSequenceGridViewModel>(), count: 0);
            }
            catch(Exception ex)
            {
                return this.ShowMessage(this.Title, ex);
            }
        }

        /// <summary>
        /// GetModule Detail.
        /// </summary>
        /// <param name="request">Callback Request.</param>
        /// <returns>Returns the list.</returns>
        [Callback]
        public async Task<ActionResult> GetModuleDetail(CallbackRequestData request)
        {
            try
            {
                SearchResponse<GeneralCodeBaseViewModel> sequences = await GeneralCodeService.Current.SearchGeneralCodes(request, "SUB_MODULE");
                if (sequences != null && sequences.Items != null && sequences.Items.Any())
                {
                    return this.CustomData(sequences.Items, sequences.Count);
                }

                return this.CustomData(new List<GeneralCodeBaseViewModel>(), count: 0);
            }
            catch (Exception ex)
            {
                return this.ShowMessage("Document Sequence Definition", ex);
            }
        }

        /// <summary>
        /// GetIssuingCompany Detail.
        /// </summary>
        /// <param name="request">Callback Request.</param>
        /// <returns>Returns the list.</returns>        
        public SearchResponse<GeneralCodeBaseViewModel> GetIssuingCompanyDetail()
        {
            try
            {
                SearchResponse<GeneralCodeBaseViewModel> issuingCompany = new SearchResponse<GeneralCodeBaseViewModel>()
                {
                    Items = new List<GeneralCodeBaseViewModel>()
                    {
                        new GeneralCodeBaseViewModel() { Code = "Agency", Description = "Agency" },
                        new GeneralCodeBaseViewModel() { Code = "Principal", Description = "Principal" }
                    },
                    TotalCount = 2
                };

                return issuingCompany;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GetCountry Detail.
        /// </summary>
        /// <param name="request">Callback Request.</param>
        /// <returns>Returns the list.</returns>
        [Callback]
        public async Task<ActionResult> GetCountryDetail(CallbackRequestData request, string searchName)
        {
            try
            {
                SearchResponse<CountryBaseViewModel> countries = await CountryService.Current.SearchCountries(request, searchName);
                if (countries != null && countries.Items != null && countries.Items.Any())
                {
                    return this.CustomData(countries.Items, countries.Count);
                }

                return this.CustomData(new List<CountryBaseViewModel>(), count: 0);
            }
            catch (Exception ex)
            {
                return this.ShowMessage("Document Sequence Definition", ex);
            }
        }
    }
}