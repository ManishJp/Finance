﻿// ***********************************************************************
// <copyright file="HomeController.cs"  company = "MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox
//   OneVision Project
// </copyright>
// <summary>This is the Controller for Home.</summary>
namespace Msc.Finance.Presentation.Web.Controllers
{
    using System.Web.Mvc;
    using Msc.Template.UI;

    /// <summary>
    /// Class HomeController.
    /// </summary>
    /// <seealso cref="Msc.Template.UI.BaseController" />
    [BaseActionFilter]
    public class HomeController : BaseController
    {
        /// <summary>
        /// Gets the function code.
        /// </summary>
        /// <value>The function code.</value>
        public override string FunctionCode
        {
            get;           
        }
        
        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <returns>Action Result.</returns>
        public ActionResult Index()
        {
            return this.View();
        }
    }
}