﻿namespace Msc.Finance.Service.DataAccess.Contracts
{
    using Framework.Common.Model.Pagination;
    using Msc.Finance.Service.DataAccess.Contracts.Objects;
    using System.Collections.Generic;

    public interface IDocumentTypeDefinitionDataReader
    {
        //PageResponse<DocumentTypeSearchResult> GetDocTypeList(long pageSize, long pageIndex, string sortField, string sortType, string subModule, long documentTypeId, string BusinessCode, bool status, string usedByAgency);
        //DocumentTypeHeader GetDocType(long documentTypeId);

        //DynamicAttributeDefinition GetDocHeaderAttributeList(long documentTypeId);
        //DocumentLineItemBase GetLineItemList(long documentTypeId);

        //DocumentLineItem GetLineItem(long lineItemId);

        //DynamicAttributeDefinition GetDocLineAttributeList(long lineItemId);

        //List<DocumentLineCharge> GetLineChargeList(long lineItemId);
        //DocumentSequenceTemplate GetDocSeqTemplate(long documentTypeId);

        PageResponse<DocumentTypeSearchResult> GetDocumentTypes(PageRequest request);
        DocumentType GetDocumentTypeById(long documentTypeId);
        PageResponse<DynamicAttributeDefinition> GetDocumentHeaderAttributes(long documentTypeId);
        IList<DocumentLineItemBase> GetLineItems(long documentTypeId);
        IList<DocumentLineItem> GetLineItem(long lineItemId);
        IList<DynamicAttributeDefinition> GetDocumentLineAttributes(long lineItemId);
        PageResponse<DocumentLineCharge> GetLineCharges(long lineItemId);
        PageResponse<DocumentSequenceTemplate> GetDocumentSequenceById(long documentTypeId);
    }
}
