﻿//-----------------------------------------------------------------------
// <copyright file="IDocumentSequenceDefinitionDataReader.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This interface is used to describe all available methods for Document Sequence on the data access layer.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Service.DataAccess.Contracts
{
    using Msc.Finance.Service.DataAccess.Contracts.Objects;
    using Msc.Framework.Common.Model.Pagination;

    /// <summary>
    /// Interface DocumentSequenceDefinitionDataReader.
    /// </summary>
    public interface IDocumentSequenceDataReader
    {
        /// <summary>
        /// GetDocumentSequences List.
        /// </summary>
        /// <param name="request">Page Request.</param>
        /// <returns>Returns the list.</returns>
        PageResponse<DocumentSequenceSearchResult> GetDocumentSequences(PageRequest request);

        /// <summary>
        /// GetDocumentSequence ById.
        /// </summary>
        /// <param name="sequenceId">Sequence Id.</param>
        /// <returns>Returns the Document Sequence.</returns>
        DocumentSequence GetDocumentSequenceById(long sequenceId);
    }
}
