﻿namespace Msc.Finance.Service.DataAccess.Contracts
{
    using Msc.Finance.Service.DataAccess.Contracts.Objects;

    public interface IDocumentTypeDefinitionDataWriter
    {
        void SaveDocumentType(DocumentType documentHeader, out bool isSuccess, out string message);
    }
}
