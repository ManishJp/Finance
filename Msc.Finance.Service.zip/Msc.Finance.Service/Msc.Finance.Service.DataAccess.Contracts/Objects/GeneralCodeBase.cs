﻿// ***********************************************************************
// <copyright file="GeneralCodeBase.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the GeneralCodeBase data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.DataAccess.Contracts.Objects
{
    /// <summary>
    /// Class GeneralCodeBase.
    /// </summary>
    public class GeneralCodeBase
    {
        /// <summary>
        /// Gets or sets the Code.
        /// </summary>
        /// <value>The Code.</value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        /// <value>The Description.</value>
        public string Description { get; set; }
    }
}