﻿// ***********************************************************************
// <copyright file="Role.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the Role data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.DataAccess.Contracts.Objects
{
    /// <summary>
    /// Class Role.
    /// </summary>
    public class Role
    {
        /// <summary>
        /// Initializes a new instance of the Role class.
        /// </summary>
        public Role()
        {
        }

        /// <summary>
        /// Gets or sets the Identifier.
        /// </summary>
        /// <value>The Identifier.</value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the Code.
        /// </summary>
        /// <value>The Code.</value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        /// <value>The Description.</value>
        public string Description { get; set; }
    }
}