﻿// ***********************************************************************
// <copyright file="DocumentLineItem.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentLineItem data.
// </summary>
// ***********************************************************************
namespace Msc.Finance.Service.DataAccess.Contracts.Objects
{
    using System.Collections.Generic;

    /// <summary>
    /// Class DocumentLineItem.
    /// </summary>
    public class DocumentLineItem : DocumentLineItemBase
    {
        /// <summary>
        /// Initializes a new instance of the DocumentLineItem class.
        /// </summary>
        public DocumentLineItem()
            : base()
        {
        }

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether IsSelected.
        /// </summary>
        /// <value>Line Item IsSelected.</value>
        public bool IsSelected { get; set; }

        /// <summary>
        /// Gets or sets the LineItemAttributes.
        /// </summary>
        /// <value>This property gets or sets the value of the LineItemAttributes.</value>
        public IList<DynamicAttributeDefinition> LineItemAttributes { get; set; } = new List<DynamicAttributeDefinition>();

        /// <summary>
        /// Gets or sets the DocumentLineCharges.
        /// </summary>
        /// <value>This property gets or sets the value of the DocumentLineCharges.</value>
        public IList<DocumentLineCharge> DocumentLineCharges { get; set; } = new List<DocumentLineCharge>();

        #endregion
    }
}
