﻿// ***********************************************************************
// <copyright file="Charge.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the Charge data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.DataAccess.Contracts.Objects
{
    /// <summary>
    /// Class Charge.
    /// </summary>
    public class Charge
    {
        /// <summary>
        /// Initializes a new instance of the Charge class.
        /// </summary>
        public Charge()
        {
        }

        /// <summary>
        /// Gets or sets the Identifier.
        /// </summary>
        /// <value>The Identifier.</value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the Code.
        /// </summary>
        /// <value>The Code.</value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        /// <value>The Description.</value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the ChargeGroup Detail.
        /// </summary>
        /// <value>The ChargeGroup Detail.</value>
        public ChargeGroupBase ChargeGroup { get; set; } = new ChargeGroupBase();
    }
}