﻿// ***********************************************************************
// <copyright file="DocumentLineCharge.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentLineCharge data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.DataAccess.Contracts.Objects
{
    /// <summary>
    /// Model for Document LineCharge.    
    /// </summary>
    public class DocumentLineCharge 
    {
        /// <summary>
        /// Initializes a new instance of the DocumentLineCharge class.
        /// </summary>
        public DocumentLineCharge()
        {
        }

        /// <summary>
        /// Gets or sets the Identifier.
        /// </summary>
        /// <value>The Identifier.</value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether IsSelected.
        /// </summary>
        /// <value>Line Charge IsSelected.</value>
        public bool IsSelected { get; set; }

        /// <summary>
        /// Gets or sets the Charge.
        /// </summary>
        /// <value>This property gets or sets the value of the Charge.</value>
        public Charge Charge { get; set; } = new Charge();

        /// <summary>
        ///  Gets or sets the value for BusinessCode.
        /// </summary>
        /// <value>Business Code.</value>
        public string BusinessCode { get; set; }
    }
}