﻿// ***********************************************************************
// <copyright file="DocumentSequenceTemplate.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentSequenceTemplate data.
// </summary>
// ***********************************************************************
namespace Msc.Finance.Service.DataAccess.Contracts.Objects
{
    using System;

    /// <summary>
    /// Class DocumentSequenceTemplate.
    /// </summary>
    public class DocumentSequenceTemplate
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the DocumentSequenceTemplate class.
        /// </summary>
        public DocumentSequenceTemplate()            
        {
            this.IssuingCompany = new GeneralCodeBase();
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        ///  Gets or sets the value for CompanyEntityDetail.
        /// </summary>
        /// <value>Company Entity Detail .</value>
        public CompanyEntityBase CompanyEntity { get; set; } = new CompanyEntityBase();

        /// <summary>
        ///  Gets or sets the value for IssuingCompanyDetail.
        /// </summary>
        /// <value>Issuing Company Detail.</value>
        public GeneralCodeBase IssuingCompany { get; set; }

        /// <summary>
        ///  Gets or sets the value for DocumentSequenceDetail.
        /// </summary>
        /// <value>Document Sequence Detail.</value>
        public DocumentSequence DocumentSequence { get; set; } = new DocumentSequence();

        /// <summary>
        ///  Gets or sets a value indicating whether IsSingleTemplate.
        /// </summary>
        /// <value>Single Template Value.</value>
        public bool IsSingleTemplate { get; set; }

        /// <summary>
        ///  Gets or sets the value for DebitDocTemplate.
        /// </summary>
        /// <value>Debit Doc Template.</value>
        public string DebitDocTemplate { get; set; }

        /// <summary>
        ///  Gets or sets the value for CreditDocTemplate.
        /// </summary>
        /// <value>Credit Doc Template.</value>
        public string CreditDocTemplate { get; set; }

        /// <summary>
        ///  Gets or sets the value for ApplicableFrom.
        /// </summary>
        /// <value>Applicable From.</value>
        public DateTime ApplicableFrom { get; set; }

        #endregion Properties
    }
}