﻿// ***********************************************************************
// <copyright file="DynamicAttributeDefinition.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DynamicAttributeDefinition data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.DataAccess.Contracts.Objects
{
    /// <summary>
    /// Model for DynamicAttributeDefinition.
    /// </summary>
    public class DynamicAttributeDefinition
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the DynamicAttributeDefinition class.
        /// </summary>
        public DynamicAttributeDefinition()            
        {
            this.Attribute = new GeneralCodeBase();
            this.Validation = new GeneralCodeBase();
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the Identifier.
        /// </summary>
        /// <value>The Identifier.</value>
        public long Id { get; set; }
    
        /// <summary>
        /// Gets or sets the AttributeDetail.
        /// </summary>
        /// <value>This property gets the value of the AttributeDetail.</value>
        public GeneralCodeBase Attribute { get; set; }

        /// <summary>
        /// Gets or sets the ValidationDetail.
        /// </summary>
        /// <value>This property gets the value of the ValidationDetail.</value>
        public GeneralCodeBase Validation { get; set; }
        #endregion
    }
}