﻿// ***********************************************************************
// <copyright file="DocumentSequence.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentSequence data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.DataAccess.Contracts.Objects
{
    /// <summary>
    /// Model for DocumentSequence.
    /// </summary>
    public class DocumentSequence : DocumentSequenceSearchResult
    {
        /// <summary>
        /// Gets or sets the IsProForma.
        /// </summary>
        /// <value>The IsProForma.</value>
        public bool IsProForma { get; set; }

        /// <summary>
        /// Gets or sets the IsLocation Prefix.
        /// </summary>
        /// <value>The IsLocation Prefix.</value>
        public bool IsLocationPrefix { get; set; }

        /// <summary>
        /// Gets or sets the ResetFrequency Detail.
        /// </summary>
        /// <value>The ResetFrequency Detail.</value>
        public GeneralCode ResetFrequencyDetail { get; set; } = new GeneralCode();

        /// <summary>
        /// Gets or sets the Serial Length.
        /// </summary>
        /// <value>The Serial Length.</value>
        public long SerialLength { get; set; }

        /// <summary>
        /// Gets or sets the Debit Prefix.
        /// </summary>
        /// <value>The Debit Prefix.</value>
        public string DebitPrefix { get; set; }

        /// <summary>
        /// Gets or sets the Debit StartingNo.
        /// </summary>
        /// <value>The Debit StartingNo.</value>
        public long DebitStartingNo { get; set; }

        /// <summary>
        /// Gets or sets the Credit Prefix.
        /// </summary>
        /// <value>The Credit Prefix.</value>
        public string CreditPrefix { get; set; }

        /// <summary>
        /// Gets or sets the Credit StartingNo.
        /// </summary>
        /// <value>The Credit StartingNo.</value>
        public long CreditStartingNo { get; set; }
    }
}