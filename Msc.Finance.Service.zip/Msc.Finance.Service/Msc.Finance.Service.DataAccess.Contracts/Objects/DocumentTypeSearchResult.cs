﻿// ***********************************************************************
// <copyright file="DocumentTypeSearchResult.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentTypeList data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.DataAccess.Contracts.Objects
{
    /// <summary>
    /// Class DocumentTypeList.
    /// </summary>
    public class DocumentTypeSearchResult : DocumentTypeBase
    {
        /// <summary>
        /// Gets or sets the SubModule.
        /// </summary>
        /// <value>Sub Module.</value>
        public GeneralCodeBase SubModule { get; set; } = new GeneralCodeBase();

        /// <summary>
        /// Gets or sets the Business Code.
        /// </summary>
        /// <value>The Business Code.</value>
        public string BusinessCode { get; set; }

        /// <summary>
        /// Gets or sets the DocumentType.
        /// </summary>
        /// <value>The DocumentType.</value>
        public string DocumentType { get; set; }

        /// <summary>
        /// Gets or sets the DocumentType.
        /// </summary>
        /// <value>The DocumentType.</value>
        public bool IsActive { get; set; }        
    }
}