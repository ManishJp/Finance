﻿using Msc.Framework.Service.Core.Communication;
using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;

namespace Msc.Finance.Service.DebugConsole
{
    [ServiceHostConfigurationExport]
    public class ServiceConfiguration : IServiceHostConfiguration
    {
        public Uri BaseAddress { get { return new Uri(uriString: "net.tcp://127.0.0.1:19205"); } }
        public int? ServiceWsdlPort { get { return 19204; } }

        public Binding Binding
        {
            get
            {
                return new NetTcpBinding(SecurityMode.None)
                {
                    ReaderQuotas = new System.Xml.XmlDictionaryReaderQuotas
                    {
                        MaxArrayLength = 2048 * 10,
                        MaxStringContentLength = 2 * 1024 * 1024 / 8,
                    },
                    MaxBufferSize = 2 * 1024 * 1024, // 2MB
                    MaxReceivedMessageSize = 2 * 1024 * 1024, //2 MB
                };
            }
        }

        public IServiceBehavior[] ServiceBehaviors
        {
            get
            {
                return new IServiceBehavior[]
                    {
                        new ServiceDebugBehavior { IncludeExceptionDetailInFaults = true },
                        new Msc.Framework.Service.Core.Diagnostics.TraceServiceBehavior(),
                    };
            }
        }

    }
}
