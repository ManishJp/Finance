﻿using Msc.Framework.Service.Core.Servers;

namespace Msc.Finance.Service.DebugConsole
{
    internal class Server : CompositionServer
    { }
}
