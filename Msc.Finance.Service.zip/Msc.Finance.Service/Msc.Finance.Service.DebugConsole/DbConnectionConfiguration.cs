﻿using Msc.Framework.Service.Core;
using Msc.Framework.Service.Core.DataAccess;
using Msc.Framework.Service.Core.DataAccess.Composition;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Msc.Finance.Service.DebugConsole
{
    //TODO Add app settings string
    [DbConnectionInfoExport("FTE")]
    public class DbConnectionConfiguration : IDbConnectionInfo
    {
        public string DataSource
        {
            get
            {
                return "OVOPS";
            }
        }

        public string Password
        {
            get
            {
                return "OPS";
            }
        }

        public bool PersistSecurityInfo
        {
            get
            {
                return true;
            }
        }

        public string UserID
        {
            get
            {
                return "OPS";
            }
        }
    }
}