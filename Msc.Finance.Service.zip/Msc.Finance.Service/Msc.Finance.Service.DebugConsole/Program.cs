﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Msc.Finance.Service.DebugConsole
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var server = new Server();
            server.Start();
            Console.WriteLine(value: "Press ENTER to stop");
            Console.ReadLine();
            server.Stop();
        }
    }
}