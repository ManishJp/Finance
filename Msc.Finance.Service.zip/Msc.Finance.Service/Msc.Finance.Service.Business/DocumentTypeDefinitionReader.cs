﻿// ***********************************************************************
// <copyright file="DocumentTypeDefinitionDataReader.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This class is used to describe all available methods for DocumentTypeDefinition data access reader.</summary>
// ***********************************************************************
namespace Msc.Finance.Service.Business
{
    using System;
    using System.Collections.Generic;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using Framework.Common.Model.Pagination;
    using Framework.Service.Core.Business;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// DocumentSequence ReaderService.
    /// </summary>
    [BusinessExport]
    public class DocumentTypeDefinitionDataReader : BusinessBase, IDocumentTypeDefinitionReader
    {
        public PageResponse<DynamicAttributeDefinition> GetDocumentHeaderAttributes(long documentTypeId)
        {
            throw new NotImplementedException();
        }

        public IList<DynamicAttributeDefinition> GetDocumentLineAttributes(long lineItemId)
        {
            throw new NotImplementedException();
        }

        public PageResponse<DocumentSequenceTemplate> GetDocumentSequenceById(long documentTypeId)
        {
            throw new NotImplementedException();
        }

        public DocumentType GetDocumentTypeById(long documentTypeId)
        {
            throw new NotImplementedException();
        }

        public PageResponse<DocumentTypeSearchResult> GetDocumentTypes(PageRequest request)
        {
            PageResponse<DataAccessObjects.DocumentTypeSearchResult> documentSequences = CallDataAccess<IDocumentTypeDefinitionDataReader>().GetDocumentTypes(request);
            return this.Map<PageResponse<DocumentTypeSearchResult>>(documentSequences);
        }

        public PageResponse<DocumentLineCharge> GetLineCharges(long lineItemId)
        {
            throw new NotImplementedException();
        }

        public IList<DocumentLineItem> GetLineItem(long lineItemId)
        {
            throw new NotImplementedException();
        }

        public IList<DocumentLineItemBase> GetLineItems(long documentTypeId)
        {
            throw new NotImplementedException();
        }
    }
}

