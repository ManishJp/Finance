﻿//-----------------------------------------------------------------------
// <copyright file="DocumentSequenceReader.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This interface is used to describe all available methods for Document Sequence on the data access layer.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Service.Business
{
    using Contracts.Objects;
    using DataAccess.Contracts;
    using Framework.Common.Model.Pagination;
    using Framework.Service.Core.Business;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// DocumentSequence Reader.
    /// </summary>
    [BusinessExport]
    public class DocumentSequenceReader : BusinessBase, IDocumentSequenceReader
    {
        /// <summary>
        /// GetDocumentSequence ById.
        /// </summary>
        /// <param name="sequenceId">Sequence Id.</param>
        /// <returns>Return the document sequence.</returns>
        public DocumentSequence GetDocumentSequenceById(long sequenceId)
        {
            DataAccessObjects.DocumentSequence documentSequence = CallDataAccess<IDocumentSequenceDataReader>().GetDocumentSequenceById(sequenceId);
            return this.Map<DocumentSequence>(documentSequence);
        }

        /// <summary>
        /// Get DocumentSequences.
        /// </summary>
        /// <param name="request">Page Request.</param>
        /// <returns>Returns the List.</returns>
        public PageResponse<DocumentSequenceSearchResult> GetDocumentSequences(PageRequest request)
        {
            PageResponse<DataAccessObjects.DocumentSequenceSearchResult> documentSequences = CallDataAccess<IDocumentSequenceDataReader>().GetDocumentSequences(request);
            return this.Map<PageResponse<DocumentSequenceSearchResult>>(documentSequences);
        }
    }
}
