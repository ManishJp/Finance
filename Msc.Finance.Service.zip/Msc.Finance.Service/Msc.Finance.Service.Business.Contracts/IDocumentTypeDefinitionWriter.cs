﻿namespace Msc.Finance.Service.Business.Contracts
{
    using Msc.Finance.Service.Business.Contracts.Objects;

    public interface IDocumentTypeDefinitionDataWriter
    {
        void SaveDocumentType(DocumentTypeHeader documentHeader, out bool isSuccess, out string message);
    }
}
