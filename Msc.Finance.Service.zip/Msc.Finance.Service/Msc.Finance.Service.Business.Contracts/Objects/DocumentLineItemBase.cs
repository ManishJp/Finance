﻿// ***********************************************************************
// <copyright file="DocumentLineItemBase.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentLineItemBase data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Class DocumentLineItemBase.
    /// </summary>
    public class DocumentLineItemBase
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        /// <value>The Long Id.</value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the Code.
        /// </summary>
        /// <value>The String Code.</value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        /// <value>The Description.</value>
        public string Description { get; set; }
    }
}