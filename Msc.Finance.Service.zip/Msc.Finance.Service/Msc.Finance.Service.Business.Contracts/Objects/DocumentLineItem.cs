﻿// ***********************************************************************
// <copyright file="DocumentLineItem.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentLineItem data.
// </summary>
// ***********************************************************************
namespace Msc.Finance.Service.Business.Contracts.Objects
{
    using System.Collections.Generic;

    /// <summary>
    /// Class DocumentLineItem.
    /// </summary>
    public class DocumentLineItem : DocumentLineItemBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets the LineItemAttributes.
        /// </summary>
        /// <value>This property gets or sets the value of the LineItemAttributes.</value>
        public IList<DynamicAttributeDefinition> LineItemAttributes { get; set; }

        /// <summary>
        /// Gets or sets the DocumentLineCharges.
        /// </summary>
        /// <value>This property gets or sets the value of the DocumentLineCharges.</value>
        public IList<DocumentLineCharge> DocumentLineCharges { get; set; }

        #endregion
    }
}
