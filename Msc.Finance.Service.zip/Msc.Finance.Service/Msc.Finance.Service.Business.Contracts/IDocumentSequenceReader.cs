﻿//-----------------------------------------------------------------------
// <copyright file="IDocumentSequenceReader.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This interface is used to describe all available methods for Document Sequence on the data access layer.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Service.Business
{
    using Msc.Finance.Service.Business.Contracts.Objects;
    using Msc.Framework.Common.Model.Pagination;

    /// <summary>
    /// Interface DocumentSequenceReader.
    /// </summary>
    public interface IDocumentSequenceReader
    {
        /// <summary>
        /// GetDocumentSequences List.
        /// </summary>
        /// <param name="request">Page Request.</param>
        /// <returns>Returns the list.</returns>
        PageResponse<DocumentSequenceSearchResult> GetDocumentSequences(PageRequest request);

        /// <summary>
        /// GetDocumentSequence ById.
        /// </summary>
        /// <param name="sequenceId">Sequence Id.</param>
        /// <returns>Returns the Document Sequence.</returns>
        DocumentSequence GetDocumentSequenceById(long sequenceId);
    }
}
