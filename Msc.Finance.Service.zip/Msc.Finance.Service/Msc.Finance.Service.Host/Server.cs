﻿//----------------------------------------------------------------------------------------------------------
// <copyright file="Server.cs" company="MSC - iBox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>Class holds the Microsoft extensibility framework container.</summary>
//-----------------------------------------------------------------------------------------------------------

namespace Msc.Finance.Service.Host
{
    using Msc.Framework.Service.Core.Servers;


    /// <summary>
    /// Class holds the Microsoft extensibility framework container.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.Core.Servers.CompositionServer" />
    internal class Server : CompositionServer
    { }
}
