﻿//----------------------------------------------------------------------------------------------------------
// <copyright file="Constants.cs" company="MSC - iBox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>Constants class holds all the constants that are used in the project.</summary>
//-----------------------------------------------------------------------------------------------------------

namespace Msc.Finance.Service.Host
{

    /// <summary>
    /// Constants class holds all the constants that are used in the project.
    /// </summary>
    public static class Constants
    {

        /// <summary>
        /// The service name
        /// </summary>
        internal const string ServiceName = "FinanceService";
        
        /// <summary>
        /// The service display name
        /// </summary>
        internal const string ServiceDisplayName = "Finance Service";
        
        /// <summary>
        /// The service description
        /// </summary>
        internal const string ServiceDescription = "Finance Service";
        
        /// <summary>
        /// The maximum array length
        /// </summary>
        internal const int MaxArrayLength = 20480;
        
        /// <summary>
        /// The maximum string content length
        /// </summary>
        internal const int MaxStringContentLength = 262144;

        /// <summary>
        /// The maximum buffer size
        /// </summary>
        internal const int MaxBufferSize = 2097152;

        /// <summary>
        /// The maximum received message size
        /// </summary>
        internal const int MaxReceivedMessageSize = 2097152;
    }
}
