﻿//----------------------------------------------------------------------------------------------------------
// <copyright file="Program.cs" company="MSC - iBox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>Console application default program file.</summary>
//-----------------------------------------------------------------------------------------------------------

namespace Msc.Finance.Service.Host
{
    using System.ServiceProcess;


    /// <summary>
    /// Application entry point.
    /// </summary>
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            ServiceBase[] servicesToRun;
            servicesToRun = new ServiceBase[]
            {
                new FinanceService()
            };
            ServiceBase.Run(servicesToRun);
        }
    }
}
