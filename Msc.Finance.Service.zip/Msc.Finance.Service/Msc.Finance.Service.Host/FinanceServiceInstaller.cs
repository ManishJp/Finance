﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.ServiceProcess;
using System.Threading.Tasks;

namespace Msc.Finance.Service.Host
{
    [RunInstaller(true)]
    public partial class FinanceServiceInstaller : System.Configuration.Install.Installer
    {
        public FinanceServiceInstaller()
        {
            InitializeComponent();

            // Instantiate installers for process and services.
            var processInstaller = new ServiceProcessInstaller();
            var serviceInstaller = new ServiceInstaller();

            // The services run under the system account.
            processInstaller.Account = ServiceAccount.LocalSystem;

            // The services are started manually.
            serviceInstaller.StartType = ServiceStartMode.Automatic;
            serviceInstaller.DelayedAutoStart = true;
            // ServiceName must equal those on ServiceBase derived classes.
            serviceInstaller.ServiceName = Constants.ServiceName;
            serviceInstaller.DisplayName = Constants.ServiceDisplayName;
            serviceInstaller.Description = Constants.ServiceDescription;

            // Add installers to collection. Order is not important.
            Installers.Add(serviceInstaller);
            Installers.Add(processInstaller);
        }
    }
}
