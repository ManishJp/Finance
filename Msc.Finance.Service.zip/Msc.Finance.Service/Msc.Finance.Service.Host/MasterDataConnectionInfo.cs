﻿//----------------------------------------------------------------------------------------------------------
// <copyright file="MasterDataConnectionInfo.cs" company="MSC - iBox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>Data base configuration export class.</summary>
//-----------------------------------------------------------------------------------------------------------
namespace Msc.MasterData.Service.Host
{
    using Msc.Finance.Service.Host.Properties;
    using Msc.Framework.Service.Core.DataAccess;
    using Msc.Framework.Service.Core.DataAccess.Composition;

    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.Core.DataAccess.DbConnectionInfo" />
    [DbConnectionInfoExport("FTE")]
    public class MasterDataConnectionInfo : DbConnectionInfo
    {
        public MasterDataConnectionInfo()
        {
            this.DataSource = Settings.Default.DbDataSource;
            this.Password = Settings.Default.OpsPassword;
            this.PersistSecurityInfo = true;
            this.UserID = Settings.Default.OpsUserID;
        }
    }
}