﻿//----------------------------------------------------------------------------------------------------------
// <copyright file="ServiceConfiguration.cs" company="MSC - iBox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>Class holds the service configuration..</summary>
//-----------------------------------------------------------------------------------------------------------

namespace Msc.Finance.Service.Host
{
    using System;
    using System.ServiceModel;
    using System.ServiceModel.Channels;
    using System.ServiceModel.Description;
    using Msc.Framework.Service.Core.Communication;
    using Properties;

    /// <summary>
    /// Class holds the service configuration.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.Core.Communication.IServiceHostConfiguration" />
    [ServiceHostConfigurationExport]
    public class ServiceConfiguration : IServiceHostConfiguration
    {
        /// <summary>
        /// Gets the base address.
        /// </summary>
        /// <value>
        /// The base address.
        /// </value>
        public Uri BaseAddress { get { return new Uri(uriString: Settings.Default.DbDataSource); } }


        /// <summary>
        /// Gets the service WSDL port.
        /// </summary>
        /// <value>
        /// The service WSDL port.
        /// </value>
        public int? ServiceWsdlPort { get { return Convert.ToInt16(Settings.Default.ServiceWsdlPort); } }

        /// <summary>
        /// Gets the binding.
        /// </summary>
        /// <value>
        /// The binding.
        /// </value>
        public Binding Binding
        {
            get
            {
                return new NetTcpBinding(SecurityMode.None)
                {
                    ReaderQuotas = new System.Xml.XmlDictionaryReaderQuotas
                    {
                        MaxArrayLength = Constants.MaxArrayLength,
                        MaxStringContentLength = Constants.MaxStringContentLength,
                    },
                    MaxBufferSize = Constants.MaxBufferSize,
                    MaxReceivedMessageSize = Constants.MaxReceivedMessageSize
                };
            }
        }

        /// <summary>
        /// Gets the service behaviors.
        /// </summary>
        /// <value>
        /// The service behaviors.
        /// </value>
        public IServiceBehavior[] ServiceBehaviors
        {
            get
            {
                return new IServiceBehavior[]
                    {
                        new ServiceDebugBehavior { IncludeExceptionDetailInFaults = true },
                    };
            }
        }
    }
}
