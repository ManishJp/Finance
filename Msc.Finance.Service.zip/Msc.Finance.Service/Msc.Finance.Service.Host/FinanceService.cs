﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace Msc.Finance.Service.Host
{
    partial class FinanceService : ServiceBase
    {
        private static Server server = null;

        public FinanceService()
        {
            InitializeComponent();
            this.ServiceName = Constants.ServiceName;
        }

        protected override void OnStart(string[] args)
        {
            if (server == null)
            {
                server = new Server();
            }
            server.Start();
        }

        protected override void OnStop()
        {
            if (server != null)
            {
                server.Stop();
            }
        }
    }
}
