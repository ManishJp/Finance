﻿//----------------------------------------------------------------------------------------------------------
// <copyright file="MasterDataConnectionInfo.cs" company="MSC - iBox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>Data base configuration export class.</summary>
//-----------------------------------------------------------------------------------------------------------

namespace Msc.MasterData.Service.Host
{
    using Msc.Framework.Service.Core.DataAccess;
    using Msc.Framework.Service.Core.DataAccess.Composition;


    /// <summary>
    /// Data base configuration export class.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.Core.DataAccess.IDbConnectionInfo" />
    [DbConnectionInfoExport("FTE")]
    public class DbConnectionConfiguration : IDbConnectionInfo
    {        
        public string DataSource
        {
            get
            {
              return "OVOPS";
            }
        }

        public string Password
        {
            get
            {
                return "OPS";
            }
        }

        public bool PersistSecurityInfo
        {
            get
            {
                return true;
            }
        }

        public string UserID
        {
            get
            {
                return "OPS";
            }
        }
    }
}
