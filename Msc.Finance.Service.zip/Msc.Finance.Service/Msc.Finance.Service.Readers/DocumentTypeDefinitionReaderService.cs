﻿// ***********************************************************************
// <copyright file="DocumentTypeDefinitionDataReader.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This class is used to describe all available methods for DocumentTypeDefinition data access reader.</summary>
// ***********************************************************************
namespace Msc.Finance.Service.Reader
{
    using System;
    using System.Collections.Generic;
    using System.ServiceModel;
    using Business;
    using Contracts.Objects;
    using Framework.Common.Model.Pagination;
    using Msc.Finance.Service.Contracts;
    using Msc.Framework.Service.Core.Services;
    using BusinessObject = Business.Contracts.Objects;
    using Readers.Wrapper;
    using Business.Contracts;    
    
    /// <summary>
    /// DocumentSequence ReaderService.
    /// </summary>
    [ServiceExport]
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerCall)]
    public class DocumentTypeDefinitionDataReader : ServiceBase, IDocumentTypeDefinitionReaderService
    {
        public PageResponse<DynamicAttributeDefinition> GetDocumentHeaderAttributes(long documentTypeId)
        {
            throw new NotImplementedException();
        }

        public IList<DynamicAttributeDefinition> GetDocumentLineAttributes(long lineItemId)
        {
            throw new NotImplementedException();
        }

        public PageResponse<DocumentSequenceTemplate> GetDocumentSequenceById(long documentTypeId)
        {
            throw new NotImplementedException();
        }

        public DocumentType GetDocumentTypeById(long documentTypeId)
        {
            throw new NotImplementedException();
        }

        public PageResponse<DocumentTypeSearchResult> GetDocumentTypes(PageRequest request)
        {
            try
            {
                PageResponse<BusinessObject.DocumentTypeSearchResult> documentSequences = CallBusiness<IDocumentTypeDefinitionReader>().GetDocumentTypes(request);
                return this.Map<PageResponse<DocumentTypeSearchResult>>(documentSequences);
            }
            catch (Exception ex)
            {
                ex.HandleCatch();
                throw;
            }
        }

        public IList<DocumentLineCharge> GetLineCharges(long lineItemId)
        {
            throw new NotImplementedException();
        }

        public DocumentLineItem GetLineItem(long lineItemId)
        {
            throw new NotImplementedException();
        }

        public IList<DocumentLineItemBase> GetLineItems(long documentTypeId)
        {
            throw new NotImplementedException();
        }
    }
}

