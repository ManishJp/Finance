﻿//-----------------------------------------------------------------------
// <copyright file="Extension.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - Ibox. OneVision Project.
// </copyright>
// <summary>
// Extension class.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Service.Readers.Wrapper
{
    using System;
    using Msc.Framework.Common.ExceptionManagement;

    /// <summary>
    /// CatchExtensions class to handle common catch block.
    /// </summary>
    public static class Extension
    {
        /// <summary>
        /// HandleCatch method.
        /// </summary>
        /// <param name="ex">Input parameter.</param>
        public static void HandleCatch(this Exception ex)
        {
            Exception outException;
            ExceptionAnalyzer.GetInstance.HandleException(ex, out outException);
            if (outException != null)
            {
                throw outException;
            }
        }
    }
}