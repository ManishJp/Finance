﻿//-----------------------------------------------------------------------
// <copyright file="DocumentSequenceReaderService.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This interface is used to describe all available methods for Document Sequence on the data access layer.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Service.Readers
{
    using System;
    using System.ServiceModel;
    using Business;
    using Contracts.Objects;
    using Framework.Common.Model.Pagination;
    using Msc.Finance.Service.Contracts;
    using Msc.Framework.Service.Core.Services;
    using Wrapper;
    using BusinessObject = Business.Contracts.Objects;

    /// <summary>
    /// DocumentSequence ReaderService.
    /// </summary>
    [ServiceExport]
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerCall)]
    public class DocumentSequenceReaderService : ServiceBase, IDocumentSequenceReaderService
    {
        /// <summary>
        /// GetDocumentSequence ById.
        /// </summary>
        /// <param name="sequenceId">Sequence Id.</param>
        /// <returns>Return the document sequence.</returns>
        public DocumentSequence GetDocumentSequenceById(long sequenceId)
        {
            try
            {
                BusinessObject.DocumentSequence documentSequence = CallBusiness<IDocumentSequenceReader>().GetDocumentSequenceById(sequenceId);
                return this.Map<DocumentSequence>(documentSequence);
            }
            catch (Exception ex)
            {
                ex.HandleCatch();
                throw;
            }
        }

        /// <summary>
        /// Get DocumentSequences.
        /// </summary>
        /// <param name="request">Page Request.</param>
        /// <returns>Returns the List.</returns>
        public PageResponse<DocumentSequenceSearchResult> GetDocumentSequences(PageRequest request)
        {
            try
            {
                PageResponse<BusinessObject.DocumentSequenceSearchResult> documentSequences = CallBusiness<IDocumentSequenceReader>().GetDocumentSequences(request);
                return this.Map<PageResponse<DocumentSequenceSearchResult>>(documentSequences);
            }
            catch (Exception ex)
            {
                ex.HandleCatch();
                throw;
            }
        }
    }
}