﻿// ***********************************************************************
// <copyright file="DocumentTypeDefinitionDataReader.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This class is used to describe all available methods for DocumentTypeDefinition data access reader.</summary>
// ***********************************************************************
namespace Msc.Finance.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Contracts;
    using Contracts.Objects;
    using Framework.Common.Utility;
    using Framework.Service.Core.DataAccess;
    using Framework.Service.Core.DataAccess.OracleClient;
    using Helpers;
    using Properties;
    using Framework.Common.Model.Pagination;
    /// <summary>
    /// Class DocumentTypeDefinitionDataReader.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.Core.DataAccess.DbDataAccessBase" />
    /// <seealso cref="Msc.Finance.Service.DataAccess.Contracts.IDocumentTypeDefinitionDataReader" />
    [DataAccessExport]
    public class DocumentTypeDefinitionDataReader : DbDataAccessBase, IDocumentTypeDefinitionDataReader
    {
        /// <summary>
        /// The success
        /// </summary>
        public readonly DbParameter Success;

        public DocumentTypeDefinitionDataReader()
        {
            Success = this.CreateParameter(name: "p_issuccess", value: DBNull.Value, direction: ParameterDirection.Output);
            Success.Size = 250;
        }

        /// <summary>
        /// Gets the default name of the connection contract.
        /// </summary>
        /// <value>The default name of the connection contract.</value>
        protected override string DefaultConnectionContractName
        {
            get
            {
                return "FTE";
            }
        }

        public PageResponse<DynamicAttributeDefinition> GetDocumentHeaderAttributes(long documentTypeId)
        {
            throw new NotImplementedException();
        }

        public IList<DynamicAttributeDefinition> GetDocumentLineAttributes(long lineItemId)
        {
            throw new NotImplementedException();
        }

        public PageResponse<DocumentSequenceTemplate> GetDocumentSequenceById(long documentTypeId)
        {
            throw new NotImplementedException();
        }

        public DocumentType GetDocumentTypeById(long documentTypeId)
        {
            throw new NotImplementedException();
        }

        public PageResponse<DocumentTypeSearchResult> GetDocumentTypes(PageRequest request)
        {
            //List<DocumentTypeSearchResult> documentSequences = default(List<DocumentTypeSearchResult>);
            //int total = 1;

            //IList<DocumentTypeSearchResult> documentTypeView = new List<DocumentTypeSearchResult>();

            //documentTypeView.Add(new DocumentTypeSearchResult { Id = 1, SubModule = new GeneralCodeBase { Description = "Customer Invoice" }, DocumentType = "INTINV", Description = "Intermodel Invoice", BusinessCode = "02", Status = new GeneralCodeBase { Description = "Active" }, UsedByAgency = "Yes" });
            //return request.CreateResponse(documentTypeView, total);

            List<DocumentTypeSearchResult> documentTypes = default(List<DocumentTypeSearchResult>);
            int total = 0;
            
            if (request != null)
            {
                Dictionary<string, object> requestValue = request.ToDictionary();
                DbParameter countParameter = this.CreateParameter(name: "p_fidot_count", dbType: DbType.Int32, size: 20, direction: ParameterDirection.Output);

                using (DbAccess context = new DbAccess(Settings.Default.DbConnectionString))
                {
                    DbParameter[] parameters =
                    {
                        this.CreateParameter("p_fidot_module", value: requestValue.GetValue(key: "module")),
                        this.CreateParameter("p_mdcoe_id", value: requestValue.GetValue(key: "companyEntityId")),
                        this.CreateParameter("p_fidot_id", value: requestValue.GetValue(key: "documentTypeId")),
                        this.CreateParameter("p_fidtu_businesscode", value: requestValue.GetValue(key: "businessCode")),
                        this.CreateParameter("p_fidot_status", value: requestValue.GetValue(key: "status")),
                        this.CreateParameter("p_usedbyagency", value: requestValue.GetValue(key: "usedByAgency")),
                        this.CreateParameter("p_page_size", value: request.PageSize),
                        this.CreateParameter("p_page_index", value: request.PageIndex),
                        this.CreateParameter("p_sort_field", value: requestValue.GetSortColumn()),
                        this.CreateParameter("p_sort_type", value: requestValue.GetSortOrder()),
                        countParameter,
                        this.CreateReadableParameter("p_fidot_list"),
                        this.Success,
                        this.CreateReadableParameter("p_message")
                    };
                    context.ExecuteNonQuery(storedProcedure: "FIPR_DOCTYPEDEFINITION.GetList_fidot_PRC", parameters: parameters);
                    ReadableDbParameter readableParameter = this.GetReadableParameter(parameters);
                    if (readableParameter != null)
                    {
                        documentTypes = readableParameter.ToDocumentTypes();
                    }

                    total = SimpleConvert.ConvertInt32(countParameter.Value);
                }

                return request.CreateResponse<DocumentTypeSearchResult>(documentTypes ?? new List<DocumentTypeSearchResult>(), total);
            }

            return new PageResponse<DocumentTypeSearchResult>();

           
        }

        public PageResponse<DocumentLineCharge> GetLineCharges(long lineItemId)
        {
            throw new NotImplementedException();
        }

        public IList<DocumentLineItem> GetLineItem(long lineItemId)
        {
            throw new NotImplementedException();
        }

        public IList<DocumentLineItemBase> GetLineItems(long documentTypeId)
        {
            throw new NotImplementedException();
        }
    }
}

