﻿//-----------------------------------------------------------------------
// <copyright file="DocumentSequenceDataReader.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This class is used to describe all available methods for DocumentSequenceDataReader data access reader.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Service.DataAccess
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Contracts;
    using Contracts.Objects;
    using Framework.Common.Model.Pagination;
    using Framework.Common.Utility;
    using Framework.Service.Core.DataAccess;
    using Framework.Service.Core.DataAccess.OracleClient;
    using Helpers;
    using Properties;

    /// <summary>
    /// DocumentSequenceDataReader class.
    /// </summary>
    [DataAccessExport]
    public class DocumentSequenceDataReader : DbDataAccessBase, IDocumentSequenceDataReader
    {
        /// <summary>
        ///  Initializes a new instance of the <see cref="DocumentSequenceDataReader"/> class..
        /// </summary>
        public DocumentSequenceDataReader()
        {
        }

        /// <summary>
        /// DefaultConnectionContractName FTE.
        /// </summary>
        /// <value>The value of DefaultConnectionContractName.</value>
        protected override string DefaultConnectionContractName
        {
            get
            {
                return "FTE";
            }
        }

        /// <summary>
        /// Get DocumentSequence ById.
        /// </summary>
        /// <param name="sequenceId">Sequence Id.</param>
        /// <returns>Returns the Document Sequence.</returns>
        public DocumentSequence GetDocumentSequenceById(long sequenceId)
        {
            DocumentSequence sequence = default(DocumentSequence);
            using (DbAccess context = new DbAccess(Settings.Default.DbConnectionString))
            {
                DbParameter[] parameters = new[]
                {
                    this.CreateParameter("p_fidsd_id", sequenceId),
                    this.CreateReadableParameter("p_fidsd_rec"),                
                    this.CreateParameter("p_issuccess", DbType.String, 50, ParameterDirection.Output),
                    this.CreateReadableParameter("p_message")
                };
                context.ExecuteNonQuery("FIPR_DocSeqDefinition.Get_fidsd_PRC", parameters);
                ReadableDbParameter readableParameter = this.GetReadableParameter(parameters);
                if (readableParameter != null)
                {
                    List<DocumentSequence> documentSequences = readableParameter.ToDocumentSequence();

                    if (documentSequences != null && documentSequences.Any())
                    {
                        sequence = documentSequences.FirstOrDefault();
                    }
                }
            }

            return sequence ?? new DocumentSequence();
        }

        /// <summary>
        /// Get DocumentSequences.
        /// </summary>
        /// <param name="request">Page Request.</param>
        /// <returns>Returns the Document sequences.</returns>
        public PageResponse<DocumentSequenceSearchResult> GetDocumentSequences(PageRequest request)
        {
            List<DocumentSequenceSearchResult> documentSequences = default(List<DocumentSequenceSearchResult>);
            int total;
            using (DbAccess context = new DbAccess(Settings.Default.DbConnectionString))
            {
                Dictionary<string, object> requestValue = request.ToDictionary();
                DbParameter countParameter = this.CreateParameter("p_fidsd_count", DbType.Int32, 50, ParameterDirection.Output);
                DbParameter[] parameters = new[]
                {
                    this.CreateParameter("p_mdcoe_id", 405),
                    this.CreateParameter("p_fidsd_module", requestValue.GetValue("moduleName")),
                    this.CreateParameter("p_fidsd_issuingcompany", requestValue.GetValue("issuingCompanyName")),
                    this.CreateParameter("p_fidsd_code", requestValue.GetValue("sequenceCode")),
                    this.CreateParameter("p_fidsd_name", requestValue.GetValue("sequenceName")),
                    this.CreateParameter("p_page_size", request.PageSize),
                    this.CreateParameter("p_page_index", request.PageIndex),
                    this.CreateParameter("p_sort_field", DocumentSequenceHelper.GetSortField(requestValue.GetValue(key: "sortColumn") as string)),
                    this.CreateParameter("p_sort_type", requestValue.GetValue(key: "sortOrder")),
                    countParameter,
                    this.CreateReadableParameter("p_fidsd_list"),
                    this.CreateParameter("p_issuccess", DbType.String, 50, ParameterDirection.Output),
                    this.CreateReadableParameter("p_message")
                };
                context.ExecuteNonQuery("FIPR_DocSeqDefinition.GetList_fidsd_PRC", parameters);
                ReadableDbParameter readableParameter = this.GetReadableParameter(parameters);
                if (readableParameter != null)
                {
                    documentSequences = readableParameter.ToDocumentSequences();
                }

                total = SimpleConvert.ConvertInt32(countParameter.Value);
            }

            return request.CreateResponse(documentSequences ?? new List<DocumentSequenceSearchResult>(), total);
        }
    }
}
