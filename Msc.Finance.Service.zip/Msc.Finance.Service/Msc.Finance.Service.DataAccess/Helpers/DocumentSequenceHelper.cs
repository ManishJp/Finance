﻿//-----------------------------------------------------------------------
// <copyright file="DocumentSequenceHelper.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This class is used to describe all available methods for DocumentSequenceHelper data access reader.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Service.DataAccess.Helpers
{
    using System.Collections.Generic;
    using System.Data.Common;
    using Contracts.Objects;
    using Framework.Common.Utility;
    using Framework.Service.Core.DataAccess;

    /// <summary>
    /// To DocumentSequences.
    /// </summary>
    internal static class DocumentSequenceHelper
    {
        /// <summary>
        /// ToDocumentSequences Record.
        /// </summary>
        /// <param name="refcursor">Readable DbParameter.</param>
        /// <returns>Returns the documentSequence.</returns>
        internal static List<DocumentSequence> ToDocumentSequence(this ReadableDbParameter refcursor)
        {
            List<DocumentSequence> documentSequences = null;
            using (DbDataReader reader = refcursor.GetDataReader())
            {
                if (reader == null || !reader.HasRows)
                {
                    return documentSequences;
                }

                documentSequences = new List<DocumentSequence>();
                while (reader.Read())
                {
                    var documentSequence = new DocumentSequence();
                    documentSequence.Id = SimpleConvert.ConvertInt64(reader["FIDSD_ID"]);
                    documentSequence.SubModuleDetail.Code = SimpleConvert.ToString(reader["FIDSD_Module"]);
                    documentSequence.SubModuleDetail.Description = SimpleConvert.ToString(reader["Module_Description"]);
                    //// documentSequence.CompanyEntityDetail.Id = SimpleConvert.ConvertInt32(reader["MDCOE_ID"]);
                    documentSequence.IssuingCompanyDetail.Code = SimpleConvert.ToString(reader["FIDSD_IssuingCompany"]);
                    documentSequence.IssuingCompanyDetail.Description = SimpleConvert.ToString(reader["IssuingCompany_Description"]);
                    documentSequence.Code = SimpleConvert.ToString(reader["FIDSD_Code"]);
                    documentSequence.Description = SimpleConvert.ToString(reader["FIDSD_Name"]);
                    documentSequence.IsProForma = SimpleConvert.ToBoolean(reader["FIDSD_HasProforma"]);
                    documentSequence.IsLocationPrefix = SimpleConvert.ToBoolean(reader["FIDSD_HasLocationPrefix"]);
                    documentSequence.ResetFrequencyDetail.Description = SimpleConvert.ToString(reader["FIDSD_ResetFrequency"]);
                    documentSequence.SerialLength = SimpleConvert.ConvertInt64(reader["FIDSD_MaxLength"]);
                    documentSequence.DebitPrefix = SimpleConvert.ToString(reader["FIDSD_DebitPrefix"]);
                    documentSequence.DebitStartingNo = SimpleConvert.ConvertInt64(reader["FIDSD_DebitStartingNo"]);
                    documentSequence.CreditPrefix = SimpleConvert.ToString(reader["FIDSD_CreditPrefix"]);
                    documentSequence.CreditStartingNo = SimpleConvert.ConvertInt64(reader["FIDSD_CreditStartingNo"]);
                }                             
            }

            return documentSequences;
        }

        /// <summary>
        /// Document Sequences List.
        /// </summary>
        /// <param name="refcursor">Readable Db parameter.</param>
        /// <returns>Returns the list.</returns>
        internal static List<DocumentSequenceSearchResult> ToDocumentSequences(this ReadableDbParameter refcursor)
        {
            List<DocumentSequenceSearchResult> documentSequences = null;
            using (DbDataReader reader = refcursor.GetDataReader())
            {
                if (reader == null || !reader.HasRows)
                {
                    return documentSequences;
                }

                documentSequences = new List<DocumentSequenceSearchResult>();
                while (reader.Read())
                {
                    var documentSequence = new DocumentSequenceSearchResult();
                    documentSequence.Id = SimpleConvert.ConvertInt64(reader["FIDSD_ID"]);
                    documentSequence.SubModuleDetail.Description = SimpleConvert.ToString(reader["Module_Description"]);
                    documentSequence.IssuingCompanyDetail.Description = SimpleConvert.ToString(reader["IssuingCompany_Description"]);
                    documentSequence.Code = SimpleConvert.ToString(reader["FIDSD_Code"]);
                    documentSequence.Description = SimpleConvert.ToString(reader["FIDSD_Name"]);
                    documentSequence.CountryHODetail.Description = SimpleConvert.ToString(reader["CountryHO"]);
                    documentSequences.Add(documentSequence);
                }               
            }

            return documentSequences;
        }

        /// <summary>
        /// Get SortField for DocumentSequence.
        /// </summary>
        /// <param name="sortField">Sort Field.</param>
        /// <returns>Returns the value.</returns>
        internal static object GetSortField(string sortField)
        {
            switch (sortField)
            {
                case "ModuleDetail.Name":
                    return "Module_Description";

                case "IssuingCompanyDetail.Name":
                    return "IssuingCompany_Description";

                case "Code":
                    return "FIDSD_Code";

                case "Name":
                    return "FIDSD_Name";

                case "CountryHODetail.Name":
                    return "CountryHO";

                default:
                    return "Module_Description";
            }
        }
    }
}
