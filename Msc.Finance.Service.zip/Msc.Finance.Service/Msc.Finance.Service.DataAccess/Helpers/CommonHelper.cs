﻿// ***********************************************************************
// <copyright file="CommonHelper.cs" company="MSC - Ibox">
//     Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This class is used to put the conversion methods for CommonHelper class.</summary>
// ***********************************************************************
namespace Msc.Finance.Service.DataAccess.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Framework.Common.Utility;
    using Framework.Common.Model.Pagination;    

    /// <summary>
    /// Class CommonHelper.
    /// </summary>
    internal static class CommonHelper
    {
        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <param name="value">The Dictionary value.</param>
        /// <param name="key">The Dictionary key.</param>
        /// <returns>Dictionary Value For Current Key.</returns>
        internal static object GetValue(this IDictionary<string, object> value, string key)
        {
            if (value.ContainsKey(key))
            {
                return value[key];
            }

            return DBNull.Value;
        }

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Dictionary Value For Current Key.</returns>
        internal static string GetSortColumn(this IDictionary<string, object> value)
        {
            if (value.ContainsKey("sortColumn"))
            {
                return SimpleConvert.ToString(value["sortColumn"]);
            }

            return string.Empty;
        }

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Dictionary Value For Current Key.</returns>
        internal static string GetSortOrder(this IDictionary<string, object> value)
        {
            if (value.ContainsKey("sortOrder"))
            {
                return SimpleConvert.ToString(value["sortOrder"]);
            }

            return string.Empty;
        }

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <param name="request">Page Request.</param>
        /// <returns>Dictionary Value For all request.</returns>
        internal static Dictionary<string, object> ToDictionary(this PageRequest request)
        {
            var dictionary = new Dictionary<string, object>();
            
            if (request.Filters != null && request.Filters.Any())
            {
                foreach (var filter in request.Filters)
                {
                    dictionary.AddData(filter.Member, filter.Criteria, filter.CriteriaTypeName);
                }
            }

            if (request.Sorts != null && request.Sorts.Any())
            {
                ISort sort = request.Sorts.FirstOrDefault();
                dictionary.Add(key: "sortColumn", value: sort.Member);
                dictionary.Add(key: "sortOrder", value: sort.IsDescending ? "desc" : "asc");
            }

            return dictionary;
        }

        /// <summary>
        /// Adds the data.
        /// </summary>
        /// <param name="dictionary">The dictionary.</param>
        /// <param name="key">The key Parameter.</param>
        /// <param name="value">The value Parameter.</param>
        /// <param name="typeName">Name of the type.</param>
        internal static void AddData(this IDictionary<string, object> dictionary, string key, string value, string typeName)
        {
            object currentValue = null;
            if (string.IsNullOrEmpty(typeName) || typeName == typeof(string).FullName)
            {
                currentValue = value;
            }
            else if (typeName == typeof(DateTime).FullName)
            {
                currentValue = RemoveDefaultValue(SimpleConvert.ToDate(value));
            }
            else if (typeName == typeof(long).FullName)
            {
                currentValue = RemoveDefaultValue(SimpleConvert.ConvertInt64(value));
            }
            else if (typeName == typeof(int).FullName)
            {
                currentValue = RemoveDefaultValue(SimpleConvert.ConvertInt32(value));
            }
            else if (typeName == typeof(short).FullName)
            {
                currentValue = RemoveDefaultValue(SimpleConvert.ConvertInt16(value));
            }
            else if (typeName == typeof(double).FullName)
            {
                currentValue = RemoveDefaultValue(SimpleConvert.ToDouble(value));
            }

            if (dictionary.ContainsKey(key))
            {
                dictionary[key] = currentValue;
            }
            else
            {
                dictionary.Add(key, currentValue);
            }
        }

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>String Value for corresponding boolean.</returns>
        internal static object GetBooleanValue(this bool value)
        {
            if (value)
            {
                return 'Y';
            }

            return 'N';
        }

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Record Status.</returns>
        internal static object GetRecordStatusById(this long value)
        {
            if (value == default(long))
            {
                return 'I';
            }

            return 'U';
        }

        /// <summary>
        /// Remove Default Value.
        /// </summary>
        /// <typeparam name="T">Input generic data type.</typeparam>
        /// <param name="value">Input parameter.</param>
        /// <returns>Value or null.</returns>
        internal static object RemoveDefaultValue<T>(T value)
        {
            switch (Type.GetTypeCode(typeof(T)))
            {
                case TypeCode.String:
                    if (string.IsNullOrWhiteSpace(value as string))
                    {
                        return DBNull.Value;
                    }

                    return value;
                    
                case TypeCode.DateTime:
                    DateTime converted = SimpleConvert.ToDate(value);
                    if (converted.Date == default(DateTime))
                    {
                        return DBNull.Value;
                    }

                    return converted;

                default:
                    if (EqualityComparer<T>.Default.Equals(value, default(T)))
                    {
                        return DBNull.Value;
                    }

                    return value;
            }
        }
    }
}
