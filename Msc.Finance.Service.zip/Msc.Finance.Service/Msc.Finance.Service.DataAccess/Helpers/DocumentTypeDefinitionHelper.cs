﻿// ***********************************************************************
// <copyright file="DocumentTypeDefinitionHelper.cs" company="MSC - Ibox">
//     Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This class is used to put the conversion methods for DocumentTypeDefinition class.</summary>
// ***********************************************************************
namespace Msc.Finance.Service.DataAccess.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using Msc.Finance.Service.DataAccess.Contracts.Objects;
    using Framework.Service.Core.DataAccess;
    using Framework.Common.Utility;

    /// <summary>
    /// DocumentTypeDefinitionHelper Class.
    /// </summary>
    internal static class DocumentTypeDefinitionHelper
    {
        /// <summary>
        /// To DocumentTypes.   
        /// </summary>
        /// <param name="refCursor">The reference cursor.</param>
        /// <returns>Returns the list of document type.</returns>
        internal static List<DocumentTypeSearchResult> ToDocumentTypes(this ReadableDbParameter refCursor)
        {
            List<DocumentTypeSearchResult> result = new List<DocumentTypeSearchResult>();
            using (var reader = refCursor.GetDataReader())
            {
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        DocumentTypeSearchResult documentType = new DocumentTypeSearchResult();
                        documentType.Id = SimpleConvert.ConvertInt64(reader["FIDOT_ID"]);
                        documentType.Code = SimpleConvert.ToString(reader["FIDOT_Code"]);
                        documentType.Description = SimpleConvert.ToString(reader["FIDOT_Description"]);
                        documentType.BusinessCode = SimpleConvert.ToString(reader["FIDTU_BusinessCode"]);
                        documentType.IsActive = SimpleConvert.ToString(reader["FIDOT_Status"]) == "Y";
                        documentType.SubModule.Description = SimpleConvert.ToString(reader["Module_Description"]);
                        result.Add(documentType);
                    }
                }
            }

            return result;
        }
    }
}
