﻿namespace Msc.Finance.Service.Contracts
{
    using System.Collections.Generic;
    using System.ServiceModel;
    using Msc.Finance.Service.Contracts.Objects;
    using Framework.Common.Model.Pagination;

    [ServiceContract]
    public interface IDocumentTypeDefinitionReaderService
    {
        [OperationContract]
        PageResponse<DocumentTypeSearchResult> GetDocumentTypes(PageRequest request);

        [OperationContract]
        DocumentType GetDocumentTypeById(long documentTypeId);

        [OperationContract]
        PageResponse<DynamicAttributeDefinition> GetDocumentHeaderAttributes(long documentTypeId);

        [OperationContract]
        IList<DocumentLineItemBase> GetLineItems(long documentTypeId);

        [OperationContract]
        DocumentLineItem GetLineItem(long lineItemId);

        [OperationContract]
        IList<DynamicAttributeDefinition> GetDocumentLineAttributes(long lineItemId);

        [OperationContract]
        IList<DocumentLineCharge> GetLineCharges(long lineItemId);

        [OperationContract]
        PageResponse<DocumentSequenceTemplate> GetDocumentSequenceById(long documentTypeId);
    }
}
