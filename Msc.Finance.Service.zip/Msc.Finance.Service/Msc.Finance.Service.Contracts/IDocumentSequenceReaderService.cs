﻿//-----------------------------------------------------------------------
// <copyright file="IDocumentSequenceServiceReader.cs" company="MSC - Ibox">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>This interface is used to describe all available methods for Document Sequence on the data access layer.</summary>
//-----------------------------------------------------------------------
namespace Msc.Finance.Service.Contracts
{
    using Framework.Common.Model.Pagination;
    using Objects;
    using System.ServiceModel;

    [ServiceContract]
    public interface IDocumentSequenceReaderService
    {
        /// <summary>
        /// GetDocumentSequences List.
        /// </summary>
        /// <param name="request">Page Request.</param>
        /// <returns>Returns the list.</returns>
        [OperationContract]
        PageResponse<DocumentSequenceSearchResult> GetDocumentSequences(PageRequest request);

        /// <summary>
        /// GetDocumentSequence ById.
        /// </summary>
        /// <param name="sequenceId">Sequence Id.</param>
        /// <returns>Returns the Document Sequence.</returns>
        [OperationContract]
        DocumentSequence GetDocumentSequenceById(long sequenceId);
    }
}
