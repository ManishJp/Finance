﻿// ***********************************************************************
// <copyright file="DocumentTypeCount.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentTypeCount data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.Contracts.Objects
{
    using System.Collections.Generic;

    /// <summary>
    /// Class DocumentTypeCount.
    /// </summary>
    public class DocumentTypeCount
    {
        /// <summary>
        /// Gets or sets the Agency Count.
        /// </summary>
        /// <value>The Agency Count.</value>
        public long AgencyCount { get; set; }

        /// <summary>
        /// Gets or sets the UnAgency Count.
        /// </summary>
        /// <value>The UnAgency Count.</value>
        public long UnAgencyCount { get; set; }

        /// <summary>
        /// Gets or sets the Document Types.
        /// </summary>
        /// <value>The Document Types.</value>
        public IList<DocumentTypeSearchResult> DocumentTypes { get; set; }
    }
}