﻿// ***********************************************************************
// <copyright file="DocumentLineCharge.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentLineCharge data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.Contracts.Objects
{
    /// <summary>
    /// Model for Document LineCharge.    
    /// </summary>
    public class DocumentLineCharge 
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        /// <value>The Long Id.</value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the ChargeDetail.
        /// </summary>
        /// <value>This property gets or sets the value of the ChargeDetail.</value>
        public Charge Charge { get; set; }

        /// <summary>
        ///  Gets or sets the value for BusinessCode.
        /// </summary>
        /// <value>Business Code.</value>
        public string BusinessCode { get; set; }
    }
}