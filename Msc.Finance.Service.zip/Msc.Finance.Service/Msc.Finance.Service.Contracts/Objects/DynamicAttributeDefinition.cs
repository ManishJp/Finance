﻿// ***********************************************************************
// <copyright file="DynamicAttributeDefinition.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DynamicAttributeDefinition data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.Contracts.Objects
{
    /// <summary>
    /// Model for DynamicAttributeDefinition.
    /// </summary>
    public class DynamicAttributeDefinition
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the DynamicAttributeDefinition class.
        /// </summary>
        public DynamicAttributeDefinition()
            : base()
        {
            this.AttributeDetail = new GeneralCode();
            this.ValidationDetail = new GeneralCode();
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        /// <value>The Long Id.</value>
        public long Id { get; set; }
    
        /// <summary>
        /// Gets or sets the AttributeDetail.
        /// </summary>
        /// <value>This property gets the value of the AttributeDetail.</value>
        public GeneralCode AttributeDetail { get; set; }

        /// <summary>
        /// Gets or sets the ValidationDetail.
        /// </summary>
        /// <value>This property gets the value of the ValidationDetail.</value>
        public GeneralCode ValidationDetail { get; set; }
        #endregion
    }
}