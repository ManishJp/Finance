﻿// ***********************************************************************
// <copyright file="DocumentSequenceList.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentSequenceList data.
// </summary>
// ***********************************************************************

namespace Msc.Finance.Service.Contracts.Objects
{
    /// <summary>
    /// Class DocumentSequenceList.
    /// </summary>
    public class DocumentSequenceSearchResult : DocumentSequenceBase
    {
        /// <summary>
        /// Gets or sets the SubModule Detail.
        /// </summary>
        /// <value>The SubModule Detail.</value>
        public GeneralCode SubModuleDetail { get; set; } = new GeneralCode();

        /// <summary>
        /// Gets or sets the IssuingCompany Detail.
        /// </summary>
        /// <value>The IssuingCompany Detail.</value>
        public GeneralCode IssuingCompanyDetail { get; set; } = new GeneralCode();

        /// <summary>
        /// Gets or sets the Country Detail.
        /// </summary> 
        /// <value>The Country Detail.</value>
        public Country CountryHODetail { get; set; } = new Country();
    }
}