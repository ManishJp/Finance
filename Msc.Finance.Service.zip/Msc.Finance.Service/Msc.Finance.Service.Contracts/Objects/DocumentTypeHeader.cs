﻿// ***********************************************************************
// <copyright file="DocumentTypeHeader.cs"  company="MSC - iBox">
//   Mediterranean Shipping Company SA - iBox. OneVision Project.
// </copyright>
// <summary>
// This class holds the information of the DocumentTypeHeader data.
// </summary>
// ***********************************************************************
namespace Msc.Finance.Service.Contracts.Objects
{
    using System.Collections.Generic;

    /// <summary>
    /// Class DocumentTypeHeader.
    /// </summary>
    public class DocumentTypeHeader : DocumentTypeSearchResult
    {
        #region Properties

        /// <summary>
        ///  Gets or sets the value for AllowedRoles.
        /// </summary>
        /// <value>Allowed Roles.</value>
        public IList<Role> AllowedRoles { get; set; }

        /// <summary>
        ///  Gets or sets the value for HeaderDynamicAttributes.
        /// </summary>
        /// <value>Header DynamicAttributes.</value>
        public IList<DynamicAttributeDefinition> HeaderDynamicAttributes { get; set; }

        /// <summary>
        /// Gets or sets the LineItemDetails.
        /// </summary>
        /// <value>This property gets or sets the value of the LineItemDetails.</value>
        public IList<DocumentLineItem> LineItemDetails { get; set; }

        /// <summary>
        /// Gets or sets the SequenceTemplateDetail.
        /// </summary>
        /// <value>This property or sets the value of the SequenceTemplateDetail.</value>
        public IList<DocumentSequenceTemplate> SequenceTemplates { get; set; }        
        #endregion
    }
}
